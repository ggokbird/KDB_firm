
# %% ○ (1) Setting 
# %% (1)-(1) Working Directory
"""
Sets the current working directory to the specified directory. 
If it doesn't exist, creates it. Also sets the Chrome version.
Downloads the ChromeDriver for the specified Chrome version.
Unzips and saves it in the specified directory, and returns the path to the executable.
"""

import os
import zipfile
import requests
import re
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import SessionNotCreatedException
from bs4 import BeautifulSoup
import pandas as pd
import time
from time import sleep

start_date = '20230101'
end_date = '20230331'
filePath = 'C:\\Users\\KRX\\Desktop\\201021'

def createAndSetWorkingDir(directory):
    # chrome_version = "118.0.5993.70"
    # chrome_version = "119.0.6045.105"
    chrome_version = "123.0.6312.86"
    if not os.path.exists(directory):
        os.makedirs(directory)
    os.chdir(directory)
    print(f"Current working directory is now set to: {os.getcwd()}")

createAndSetWorkingDir(filePath)

def download_chromedriver(chrome_version):
    zip_path = os.path.join(filePath, "chromedriver.zip")
    extract_folder = os.path.join(filePath, "chromedriver-win32")
    
    # Base URL : https://googlechromelabs.github.io/chrome-for-testing/
    url = f"https://edgedl.me.gvt1.com/edgedl/chrome/chrome-for-testing/{chrome_version}/win32/chromedriver-win32.zip"
    response = requests.get(url, stream=True)
    if response.status_code != 200:
        raise Exception(f"Failed to download ChromeDriver for version {chrome_version}. Status code: {response.status_code}")

    with open(zip_path, "wb") as f:
        for chunk in response.iter_content(chunk_size=8192):
            f.write(chunk)

    print("Starting to unzip the chromedriver...")
    with zipfile.ZipFile(zip_path, 'r') as zip_ref:
        zip_ref.extractall(extract_folder)
    print("Unzipping completed.")

    chromedriver_exe_path = os.path.join(extract_folder, "chromedriver.exe")

    # Change the working directory to the extracted folder
    os.chdir(extract_folder)
    print(f"Working directory changed to: {os.getcwd()}")

    if os.path.exists(chromedriver_exe_path):
        return chromedriver_exe_path
    else:
        raise FileNotFoundError(f"'chromedriver.exe' was not found in the extracted directory: {extract_folder}")

try:
    # chrome_v = "118.0.5993.70"
    chrome_v = "119.0.6045.105"
    print(f"Expected Chrome version: {chrome_v}")
    chromedriver_path = download_chromedriver(chrome_v)
    print(f"Downloaded ChromeDriver path: {chromedriver_path}")
    
    options = webdriver.ChromeOptions()
    options.binary_location = r"C:\Program Files\Google\Chrome\Application\chrome.exe"
    service = Service(executable_path=chromedriver_path)
    driver = webdriver.Chrome(service=service, options=options)
    driver.get("https://www.google.com")
    driver.quit()

except SessionNotCreatedException as e:
    print(f"Error encountered: {str(e)}")
    match = re.search(r"Chrome version (\d+\.\d+\.\d+)", str(e))
    if match:
        chrome_version_detected = match.group(1)
        print(f"Detected Chrome version from error: {chrome_version_detected}")
        try:
            chromedriver_path = download_chromedriver(chrome_version_detected)
            print(f"Downloaded ChromeDriver path for detected version: {chromedriver_path}")
            
            options = webdriver.ChromeOptions()
            options.binary_location = r"C:\Program Files\Google\Chrome\Application\chrome.exe"
            service = Service(executable_path=chromedriver_path)
            driver = webdriver.Chrome(service=service, options=options)
            driver.get("https://www.google.com")
            driver.quit()
        except Exception as ex:
            print(f"Error while trying to download ChromeDriver for detected version: {ex}")
    
# %% ○ (2) Selenium Crawling 
# %% (2)-i) download attachment
from selenium import webdriver
import time
import pyautogui as pag
import pyperclip as py
import keyboard
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains
from selenium.common.exceptions import NoSuchElementException

"""
 - It can be useful :
     chrome_options.add_experimental_option("prefs",{'download.prompt_for_download': True})

 - Case 1 : ∃ 계약서류, 추가 첨부파일
    - ver1. ex) https://dataservice.koscom.co.kr/krx/100617/approval-detail
   * 주문서 : //*[@id="contents"]/div[3]/dl[3]/dd[1]/a/span[2] 
    ☞ print_dialog_first
    
   * 요약본 : //*[@id="contents"]/div[3]/dl[3]/dd[2]/a/span[2]
    ☞ print_dialog_first
    
   * 이용조건 : //*[@id="contents"]/div[3]/dl[4]/dd[1]/a/span[2]
   ☞ just click
   
   * 계약조건 : //*[@id="contents"]/div[3]/dl[4]/dd[2]/a/span[2]
   ☞ just click
   
   * 추가첨부_1 : //*[@id="contents"]/div[5]/dl[1]/dd/ul/li[1]/a/span[2]
   ☞ just click
   
   * 추가첨부_2 : //*[@id="contents"]/div[5]/dl[1]/dd/ul/li[2]/a/span[2]
   ☞ just click
   
"""
######################### Setting : should be excecuted #########################
def print_dialog_first(title, sub_title, driver):
    time.sleep(2)
    pag.press('enter') # "Print" Button     
    time.sleep(2)
    
    # Type subject 
    py.copy(title + "_" + sub_title) # copy to clipboard (Korean not supported in pag.typewrite)
    pag.hotkey('ctrl', 'v') 
    pag.press('enter') # "Print" Button     
    
    time.sleep(2) # For Loading 
    # ==========# It is "NO" for duplicated files(For safety, twice)==========
    keyboard.send("esc") 
    time.sleep(2) # For Loading 
    keyboard.send("Enter")
    time.sleep(1) # For Loading 
    
    keyboard.send("esc") 
    time.sleep(2) # For Loading 
    keyboard.send("Enter")
    time.sleep(1) # For Loading 
    
    # ====================# It is for click the "X"====================
    # dr.switch_to.window(dr.currnet_window_handle)
    webdriver.ActionChains(dr).send_keys(Keys.ESCAPE).perform()
    keyboard.send("esc") 
    time.sleep(2) # For Loading 
    keyboard.send("Enter")
    time.sleep(1) # For Loading 
    
    dr.switch_to.window(dr.currnet_window_handle)
    keyboard.send("esc") 
    time.sleep(2) # For Loading 
    keyboard.send("Enter")
    time.sleep(1) # For Loading 

def just_save_dialog_first(title, sub_title, driver):
    """
     - IF ∃ 2 or more files → More "enter" is needed (up to 4 files)
    """
    time.sleep(2)
    pag.press('enter') # "Print" Button     
    time.sleep(2)
    pag.press('enter') # "Print" Button     
    time.sleep(2)
    pag.press('enter') # "Print" Button     
    time.sleep(2)
    pag.press('enter') # "Print" Button     
    time.sleep(2)
    
    # # Type subject 
    # py.copy(title + "_" + sub_title) # copy to clipboard (Korean not supported in pag.typewrite)
    # pag.hotkey('ctrl', 'v') 
    # pag.press('enter') # "Print" Button     
    
    time.sleep(2) # For Loading 
    
    # ==========# It is "NO" for duplicated files(For safety, twice)==========
    # keyboard.send("esc") 
    # time.sleep(2) # For Loading 
    # keyboard.send("Enter")
    # time.sleep(2) # For Loading 
        
    # keyboard.send("esc") 
    # time.sleep(2) # For Loading 
    # keyboard.send("Enter")
    # time.sleep(2) # For Loading 

app_id = 'goguma@krx.co.kr'
app_pw = "wkrwjs12!@"

dr = webdriver.Chrome()
dr.set_window_size(1200, 2400)  # 웹창 크기 지정
dr.get('https://dataservice.koscom.co.kr/login?returnUrl=/krx/approval-list')  
dr.maximize_window()
dr.implicitly_wait(10)  # 창이 뜰때까지 기다림

def ilogin():
    # 요소 지정
    try : 
        id_box = dr.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[1]/div/div/input')   # ID입력창
        password_box = dr.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[2]/div/div/input') # password 입력창
        login_button = dr.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[3]/button')  # 로그인 버튼
    
        # 동작 실행하기
        act = ActionChains(dr) # 동작 실행 코드 지정
    
        id = app_id    # 아이디 입력받기
        password = app_pw    # 비밀번호 입력받기
        act.send_keys_to_element(id_box, '{}'.format(id)).send_keys_to_element(password_box, '{}'.format(password)).click(login_button).perform()    
        time.sleep(3)
        
    except NoSuchElementException as e : 
        """
         - if already login-ed
        """
        dr.get('https://dataservice.koscom.co.kr/krx/approval-list')  
        dr.maximize_window()
        dr.implicitly_wait(10)  # 창이 뜰때까지 기다림
        
    
# 테스트 코드
ilogin()

# %% (2)-ii) 웹사이트로부터 상품 정보 및 주석 데이터 추출하기 (표 1개 / 2개 모두 Working)
# %% - `230401 작업본
url = "https://dataservice.koscom.co.kr/krx/100617/approval-detail"
dr.get(url)
dr.maximize_window()
time.sleep(5)

######################### title & date #########################
"""
# title ← Same as wts_sub
"""

title = dr.find_element(By.XPATH, '//*[@id="contents"]/div[5]/div[1]/span') # title
title = title.text[15:][:len(title.text)-8] 

date = dr.find_element(By.XPATH, '//*[@id="contents"]/div[3]/dl[2]/dd[2]') # date
date = date.text

######################### attachment & def #########################
""" Example code
attach_1 = dr.find_element(By.XPATH, '//*[@id="contents"]/div[3]/dl[3]/dd[1]/a/span[2]') # 주문서
attach_1.click()

time.sleep(5) # For Loading 
print_dialog_first(title = title, sub_title = "주문서" + "(" + date + ")")
"""

######################### Iteration #########################
sub_name_dict = {
    "주문서" : '//*[@id="contents"]/div[3]/dl[3]/dd[1]/a/span[2]', 
    "요약본" : '//*[@id="contents"]/div[3]/dl[3]/dd[2]/a/span[2]',
    "이용조건" : '//*[@id="contents"]/div[3]/dl[4]/dd[1]/a/span[2]', 
    "계약조건" : '//*[@id="contents"]/div[3]/dl[4]/dd[2]/a/span[2]', 
    "추가첨부_1" : '//*[@id="contents"]/div[5]/dl[1]/dd/ul/li[1]/a/span[2]', 
    "추가첨부_2" : '//*[@id="contents"]/div[5]/dl[1]/dd/ul/li[2]/a/span[2]'
    }
"""
 - `23.3.2 : 문제 發 - esc 문제는 해결되었으나, 현재 중복 다운로드 등 문제 상존 
"""
for i, (sub_title, xpath) in enumerate(sub_name_dict.items()) : 
    if i <= 1 : 
        try : 
            time.sleep(5) # For Loading 
            attach = dr.find_element(By.XPATH, xpath) # 주문서, 요약본 ... 
            
            time.sleep(2) # For Loading 
            keyboard.send("esc") # pag.press('Esc') is not working / and sometimes keyboard.send not work 
            
            # time.sleep(2) # For Loading 
            # keyboard.send("esc") # pag.press('Esc') is not working
            
            attach.click()
            
            time.sleep(5) # For Loading 
            print_dialog_first(title = title, sub_title = sub_title + "(" + date + ")", driver = dr)
            # pag.press(pag.KEYBOARD_KEYS["esc"])
            # pag.press(pag.KEYBOARD_KEYS["esc"])
            # pag.press('esc') 
        except : 
            pass
        
    else : 
        try : 
            time.sleep(5) # For Loading 
            attach = dr.find_element(By.XPATH, xpath) # 이용조건, 계약조건 ... 
            attach.click()
            just_save_dialog_first(title = title, sub_title = sub_title + "(" + date + ")", driver = dr)
        except : 
            pass
# =============================================================================
# =============================================================================
# # ↑ `23.4. 작업본 ↓ `23.11 작업본
# =============================================================================
# =============================================================================
# %% - 231101 웹사이트로부터 상품 정보 및 주석 데이터 추출하기
# (표 1개 / 2개 모두 Working))

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.action_chains import ActionChains
from selenium.common.exceptions import NoSuchElementException
import time
import pandas as pd

def login(driver, app_id, app_pw):
    try:
        id_box = driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[1]/div/div/input')
        password_box = driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[2]/div/div/input')
        login_button = driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[3]/button')
        
        act = ActionChains(driver)
        act.send_keys_to_element(id_box, app_id).send_keys_to_element(password_box, app_pw).click(login_button).perform()
        time.sleep(3)
    except NoSuchElementException:
        driver.get('https://dataservice.koscom.co.kr/krx/approval-list')
        driver.maximize_window()
        driver.implicitly_wait(10)

def table_iter(num, driver):
    base_url = f"https://dataservice.koscom.co.kr/krx/{num}/approval-detail"
    driver.get(base_url)

    # 페이지에서 모든 행을 기다림
    WebDriverWait(driver, 10).until(
        EC.presence_of_all_elements_located((By.CSS_SELECTOR, 'table > tbody > tr'))
    )
    
    # 테이블의 모든 행(row)를 가져옴
    rows = driver.find_elements(By.CSS_SELECTOR, 'table > tbody > tr')
    result = []
    for row in rows:
        cells = row.find_elements(By.CSS_SELECTOR, 'td')
        result.append([cell.text for cell in cells])
    
    # 페이지에서 주석이 포함된 모든 div를 기다림
    WebDriverWait(driver, 10).until(
        EC.presence_of_all_elements_located((By.XPATH, "//div[contains(@style, 'margin-top:') and contains(text(), '주')]"))
    )
    
    # 노트(주석)을 가져옴
    notes = driver.find_elements(By.XPATH, "//div[contains(@style, 'margin-top:') and contains(text(), '주')]")
    notes_text = [note.text for note in notes]

    return result, notes_text

def convert_to_dataframes(data_list, notes_list):
    headers = ["구분", "상품명", "화폐단위", "이용료(월)", "제공방식", "계약 효력일"]
    df = pd.DataFrame(data_list, columns=headers)
    notes_df = pd.DataFrame(notes_list, columns=["Notes"])
    return df, notes_df

app_id = 'goguma@krx.co.kr'
app_pw = "wkrwjs12!@"

driver = webdriver.Chrome()
driver.set_window_size(1200, 2400)
driver.get('https://dataservice.koscom.co.kr/login?returnUrl=/krx/approval-list')
driver.maximize_window()
driver.implicitly_wait(10)

# Login
login(driver, app_id, app_pw)

# Extract data
num = 100562 # Example number, it can be different
data_result, notes_result = table_iter(num, driver)

# Convert the data to DataFrame
data_df, notes_df = convert_to_dataframes(data_result, notes_result)

# Display the data
print(data_df)
print(notes_df)

# Make sure to quit the driver after your scraping job is done
# driver.quit()

# %% - 웹사이트로부터 상품 정보 및 주석 데이터 추출하기 (seleniumwire Ver.)
# 231103
from seleniumwire import webdriver  # Import from seleniumwire
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.action_chains import ActionChains
from selenium.common.exceptions import NoSuchElementException, TimeoutException
import time
import pandas as pd

def login(driver, app_id, app_pw):
    try:
        driver.get('https://dataservice.koscom.co.kr/login?returnUrl=/krx/approval-list')
        WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[1]/div/div/input')))
        
        id_box = driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[1]/div/div/input')
        password_box = driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[2]/div/div/input')
        login_button = driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[3]/button')
        
        actions = ActionChains(driver)
        actions.send_keys_to_element(id_box, app_id)
        actions.send_keys_to_element(password_box, app_pw)
        actions.click(login_button)
        actions.perform()
        
        WebDriverWait(driver, 10).until(EC.url_to_be('https://dataservice.koscom.co.kr/krx/approval-list'))
        
    except NoSuchElementException as e:
        print("[ERROR] One of the login elements could not be found.", e)
        driver.quit()
    except TimeoutException as e:
        print("[ERROR] Timeout occurred during login.", e)

def extract_data(driver, num):
    base_url = f"https://dataservice.koscom.co.kr/krx/{num}/approval-detail"
    driver.get(base_url)

    WebDriverWait(driver, 10).until(
        EC.presence_of_all_elements_located((By.CSS_SELECTOR, 'table > tbody > tr'))
    )

    rows = driver.find_elements(By.CSS_SELECTOR, 'table > tbody > tr')
    result = []
    for row in rows:
        cells = row.find_elements(By.CSS_SELECTOR, 'td')
        result.append([cell.text for cell in cells])

    WebDriverWait(driver, 10).until(
        EC.presence_of_all_elements_located((By.XPATH, "//div[contains(@style, 'margin-top:') and contains(text(), '주')]"))
    )

    notes = driver.find_elements(By.XPATH, "//div[contains(@style, 'margin-top:') and contains(text(), '주')]")
    notes_text = [note.text for note in notes]

    return result, notes_text

def convert_to_dataframes(data_list, notes_list):
    headers = ["구분", "상품명", "화폐단위", "이용료(월)", "제공방식", "계약 효력일"]
    df = pd.DataFrame(data_list, columns=headers)
    notes_df = pd.DataFrame(notes_list, columns=["Notes"])
    return df, notes_df

# 메인 실행 코드
if __name__ == "__main__":
    seleniumwire_options = {
        'connection_timeout': None,
        'verify_ssl': False,
    }

    driver = webdriver.Chrome(seleniumwire_options=seleniumwire_options)

    try:
        # Login
        login(driver, 'goguma@krx.co.kr', 'wkrwjs12!@')

        # Extract data
        num = 100561 # Example number, replace with actual value if necessary
        data_result, notes_result = extract_data(driver, num)

        # Convert the data to DataFrame
        data_df, notes_df = convert_to_dataframes(data_result, notes_result)

        # Display the data
        print(data_df)
        print(notes_df)

    except Exception as e:
        print("[ERROR] An error occurred:", e)
    finally:
        driver.quit()

# %% (2)-iii) 셀레니움을 이용한 웹사이트 로그인 및 다운로드 링크 클릭 로깅
# %% - 다운로드 링크 클릭 [(3) Error]
# 231102 
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import NoSuchElementException
import pandas as pd
import time
import pyautogui
import keyboard

def login(driver, app_id, app_pw):
    # 로그인 시도 전 로그 출력
    print("[INFO] 로그인을 시도합니다.")
    id_box = driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[1]/div/div/input')
    password_box = driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[2]/div/div/input')
    login_button = driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[3]/button')
    
    act = ActionChains(driver)
    act.send_keys_to_element(id_box, app_id).send_keys_to_element(password_box, app_pw).click(login_button).perform()
    time.sleep(3)

def table_iter(num, driver):
    # 상세 페이지 이동 전 로그 출력
    print(f"[INFO] 상세 페이지로 이동합니다: {num}")
    base_url = f"https://dataservice.koscom.co.kr/krx/{num}/approval-detail"
    driver.get(base_url)

    WebDriverWait(driver, 10).until(
        EC.presence_of_all_elements_located((By.CSS_SELECTOR, 'table > tbody > tr'))
    )
    
    rows = driver.find_elements(By.CSS_SELECTOR, 'table > tbody > tr')
    result = []
    for row in rows:
        cells = row.find_elements(By.CSS_SELECTOR, 'td')
        result.append([cell.text for cell in cells])
    
    WebDriverWait(driver, 10).until(
        EC.presence_of_all_elements_located((By.XPATH, "//div[contains(@style, 'margin-top:') and contains(text(), '주')]"))
    )
    
    notes = driver.find_elements(By.XPATH, "//div[contains(@style, 'margin-top:') and contains(text(), '주')]")
    notes_text = [note.text for note in notes]

    return result, notes_text

def convert_to_dataframes(data_list, notes_list):
    # 데이터프레임 변환 전 로그 출력
    print("[INFO] 데이터를 데이터프레임으로 변환합니다.")
    headers = ["구분", "상품명", "화폐단위", "이용료(월)", "제공방식", "계약 효력일"]
    df = pd.DataFrame(data_list, columns=headers)
    notes_df = pd.DataFrame(notes_list, columns=["Notes"])
    return df, notes_df

def handle_print_dialog():
    # 인쇄 대화 상자 처리 전 로그 출력
    print("[INFO] 인쇄 대화 상자를 처리합니다.")
    time.sleep(2)
    pyautogui.press('enter')  # "Print" Button
    time.sleep(2)
    pyautogui.hotkey('ctrl', 'v') 
    pyautogui.press('enter')  # "Print" Button
    time.sleep(2)
    keyboard.send("esc")
    time.sleep(2)
    keyboard.send("enter")
    time.sleep(1)
    keyboard.send("esc")

# capabilities = DesiredCapabilities.CHROME
# capabilities['goog:loggingPrefs'] = {'browser': 'ALL'}

# driver = webdriver.Chrome(desired_capabilities=capabilities)
# driver = webdriver.Chrome()
# ChromeOptions 인스턴스 생성
chrome_options = webdriver.ChromeOptions()

# 로거 설정 추가
chrome_options.set_capability('goog:loggingPrefs', {'browser': 'ALL'})

# Chrome 드라이버 인스턴스 생성
driver = webdriver.Chrome(options=chrome_options)

app_id = 'goguma@krx.co.kr'
app_pw = "wkrwjs12!@"

driver.set_window_size(1200, 2400)
driver.get('https://dataservice.koscom.co.kr/login?returnUrl=/krx/approval-list')
driver.maximize_window()
driver.implicitly_wait(10)

login(driver, app_id, app_pw)

num = 100562  # Example number, adjust for actual use
data_result, notes_result = table_iter(num, driver)

data_df, notes_df = convert_to_dataframes(data_result, notes_result)

print(data_df)
print(notes_df)

print("[INFO] 다운로드 링크를 클릭합니다.")
download_links = driver.find_elements(By.CSS_SELECTOR, 'a.file-link[download]')
for index, link in enumerate(download_links):
    link_text = link.find_element(By.XPATH, ".//span[contains(@class, 'name')]").text
    try:
        if "이용조건" not in link_text:
            print(f"[INFO] 다운로드 링크 ({index}) 클릭.")
            driver.execute_script("arguments[0].click();", link)
            handle_print_dialog()  # 이용조건이 아닌 링크에 대해 인쇄 대화 상자 처리
        else:
            print(f"[INFO] '이용조건' 다운로드 링크 클릭, 별도의 인쇄 대화 상자 처리를 생략합니다.")
            driver.execute_script("arguments[0].click();", link)
            # '이용조건' 링크의 경우 별도의 처리가 필요없으므로 대기만 합니다.
            time.sleep(5)  # 다운로드가 시작되기를 기다립니다.
    except Exception as e:
        print(f"[ERROR] 다운로드 링크 클릭 오류: {e}")

# %% ○ (3) Json Responses
# %% (3)-i) 웹사이트 로그인 및 동적 JSON 데이터 추출 자동화 스크립트
from seleniumwire import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import pandas as pd
import json
import time
import gzip
import os
import traceback

# 로그인 함수
def login(driver, app_id, app_pw):
    print("[INFO] 로그인을 시도합니다.")
    driver.get('https://dataservice.koscom.co.kr/login?returnUrl=/krx/approval-list')
    WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[1]/div/div/input')))
    id_box = driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[1]/div/div/input')
    password_box = driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[2]/div/div/input')
    login_button = driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[3]/button')
    id_box.send_keys(app_id)
    password_box.send_keys(app_pw)
    login_button.click()
    WebDriverWait(driver, 10).until(EC.url_to_be('https://dataservice.koscom.co.kr/krx/approval-list'))

# 데이터 추출 함수
def table_iter(num, driver):
    print(f"[INFO] 상세 페이지로 이동합니다: {num}")
    base_url = f"https://dataservice.koscom.co.kr/krx/{num}/approval-detail"
    driver.get(base_url)
    WebDriverWait(driver, 10).until(EC.presence_of_all_elements_located((By.CSS_SELECTOR, 'table > tbody > tr')))
    rows = driver.find_elements(By.CSS_SELECTOR, 'table > tbody > tr')
    result = [[cell.text for cell in row.find_elements(By.CSS_SELECTOR, 'td')] for row in rows]
    WebDriverWait(driver, 10).until(EC.presence_of_all_elements_located((By.XPATH, "//div[contains(@style, 'margin-top:') and contains(text(), '주')]")))
    notes = [note.text for note in driver.find_elements(By.XPATH, "//div[contains(@style, 'margin-top:') and contains(text(), '주')]")]
    return result, notes

# 데이터를 DataFrame으로 변환하는 함수
def convert_to_dataframes(data_list, notes_list):
    headers = ["구분", "상품명", "화폐단위", "이용료(월)", "제공방식", "계약 효력일"]
    df = pd.DataFrame(data_list, columns=headers)
    notes_df = pd.DataFrame(notes_list, columns=["Notes"])
    return df, notes_df

# JSON 데이터를 파일에 저장하는 함수
def save_json_to_file(data, filename):
    with open(filename, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=4)

# 메인 실행 코드입니다.
if __name__ == "__main__":
    seleniumwire_options = {
        'connection_timeout': None,
        'verify_ssl': False,
    }
    driver = webdriver.Chrome(seleniumwire_options=seleniumwire_options)

    try:
        login(driver, 'goguma@krx.co.kr', 'wkrwjs12!@')

        # 데이터 추출
        num = '100562'
        data_result, notes_result = table_iter(num, driver)
        data_df, notes_df = convert_to_dataframes(data_result, notes_result)

        # 클릭할 다운로드 버튼 요소를 찾습니다.
        download_link = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, '.iconset.icon-down-attach'))
        )
        download_link.click()  # 요소를 클릭합니다.

        # 클릭 후에 발생하는 요청을 필터링합니다.
        time.sleep(3)  # 네트워크 트래픽을 기다립니다.
        json_responses = []
        for request in driver.requests:
            if request.response and 'application/json' in request.response.headers.get('Content-Type', ''):
                print(f"요청 URL: {request.url}")
                print(f"응답 코드: {request.response.status_code}")
                content_encoding = request.response.headers.get('Content-Encoding', '')
                if 'gzip' in content_encoding:
                    json_data = gzip.decompress(request.response.body).decode('utf-8')
                else:
                    json_data = request.response.body.decode('utf-8')
                
                # JSON 데이터를 파이썬 객체로 변환하고 리스트에 추가합니다.
                json_obj = json.loads(json_data)
                # 요청 URL을 JSON 객체에 추가합니다.
                # 만약 json_obj가 리스트 형태라면 각 항목에 URL을 추가해야 합니다.
                if isinstance(json_obj, list):
                    for item in json_obj:
                        if isinstance(item, dict):
                            item['request_url'] = request.url
                    json_responses.extend(json_obj)
                else:
                    json_obj['request_url'] = request.url
                    json_responses.append(json_obj)

        # JSON 데이터를 파일에 저장합니다.
        save_json_to_file(json_responses, 'output.json')
        
        # 파일에서 DataFrame으로 변환합니다.
        # DataFrame 생성 전에 json_responses 내부의 모든 원소가 딕셔너리 형인지 확인합니다.
        if all(isinstance(item, dict) for item in json_responses):
            df_from_json = pd.json_normalize(json_responses, sep='_')
            print(df_from_json)  # DataFrame 출력
        else:
            print("Error: Not all items in json_responses are dictionaries.")

        # 원래 데이터 프레임 출력
        print(data_df)
        print(notes_df)

    except Exception as e:
        print("[ERROR] An error occurred:", traceback.format_exc())
    finally:
        driver.quit()
        if os.path.exists('output.json'):
            os.remove('output.json')
# %% (3)-ii) 자동화된 웹 브라우저를 통한 로그인 및 데이터 추출 시스템 (헤더 포함) 
# 231106 
from seleniumwire import webdriver  # Selenium Wire를 임포트합니다.
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import pandas as pd
import json
import time
import gzip
import os
import traceback

# 로그인 함수
def login(driver, app_id, app_pw):
    print("[INFO] 로그인을 시도합니다.")
    driver.get('https://dataservice.koscom.co.kr/login?returnUrl=/krx/approval-list')
    WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[1]/div/div/input')))
    id_box = driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[1]/div/div/input')
    password_box = driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[2]/div/div/input')
    login_button = driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[3]/button')
    id_box.send_keys(app_id)
    password_box.send_keys(app_pw)
    login_button.click()
    WebDriverWait(driver, 10).until(EC.url_to_be('https://dataservice.koscom.co.kr/krx/approval-list'))

# 데이터 추출 함수
def table_iter(num, driver):
    print(f"[INFO] 상세 페이지로 이동합니다: {num}")
    base_url = f"https://dataservice.koscom.co.kr/krx/{num}/approval-detail"
    driver.get(base_url)
    WebDriverWait(driver, 10).until(EC.presence_of_all_elements_located((By.CSS_SELECTOR, 'table > tbody > tr')))
    rows = driver.find_elements(By.CSS_SELECTOR, 'table > tbody > tr')
    result = [[cell.text for cell in row.find_elements(By.CSS_SELECTOR, 'td')] for row in rows]
    WebDriverWait(driver, 10).until(EC.presence_of_all_elements_located((By.XPATH, "//div[contains(@style, 'margin-top:') and contains(text(), '주')]")))
    notes = [note.text for note in driver.find_elements(By.XPATH, "//div[contains(@style, 'margin-top:') and contains(text(), '주')]")]
    return result, notes

# 데이터를 DataFrame으로 변환하는 함수
def convert_to_dataframes(data_list, notes_list):
    headers = ["구분", "상품명", "화폐단위", "이용료(월)", "제공방식", "계약 효력일"]
    df = pd.DataFrame(data_list, columns=headers)
    notes_df = pd.DataFrame(notes_list, columns=["Notes"])
    return df, notes_df

# JSON 데이터를 파일에 저장하는 함수
def save_json_to_file(data, filename):
    with open(filename, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=4)

# 메인 실행 코드
if __name__ == "__main__":
    seleniumwire_options = {
        'connection_timeout': None,
        'verify_ssl': False,
    }
    driver = webdriver.Chrome(seleniumwire_options=seleniumwire_options)

    try:
        # 실제 사용자 정보로 변경해야 합니다.
        login(driver, 'goguma@krx.co.kr', 'wkrwjs12!@')

        # 데이터 추출
        num = '100562'
        data_result, notes_result = table_iter(num, driver)
        data_df, notes_df = convert_to_dataframes(data_result, notes_result)

        # 클릭할 다운로드 버튼 요소를 찾습니다.
        download_link = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, '.iconset.icon-down-attach'))
        )
        download_link.click()  # 요소를 클릭합니다.

        # 클릭 후에 발생하는 요청을 필터링합니다.
        time.sleep(3)  # 네트워크 트래픽을 기다립니다.
        for request in driver.requests:
            if request.response and 'application/json' in request.response.headers.get('Content-Type', ''):
                print(f"요청 URL: {request.url}")
                print(f"응답 코드: {request.response.status_code}")
                print(f"요청 헤더: {request.headers}")
                if request.body:
                    # 요청 본문이 있다면 출력합니다.
                    print(f"요청 바디: {request.body.decode('utf-8', 'ignore')}")
                else:
                    print("요청 바디: None")
                
                # 응답 본문을 출력할 수도 있습니다.
                # 만약 응답이 크다면 이를 출력하지 않거나 적절하게 처리해야 할 수 있습니다.
                # if request.response.body:
                #     print(f"응답 바디: {request.response.body.decode('utf-8', 'ignore')}")

        # 원래 데이터 프레임 출력
        print(data_df)
        print(notes_df)

    except Exception as e:
        print("[ERROR] An error occurred:", traceback.format_exc())
    finally:
        driver.quit()
        
# %% (3)-iii) Selenium Wire를 활용한 웹 자동 로그인 및 인증 헤더 추출을 통한 API 호출 자동화
# 231106 1130 
from seleniumwire import webdriver  # Selenium Wire를 임포트합니다.
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import pandas as pd
import json
import time
import gzip
import os
import traceback

# 로그인 함수
def login(driver, app_id, app_pw):
    print("[INFO] 로그인을 시도합니다.")
    driver.get('https://dataservice.koscom.co.kr/login?returnUrl=/krx/approval-list')
    WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[1]/div/div/input')))
    id_box = driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[1]/div/div/input')
    password_box = driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[2]/div/div/input')
    login_button = driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[3]/button')
    id_box.send_keys(app_id)
    password_box.send_keys(app_pw)
    login_button.click()
    WebDriverWait(driver, 10).until(EC.url_to_be('https://dataservice.koscom.co.kr/krx/approval-list'))

# 데이터 추출 함수
def table_iter(num, driver):
    print(f"[INFO] 상세 페이지로 이동합니다: {num}")
    base_url = f"https://dataservice.koscom.co.kr/krx/{num}/approval-detail"
    driver.get(base_url)
    WebDriverWait(driver, 10).until(EC.presence_of_all_elements_located((By.CSS_SELECTOR, 'table > tbody > tr')))
    rows = driver.find_elements(By.CSS_SELECTOR, 'table > tbody > tr')
    result = [[cell.text for cell in row.find_elements(By.CSS_SELECTOR, 'td')] for row in rows]
    WebDriverWait(driver, 10).until(EC.presence_of_all_elements_located((By.XPATH, "//div[contains(@style, 'margin-top:') and contains(text(), '주')]")))
    notes = [note.text for note in driver.find_elements(By.XPATH, "//div[contains(@style, 'margin-top:') and contains(text(), '주')]")]
    return result, notes

# 데이터를 DataFrame으로 변환하는 함수
def convert_to_dataframes(data_list, notes_list):
    headers = ["구분", "상품명", "화폐단위", "이용료(월)", "제공방식", "계약 효력일"]
    df = pd.DataFrame(data_list, columns=headers)
    notes_df = pd.DataFrame(notes_list, columns=["Notes"])
    return df, notes_df

# JSON 데이터를 파일에 저장하는 함수
def save_json_to_file(data, filename):
    with open(filename, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=4)

# 메인 실행 코드
if __name__ == "__main__":
    seleniumwire_options = {
        'connection_timeout': None,
        'verify_ssl': False,
    }
    driver = webdriver.Chrome(seleniumwire_options=seleniumwire_options)

    try:
        login(driver, 'goguma@krx.co.kr', 'wkrwjs12!@')

        # 데이터 추출
        num = '100562'
        data_result, notes_result = table_iter(num, driver)
        data_df, notes_df = convert_to_dataframes(data_result, notes_result)

        # 클릭할 다운로드 버튼 요소를 찾습니다.
        download_link = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, '.iconset.icon-down-attach'))
        )
        download_link.click()  # 요소를 클릭합니다.

        # 클릭 후에 발생하는 요청을 필터링합니다.
        time.sleep(3)  # 네트워크 트래픽을 기다립니다.
        json_responses = []
        for request in driver.requests:
            if request.response and 'application/json' in request.response.headers.get('Content-Type', ''):
                print(f"요청 URL: {request.url}")
                print(f"응답 코드: {request.response.status_code}")
                print(f"요청 헤더: {request.headers}")
                if request.body:
                    # 요청 본문이 있다면 출력합니다.
                    print(f"요청 바디: {request.body.decode('utf-8', 'ignore')}")
                else:
                    print("요청 바디: None")

                # 응답이 gzip으로 압축되었다면 압축 해제합니다.
                content_encoding = request.response.headers.get('Content-Encoding', '')
                if 'gzip' in content_encoding:
                    response_body = gzip.decompress(request.response.body).decode('utf-8')
                else:
                    response_body = request.response.body.decode('utf-8')

                # JSON 응답을 파이썬 객체로 변환하여 리스트에 추가합니다.
                json_responses.append(json.loads(response_body))

        # JSON 응답을 파일에 저장합니다.
        save_json_to_file(json_responses, 'api_responses.json')
        print("[INFO] JSON 응답이 파일에 저장되었습니다.")

        # 원래 데이터 프레임 출력
        print(data_df)
        print(notes_df)

    except Exception as e:
        print("[ERROR] An error occurred:", traceback.format_exc())
    finally:
        driver.quit()

# %% (3)-iv) 웹 자동화를 통한 크롤링 및 API 응답 데이터(All) 추출 및 저장 
# 231106 2230 
# Json_responses 에서 원하는 정보 추출 가능 (요청 정보 / 받은 정보 추출)

from seleniumwire import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import pandas as pd
import json
import time
import gzip
import traceback

# 로그인 함수
def login(driver, app_id, app_pw):
    print("[INFO] 로그인을 시도합니다.")
    driver.get('https://dataservice.koscom.co.kr/login?returnUrl=/krx/approval-list')
    WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[1]/div/div/input')))
    id_box = driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[1]/div/div/input')
    password_box = driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[2]/div/div/input')
    login_button = driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[3]/button')
    id_box.send_keys(app_id)
    password_box.send_keys(app_pw)
    login_button.click()
    WebDriverWait(driver, 10).until(EC.url_to_be('https://dataservice.koscom.co.kr/krx/approval-list'))

# 데이터 추출 함수
def table_iter(num, driver):
    print(f"[INFO] 상세 페이지로 이동합니다: {num}")
    base_url = f"https://dataservice.koscom.co.kr/krx/{num}/approval-detail"
    driver.get(base_url)
    WebDriverWait(driver, 10).until(EC.presence_of_all_elements_located((By.CSS_SELECTOR, 'table > tbody > tr')))
    rows = driver.find_elements(By.CSS_SELECTOR, 'table > tbody > tr')
    result = [[cell.text for cell in row.find_elements(By.CSS_SELECTOR, 'td')] for row in rows]
    return result

# 데이터를 DataFrame으로 변환하는 함수
def convert_to_dataframes(data_list):
    headers = ["구분", "상품명", "화폐단위", "이용료(월)", "제공방식", "계약 효력일"]
    df = pd.DataFrame(data_list, columns=headers)
    return df

# 메인 실행 코드
if __name__ == "__main__":
    seleniumwire_options = {
        'connection_timeout': None,
        'verify_ssl': False,
    }
    driver = webdriver.Chrome(seleniumwire_options=seleniumwire_options)

    try:
        # 실제 사용자 정보로 변경해야 합니다.
        login(driver, 'goguma@krx.co.kr', 'wkrwjs12!@')

        # 데이터 추출
        num = '100562'
        data_result = table_iter(num, driver)
        data_df = convert_to_dataframes(data_result)

        # 클릭 후에 발생하는 요청을 필터링합니다.
        time.sleep(3)  # 네트워크 트래픽을 기다립니다.
        json_responses = []
        for request in driver.requests:
            if request.response and 'application/json' in request.response.headers.get('Content-Type', ''):
                response_body = request.response.body
                if 'gzip' in request.response.headers.get('Content-Encoding', ''):
                    response_body = gzip.decompress(response_body)
                response_body = response_body.decode('utf-8')
                json_data = json.loads(response_body)

                # Check if request is a POST and has a body
                request_body = None
                if request.method == 'POST' and request.body:
                    request_body = request.body.decode('utf-8')
                    try:
                        request_body = json.loads(request_body)
                    except json.JSONDecodeError:
                        pass  # request_body remains a string if it's not JSON

                response_info = {
                    'request_url': request.url,
                    'request_method': request.method,
                    'request_body': request_body,
                    'request_headers': dict(request.headers),
                    'response_code': request.response.status_code,
                    'response_headers': dict(request.response.headers),
                    'response_body': json_data
                }
                json_responses.append(response_info)

        # JSON 응답을 파일에 저장합니다.
        with open('api_responses.json', 'w', encoding='utf-8') as f:
            json.dump(json_responses, f, ensure_ascii=False, indent=4)

        print("[INFO] JSON 응답이 파일에 저장되었습니다.")

        # 데이터 프레임을 출력하거나 파일로 저장할 수 있습니다.
        print(data_df)

    except Exception as e:
        print("[ERROR] An error occurred:", traceback.format_exc())
    finally:
        driver.quit()

# %% ○ (4) 코스콤 데이터 서비스 로그인 및 API 호출 자동화 스크립트 (프로필 도입)
# 231106 2330 
# 프로필 로그인을 위해서는 프로필 (C:\Users\221016\AppData\Local\Google\Chrome\User Data) 
# 정보를 다른 DIR 에 복사하여 설정해주어야 충돌 문제가 없음
# %% (4)-i) 크롬 드라이버를 활용한 코스콤 데이터 서비스 로그인 및 API 응답 데이터 추출
# 231112 2300 
import subprocess
import json
import time
import os
import datetime
from bs4 import BeautifulSoup  # 추가된 부분
from seleniumwire import webdriver
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import WebDriverException
import traceback
import requests

# 설정 및 경로 정의
CHROMEDRIVER_PATH = 'C:\\Users\\KRX\\Desktop\\201021\\chromedriver-win32\\chromedriver.exe'
CHROME_BINARY_PATH = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe'
LOGIN_URL = 'https://dataservice.koscom.co.kr/login?returnUrl=/krx/approval-list'
TARGET_URL = 'https://dataservice.koscom.co.kr/krx/approval-list'
PROFILE_PATH = 'C:\\Users\\KRX\\Desktop\\201021'
PROFILE_NAME = 'Profile 4'

# Chrome 옵션 설정
chrome_options = Options()
chrome_options.binary_location = CHROME_BINARY_PATH
chrome_options.add_argument("--disable-gpu")
chrome_options.add_argument("--no-sandbox")
chrome_options.add_argument("--start-maximized")
chrome_options.add_argument(f'user-data-dir={PROFILE_PATH}')
chrome_options.add_argument(f'profile-directory={PROFILE_NAME}')

# 기존 Chrome 작업 종료
def kill_chrome_tasks():
    try:
        subprocess.run(["taskkill", "/f", "/im", "chrome.exe"], check=True)
        print("Existing Chrome tasks terminated successfully.")
    except subprocess.CalledProcessError as e:
        print(f"Error terminating Chrome tasks: {e}")

# WebDriver 인스턴스 생성
def create_webdriver():
    service = ChromeService(executable_path=CHROMEDRIVER_PATH)
    driver = webdriver.Chrome(service=service, options=chrome_options)
    return driver

# 로그인 함수
def login(driver, app_id, app_pw):
    try:
        driver.get(LOGIN_URL)
        WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[1]/div/div/input')))
        id_box = driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[1]/div/div/input')
        password_box = driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[2]/div/div/input')
        login_button = driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[3]/button')
        id_box.send_keys(app_id)
        password_box.send_keys(app_pw)
        login_button.click()
        WebDriverWait(driver, 15).until(EC.url_to_be(TARGET_URL))
        print("[INFO] 로그인에 성공했습니다.")
    except Exception as e:
        print("[ERROR] 로그인 중 오류 발생:", traceback.format_exc())

# HTML에서 텍스트 추출 함수
def extract_text_from_html(html_content):
    soup = BeautifulSoup(html_content, 'html.parser')
    return soup.get_text()

# API 요청 함수
def send_api_request(url, headers):
    response = requests.get(url, headers=headers, verify=False)
    if response.status_code == 200:
        html_content = response.content.decode('utf-8')  # HTML 컨텐츠 추출
        text_content = extract_text_from_html(html_content)  # 텍스트만 추출
        return text_content
    else:
        print(f"[ERROR] API 요청 실패. Status Code: {response.status_code}")
        print(f"Response: {response.text}")
        return None

# 메인 실행 코드
if __name__ == "__main__":
    driver = create_webdriver()
    try:
        login(driver, 'goguma@krx.co.kr', 'wkrwjs12!@')
        time.sleep(10) # 인증 키 얻는 시간 고려
        headers = None
        for request in driver.requests:
            if 'Authorization' in request.headers:
                headers = {'Authorization': request.headers['Authorization']}
                break
        if not headers:
            print("[ERROR] Authorization 헤더를 찾을 수 없습니다.")
        else:
            YOUR_API_URL = 'https://dataservice.koscom.co.kr/apis/v1/user/approvals/100562'
            text_response = send_api_request(YOUR_API_URL, headers)
            if text_response:
                print("[INFO] API 응답 데이터:", text_response)
            else:
                print("[ERROR] API 요청 실패")
    except Exception as e:
        print("[ERROR] 메인 실행 중 오류 발생:", traceback.format_exc())
    finally:
        driver.quit()  # Uncomment if you want to close the browser at the end
        print("세션을 종료하고 프로세스가 완료되었습니다.")

# %% (4)-ii) 크롬 드라이버를 활용한 코스콤 데이터 서비스 로그인 및 API 응답 데이터 추출 (List 作)
# 231112 2330 
import subprocess
import json
import time
import os
import datetime
from seleniumwire import webdriver
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import WebDriverException
import traceback
import requests
from bs4 import BeautifulSoup

# 설정 및 경로 정의
CHROMEDRIVER_PATH = 'C:\\Users\\KRX\\Desktop\\201021\\chromedriver-win32\\chromedriver.exe'
CHROME_BINARY_PATH = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe'
LOGIN_URL = 'https://dataservice.koscom.co.kr/login?returnUrl=/krx/approval-list'
TARGET_URL = 'https://dataservice.koscom.co.kr/krx/approval-list'
PROFILE_PATH = 'C:\\Users\\KRX\\Desktop\\201021'
PROFILE_NAME = 'Profile 4'

# Chrome 옵션 설정
chrome_options = Options()
chrome_options.binary_location = CHROME_BINARY_PATH
chrome_options.add_argument("--disable-gpu")
chrome_options.add_argument("--no-sandbox")
chrome_options.add_argument("--start-maximized")
chrome_options.add_argument(f'user-data-dir={PROFILE_PATH}')
chrome_options.add_argument(f'profile-directory={PROFILE_NAME}')

# 기존 Chrome 작업 종료
def kill_chrome_tasks():
    try:
        subprocess.run(["taskkill", "/f", "/im", "chrome.exe"], check=True)
        print("Existing Chrome tasks terminated successfully.")
    except subprocess.CalledProcessError as e:
        print(f"Error terminating Chrome tasks: {e}")

# WebDriver 인스턴스 생성
def create_webdriver():
    service = ChromeService(executable_path=CHROMEDRIVER_PATH)
    driver = webdriver.Chrome(service=service, options=chrome_options)
    return driver

# 로그인 함수
def login(driver, app_id, app_pw):
    try:
        driver.get(LOGIN_URL)
        WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[1]/div/div/input')))
        id_box = driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[1]/div/div/input')
        password_box = driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[2]/div/div/input')
        login_button = driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[3]/button')
        id_box.send_keys(app_id)
        password_box.send_keys(app_pw)
        login_button.click()
        WebDriverWait(driver, 15).until(EC.url_to_be(TARGET_URL))
        print("[INFO] 로그인에 성공했습니다.")
    except Exception as e:
        print("[ERROR] 로그인 중 오류 발생:", traceback.format_exc())

# BeautifulSoup을 사용하여 HTML 테이블 추출
def extract_tables_from_html(html_content):
    soup = BeautifulSoup(html_content, 'html.parser')
    tables = soup.find_all('table')
    result = []

    for table in tables:
        rows = table.find_all('tr')
        table_data = []

        for row in rows:
            cols = row.find_all(['td', 'th'])
            cols = [ele.text.strip() for ele in cols]
            table_data.append(cols)

        result.append(table_data)

    return result

# API 요청 함수
def send_api_request(url, headers):
    response = requests.get(url, headers=headers, verify=False)
    if response.status_code == 200:
        html_content = response.content.decode('utf-8')
        tables = extract_tables_from_html(html_content)
        return tables
    else:
        print(f"[ERROR] API 요청 실패. Status Code: {response.status_code}")
        print(f"Response: {response.text}")
        return None

# 메인 실행 코드
if __name__ == "__main__":
    driver = create_webdriver()
    try:
        login(driver, 'goguma@krx.co.kr', 'wkrwjs12!@')
        time.sleep(10) # 인증 키 얻는 시간 고려
        headers = None
        for request in driver.requests:
            if 'Authorization' in request.headers:
                headers = {'Authorization': request.headers['Authorization']}
                break
        if not headers:
            print("[ERROR] Authorization 헤더를 찾을 수 없습니다.")
        else:
            YOUR_API_URL = 'https://dataservice.koscom.co.kr/apis/v1/user/approvals/100562'
            tables_response = send_api_request(YOUR_API_URL, headers)
            if tables_response:
                print("[INFO] API 응답 데이터:", tables_response)
            else:
                print("[ERROR] API 요청 실패")
    except Exception as e:
        print("[ERROR] 메인 실행 중 오류 발생:", traceback.format_exc())
    finally:
        driver.quit()  # Uncomment if you want to close the browser at the end
        print("세션을 종료하고 프로세스가 완료되었습니다.")

# %% (4)-iii) 크롬 드라이버를 이용한 로그인과 BeautifulSoup을 활용한 HTML 테이블 데이터 추출 (Same With (3)-ii) / iii) )
# 231113 2200 
# (3)-ii) / iii) 과 동일 데이터 추출 수행
"""
- 로그인 후 대기 시간: 로그인 후 대기 시간이 20초에서 5초로 줄어듦.
- API 요청 처리: 첫 번째 API 요청 후, 응답이 없을 경우 재시도나 추가 처리가 없음.
- 네트워크 요청 로그: 별도의 네트워크 요청 로그를 파일로 저장하는 기능이 없음.
- 추가된 설정: 참조 ID (REFERENCE_ID) 같은 별도의 설정이 추가되지 않음.
- 로그 메시지: 상세한 로그 메시지 출력 및 예외 처리 메시지가 포함됨.

"""

import subprocess
import json
import time
import os
import datetime
from seleniumwire import webdriver
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import WebDriverException
import traceback
import requests
from bs4 import BeautifulSoup

# 설정 및 경로 정의
CHROMEDRIVER_PATH = 'C:\\Users\\KRX\\Desktop\\201021\\chromedriver-win32\\chromedriver.exe'
CHROME_BINARY_PATH = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe'
LOGIN_URL = 'https://dataservice.koscom.co.kr/login?returnUrl=/krx/approval-list'
TARGET_URL = 'https://dataservice.koscom.co.kr/krx/approval-list'
PROFILE_PATH = 'C:\\Users\\KRX\\Desktop\\201021'
PROFILE_NAME = 'Profile 4'

# Chrome 옵션 설정
chrome_options = Options()
chrome_options.binary_location = CHROME_BINARY_PATH
chrome_options.add_argument("--disable-gpu")
chrome_options.add_argument("--no-sandbox")
chrome_options.add_argument("--start-maximized")
chrome_options.add_argument(f'user-data-dir={PROFILE_PATH}')
chrome_options.add_argument(f'profile-directory={PROFILE_NAME}')

# 기존 Chrome 작업 종료
def kill_chrome_tasks():
    try:
        subprocess.run(["taskkill", "/f", "/im", "chrome.exe"], check=True)
        print("Existing Chrome tasks terminated successfully.")
    except subprocess.CalledProcessError as e:
        print(f"Error terminating Chrome tasks: {e}")

# WebDriver 인스턴스 생성
def create_webdriver():
    service = ChromeService(executable_path=CHROMEDRIVER_PATH)
    driver = webdriver.Chrome(service=service, options=chrome_options)
    return driver

# 로그인 함수
def login(driver, app_id, app_pw):
    try:
        driver.get(LOGIN_URL)
        WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[1]/div/div/input')))
        id_box = driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[1]/div/div/input')
        password_box = driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[2]/div/div/input')
        login_button = driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[3]/button')
        id_box.send_keys(app_id)
        password_box.send_keys(app_pw)
        login_button.click()
        WebDriverWait(driver, 15).until(EC.url_to_be(TARGET_URL))
        print("[INFO] 로그인에 성공했습니다.")
    except Exception as e:
        print("[ERROR] 로그인 중 오류 발생:", traceback.format_exc())

# BeautifulSoup을 사용하여 HTML 컨텐츠 추출
def extract_data_from_html(html_content):
    soup = BeautifulSoup(html_content, 'html.parser')

    # 구조화된 데이터(테이블) 추출
    tables = soup.find_all('table')
    structured_data = []
    for table in tables:
        rows = table.find_all('tr')
        table_data = []
        for row in rows:
            cols = row.find_all(['td', 'th'])
            cols = [ele.text.strip() for ele in cols]
            table_data.append(cols)
        structured_data.append(table_data)

    # 구조화되지 않은 데이터 추출
    [s.extract() for s in soup(['style', 'script', 'table', '[document]', 'head', 'title'])]
    unstructured_data = soup.get_text(separator=' ', strip=True)

    # 전체 데이터 추출
    all_data = soup.get_text(separator=' ', strip=True)

    return all_data, structured_data, unstructured_data

# API 요청 함수
def send_api_request(url, headers):
    response = requests.get(url, headers=headers, verify=False)
    if response.status_code == 200:
        html_content = response.content.decode('utf-8')
        all_data, structured_data, unstructured_data = extract_data_from_html(html_content)
        return all_data, structured_data, unstructured_data
    else:
        print(f"[ERROR] API 요청 실패. Status Code: {response.status_code}")
        print(f"Response: {response.text}")
        return None, None, None

# 메인 실행 코드
if __name__ == "__main__":
    driver = create_webdriver()
    try:
        login(driver, 'goguma@krx.co.kr', 'wkrwjs12!@')
        time.sleep(20) # 인증 키 얻는 시간 고려
        headers = None
        for request in driver.requests:
            if 'Authorization' in request.headers:
                headers = {'Authorization': request.headers['Authorization']}
                break
        if not headers:
            print("[ERROR] Authorization 헤더를 찾을 수 없습니다.")
        else:
            YOUR_API_URL = 'https://dataservice.koscom.co.kr/apis/v1/user/approvals/100562'
            all_data, structured_data, unstructured_data = send_api_request(YOUR_API_URL, headers)
            if all_data or structured_data or unstructured_data:
                print("[INFO] 모든 데이터:", all_data)
                print("[INFO] 구조화된 데이터:", structured_data)
                print("[INFO] 구조화되지 않은 데이터:", unstructured_data)
            else:
                print("[ERROR] API 요청 실패")
    except Exception as e:
        print("[ERROR] 메인 실행 중 오류 발생:", traceback.format_exc())
    finally:
        driver.quit()  # Uncomment if you want to close the browser at the end
        print("세션을 종료하고 프로세스가 완료되었습니다.")

# %% ○ (5) + Second API 
# %% Structed / UnStructed Prints
"""
- 로그인 및 Authorization 헤더 추출의 확장: 로그인 함수는 실패 시 재로그인을 시도하고, 다시 헤더를 추출하는 로직을 포함합니다. 이는 네트워크 트래픽을 통해 Authorization 헤더를 얻는 과정을 더 견고하게 만듭니다.
- 네트워크 로그 저장: 네트워크 요청의 세부 정보를 파일로 저장하는 기능이 추가되어, 요청과 응답의 헤더를 포함한 로그를 기록합니다.
- 보다 상세한 오류 처리: 예외 발생 시 트레이스백 정보를 출력하여 오류의 원인을 더 명확하게 파악할 수 있습니다.
- 첫 번째 API 요청 실패시의 추가 처리: 첫 번째 API 요청이 실패할 경우 재로그인을 시도하여 Authorization 헤더를 다시 얻고 요청을 재시도합니다.
- 두 번째 API 요청의 헤더와 바디: 두 번째 API 요청을 위한 헤더와 바디의 세부 사항이 명시되어 있습니다.

"""
import subprocess
import json
import time
import os
import datetime
from seleniumwire import webdriver
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.common.exceptions import WebDriverException, TimeoutException
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import traceback
import requests
from bs4 import BeautifulSoup

# 설정 및 경로 정의
CHROMEDRIVER_PATH = 'C:\\Users\\KRX\\Desktop\\201021\\chromedriver-win32\\chromedriver.exe'
CHROME_BINARY_PATH = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe'
LOGIN_URL = 'https://dataservice.koscom.co.kr/login?returnUrl=/krx/approval-list'
TARGET_URL = 'https://dataservice.koscom.co.kr/krx/approval-list'
PROFILE_PATH = 'C:\\Users\\KRX\\Desktop\\201021'
PROFILE_NAME = 'Profile 4'
REFERENCE_ID = 100562  # 추가된 설정

# Chrome 옵션 설정
chrome_options = Options()
chrome_options.binary_location = CHROME_BINARY_PATH
chrome_options.add_argument("--disable-gpu")
chrome_options.add_argument("--no-sandbox")
chrome_options.add_argument("--start-maximized")
chrome_options.add_argument(f'user-data-dir={PROFILE_PATH}')
chrome_options.add_argument(f'profile-directory={PROFILE_NAME}')

# 기존 Chrome 작업 종료
def kill_chrome_tasks():
    try:
        subprocess.run(["taskkill", "/f", "/im", "chrome.exe"], check=True)
        print("Existing Chrome tasks terminated successfully.")
    except subprocess.CalledProcessError as e:
        print(f"Error terminating Chrome tasks: {e}")

# WebDriver 인스턴스 생성
def create_webdriver():
    service = ChromeService(executable_path=CHROMEDRIVER_PATH)
    driver = webdriver.Chrome(service=service, options=chrome_options)
    return driver

# 로그인 함수
def login(driver, app_id, app_pw):
    try:
        driver.get(LOGIN_URL)
        WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[1]/div/div/input')))
        id_box = driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[1]/div/div/input')
        password_box = driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[2]/div/div/input')
        login_button = driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[3]/button')
        id_box.send_keys(app_id)
        password_box.send_keys(app_pw)
        login_button.click()
        WebDriverWait(driver, 15).until(EC.url_to_be(TARGET_URL))
        print("[INFO] 로그인에 성공했습니다.")
    except TimeoutException as e:
        print("[ERROR] 이미 로그인 되었는지, 로그인 창으로 이동할 수 없습니다.")
        # print(e)
    except Exception as e:
        print("[ERROR] 로그인 중 다른 오류 발생:", traceback.format_exc())

# 로그인 및 Authorization 헤더 추출 함수
def login_and_get_auth_header(driver, app_id, app_pw):
    try:
        driver.get(LOGIN_URL)
        WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[1]/div/div/input')))
        id_box = driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[1]/div/div/input')
        password_box = driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[2]/div/div/input')
        login_button = driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[3]/button')
        id_box.send_keys(app_id)
        password_box.send_keys(app_pw)
        login_button.click()
        WebDriverWait(driver, 15).until(EC.url_to_be(TARGET_URL))

        # 로그인 후 Authorization 헤더를 추출합니다.
        new_auth_header = None
        for request in driver.requests:
            if 'Authorization' in request.headers:
                new_auth_header = request.headers['Authorization']
                break

        if new_auth_header:
            print(f"[INFO] 추출된 Authorization 헤더: {new_auth_header}")
            return new_auth_header
        else:
            print("[ERROR] Authorization 헤더를 찾을 수 없습니다.")
            return None

    except TimeoutException:
        # 이미 로그인 상태인 경우, TARGET_URL로 이동하여 재시도
        print("[INFO] 이미 로그인 상태로 확인됨. TARGET_URL로 이동하여 재시도합니다.")
        driver.get(TARGET_URL)
        time.sleep(30)  # 30초 대기
        for request in driver.requests:
            if 'Authorization' in request.headers:
                new_auth_header = request.headers['Authorization']
                print(f"[INFO] 재시도 후 얻은 Authorization 헤더: {new_auth_header}")
                return new_auth_header
        print("[ERROR] 재시도 후에도 Authorization 헤더를 얻지 못함")
        return None
    except Exception as e:
        print("[ERROR] 로그인 또는 헤더 추출 중 오류 발생:", traceback.format_exc())
        return None
        
# BeautifulSoup을 사용하여 HTML 컨텐츠 추출
def extract_data_from_html(html_content):
    soup = BeautifulSoup(html_content, 'html.parser')
    tables = soup.find_all('table')
    structured_data = []
    unstructured_data = []

    # 구조화된 데이터(테이블) 추출
    for table in tables:
        rows = table.find_all('tr')
        table_data = []

        for row in rows:
            cols = row.find_all(['td', 'th'])
            cols = [ele.text.strip() for ele in cols]
            table_data.append(cols)

        structured_data.append(table_data)

    # 구조화되지 않은 데이터 추출
    [s.extract() for s in soup(['style', 'script', '[document]', 'head', 'title'])]
    unstructured_data = soup.get_text(separator=' ', strip=True)

    return structured_data, unstructured_data

# API 요청 함수
def send_api_request(url, headers):
    response = requests.get(url, headers=headers, verify=False)
    if response.status_code == 200:
        html_content = response.content.decode('utf-8')
        structured_data, unstructured_data = extract_data_from_html(html_content)
        return response.json(), structured_data, unstructured_data
    else:
        print(f"[ERROR] API 요청 실패. Status Code: {response.status_code}")
        print(f"Response: {response.text}")
        return None, None, None

# POST 요청을 보내는 함수
def send_post_request(url, headers, body):
    try:
        response = requests.post(url, headers=headers, json=body, verify=False)  # SSL 검증 비활성화
        if response.status_code == 200:
            return response.json()
        else:
            print(f"[ERROR] POST 요청 실패. Status Code: {response.status_code}")
            print(f"Response: {response.text}")
            return None
    except Exception as e:
        print("[ERROR] POST 요청 중 오류 발생:", traceback.format_exc())
        return None
    
# 응답 데이터를 JSON 파일로 저장하는 함수
def save_response_as_json(response_data, file_path):
    with open(file_path, 'w', encoding='utf-8') as file:
        json.dump(response_data, file, ensure_ascii=False, indent=4)

# 두 번째 API 응답 데이터 분류
def classify_api_response(api_response):
    structured_data = {}   # 구조화된 데이터 저장
    unstructured_data = {} # 비구조화된 데이터 저장

    # 데이터를 적절한 구조화 또는 비구조화 범주에 할당
    for key, value in api_response.items():
        if isinstance(value, dict) or isinstance(value, list):
            structured_data[key] = value
        else:
            unstructured_data[key] = value

    return structured_data, unstructured_data

# 로그인 후 쿠키 확인 함수
def check_cookies(driver):
    cookies = driver.get_cookies()
    print("[INFO] 쿠키 정보:", cookies)

# 네트워크 로그를 파일로 저장하는 함수
def save_network_logs(driver, file_name):
    with open(file_name, 'w', encoding='utf-8') as file:
        for request in driver.requests:
            file.write(f"요청 URL: {request.url}\n")
            file.write(f"요청 헤더: {request.headers}\n")
            if 'Authorization' in request.headers:
                file.write(f"요청 Authorization 헤더: {request.headers['Authorization']}\n")
            if request.response:
                file.write(f"응답 코드: {request.response.status_code}\n")
                file.write(f"응답 헤더: {request.response.headers}\n")
                if 'Authorization' in request.response.headers:
                    file.write(f"응답 Authorization 헤더: {request.response.headers['Authorization']}\n")
            file.write("\n")

# 메인 실행 코드
if __name__ == "__main__":
    driver = create_webdriver()
    try:
        # 로그인 및 Authorization 헤더 추출
        auth_header = login_and_get_auth_header(driver, 'goguma@krx.co.kr', 'wkrwjs12!@')
        time.sleep(15)  # 로그인 후 인증 토큰 생성 대기

        if auth_header:
            print(f"[INFO] 로그인 후 얻은 Authorization 헤더: {auth_header}")
        else:
            print("[ERROR] Authorization 헤더를 얻을 수 없습니다.")
            driver.quit()
            
        headers = {'Authorization': auth_header}
        first_api_url = f'https://dataservice.koscom.co.kr/apis/v1/user/approvals/{REFERENCE_ID}'

        for request in driver.requests:
            if 'Authorization' in request.headers:
                headers = {'Authorization': request.headers['Authorization']}
                break
        if not headers:
            print("[ERROR] Authorization 헤더를 찾을 수 없습니다.")
        else:
            # 첫 번째 API 요청 실행
            first_api_response, structured_data, unstructured_data = send_api_request(first_api_url, headers)
            print(f"[INFO] 첫 번째 API 요청 헤더: {headers}")
    
            if first_api_response or structured_data or unstructured_data:
                # 첫 번째 API 응답 처리
                # print("[INFO] 첫 번째 API 응답:", first_api_response)
                # print("[INFO] 구조화된 데이터:", structured_data)
                # print("[INFO] 구조화되지 않은 데이터:", unstructured_data)
                save_response_as_json({"first_api_response": first_api_response, "structured_data": structured_data, "unstructured_data": unstructured_data}, "first_api_response.json")
            else:
                print("[ERROR] 첫 번째 API 요청 실패. 재시도를 시도합니다.")
                # 재로그인을 시도하고 다시 헤더 추출
                login(driver, 'goguma@krx.co.kr', 'wkrwjs12!@')
                time.sleep(15)
                for request in driver.requests:
                    if request.url == "https://dataservice.koscom.co.kr/apis/v1/common/auth/my-information":
                        auth_header = request.headers.get('Authorization')
                        print(f"[INFO] 첫 번째 API 요청 재시도 헤더: {auth_header}")
                        break

        # 두 번째 API 요청
        second_api_url = "https://dataservice.koscom.co.kr/apis/v1/common/snapshots/history"
        
        # Authorization, Content-Type, Accept와 같은 헤더는 대부분의 API 요청에 필수적
        second_api_headers = {
            'Host': 'dataservice.koscom.co.kr',
            'Connection': 'keep-alive',
            # 'Content-Length': '105',
            'sec-ch-ua': '"Google Chrome";v="119", "Chromium";v="119", "Not?A_Brand";v="24"',
            # 'KMBS-LANGUAGE': 'ko',
            # 'sec-ch-ua-mobile': '?0',
            'Authorization': headers['Authorization'],
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36',
            'Content-Type': 'application/json',
            'Accept': 'application/json, text/plain, */*',
            # 'KMBS-PAGEID': '300238',
            'sec-ch-ua-platform': '"Windows"',
            'Origin': 'https://dataservice.koscom.co.kr',
            'Sec-Fetch-Site': 'same-origin',
            'Sec-Fetch-Mode': 'cors',
            'Sec-Fetch-Dest': 'empty',
            'Referer': 'https://dataservice.koscom.co.kr/krx/100562/approval-detail',
            'Accept-Encoding': 'gzip, deflate, br',
            'Accept-Language': 'ko-KR,ko;q=0.9,en-US;q=0.8,en;q=0.7'
        }
        second_api_body = {
            'snapshotsLargeClassificationCode': '04',
            'snapshotsSmallClassificationCode': '04_01',
            'referenceId': REFERENCE_ID
        }

        # 두 번째 API 요청 실행
        second_api_response = send_post_request(second_api_url, second_api_headers, second_api_body)
        print(f"[INFO] 두 번째 API 요청 헤더: {second_api_headers}")

        if second_api_response:
            # print("[INFO] 두 번째 API 응답:", second_api_response)

            # 두 번째 API 응답 데이터 분류
            structured_data, unstructured_data = classify_api_response(second_api_response)
            # print("[INFO] 구조화된 데이터:", structured_data)
            # print("[INFO] 비구조화된 데이터:", unstructured_data)

            # JSON 파일로 저장
            save_response_as_json({"second_api_response": second_api_response, "structured_data": structured_data, "unstructured_data": unstructured_data}, "second_api_response.json")
            save_network_logs(driver, "network_logs_success.txt")
        else:
            print("[ERROR] 두 번째 API 요청 실패")
            save_network_logs(driver, "network_logs_fail.txt")

    except Exception as e:
        print("[ERROR] 메인 실행 중 오류 발생:", traceback.format_exc())
    finally:
        driver.quit()
        print("세션을 종료하고 프로세스가 완료되었습니다.")
        
# %% ○ (6) [Class : WebInteractionLogger] cf) tracking log using tk(Filtering 기능 추가) 
# Static Method : filter_json_responses_by_keywords
# 231118-231121 Class 化 + Filtering 추가 

import json
import time
import tkinter as tk
from threading import Thread
from seleniumwire import webdriver
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

class WebInteractionLogger:
    """
    웹 상호작용을 로깅하는 클래스입니다.
    Selenium WebDriver를 사용하여 웹 페이지와의 상호작용을 기록하고,
    결과를 로그 파일과 객체에 저장합니다.
    """
    def __init__(self, chromedriver_path, chrome_binary_path, login_url, username, password, target_url, log_file, json_log_file):
        self.chromedriver_path = chromedriver_path
        self.chrome_binary_path = chrome_binary_path
        self.login_url = login_url
        self.username = username
        self.password = password
        self.target_url = target_url
        self.log_file = log_file
        self.json_log_file = json_log_file
        self.driver = None
        self.json_responses = []
        self.recording = False

    def create_webdriver(self):
        """
        Chrome WebDriver 인스턴스를 생성합니다.
        """
        chrome_options = Options()
        chrome_options.binary_location = self.chrome_binary_path
        chrome_options.add_argument("--disable-gpu")
        chrome_options.add_argument("--no-sandbox")
        chrome_options.add_argument("--start-maximized")
        service = ChromeService(executable_path=self.chromedriver_path)
        self.driver = webdriver.Chrome(service=service, options=chrome_options)

    def login(self):
        """
        로그인 페이지에서 자동 로그인을 수행합니다.
        """
        self.driver.get(self.login_url)
        WebDriverWait(self.driver, 10).until(EC.presence_of_element_located((By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[1]/div/div/input'))).send_keys(self.username)
        WebDriverWait(self.driver, 10).until(EC.presence_of_element_located((By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[2]/div/div/input'))).send_keys(self.password)
        WebDriverWait(self.driver, 10).until(EC.presence_of_element_located((By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[3]/button'))).click()
        time.sleep(5)

    def save_interaction_log(self):
        """
        상호작용 로그를 파일과 객체에 저장합니다.
        """
        with open(self.log_file, 'w', encoding='utf-8') as file:
            for request in self.driver.requests:
                file.write(f"URL: {request.url}\n")
                file.write(f"Method: {request.method}\n")
                file.write(f"Headers: {request.headers}\n")
                if request.body:
                    file.write(f"Request Body: {request.body.decode('utf-8')}\n")
                if request.response:
                    file.write(f"Response Status: {request.response.status_code}\n")
                    file.write(f"Response Headers: {request.response.headers}\n")
                    try:
                        response_body = request.response.body.decode('utf-8')
                        file.write(f"Response Body: {response_body}\n")
                        if 'application/json' in request.response.headers.get('Content-Type', '') and self.recording:
                            json_data = json.loads(response_body)
                            self.json_responses.append({
                                'url': request.url,
                                'method': request.method,
                                'request_headers': dict(request.headers),
                                'request_body': request.body.decode('utf-8'),
                                'response_code': request.response.status_code,
                                'response_headers': dict(request.response.headers),
                                'response_body': json_data
                            })
                    except UnicodeDecodeError:
                        continue
                file.write("\n")
        self.recording = False
        self.print_json_responses()

    def print_json_responses(self):
        """
        JSON 응답을 출력합니다.
        """
        print("JSON Responses Collected:")
        for response in self.json_responses:
            print(f"URL: {response['url']}")
            print(f"Method: {response['method']}")
            print(f"Request Headers: {response['request_headers']}")
            print(f"Request Body: {response['request_body']}")
            print(f"Response Code: {response['response_code']}")
            print(f"Response Headers: {response['response_headers']}")
            print(json.dumps(response['response_body'], indent=4, ensure_ascii=False))

    @staticmethod
    def filter_json_responses_by_keywords(json_responses, wts_keywords):
        """
        주어진 키워드를 포함하는 JSON 응답을 필터링합니다.

        :param json_responses: JSON 응답 리스트
        :param wts_keywords: 필터링에 사용할 키워드 리스트
        :return: 필터링된 JSON 응답 리스트
        """
        filtered_responses = []
        for response in json_responses:
            response_str = json.dumps(response)
            if any(keyword in response_str for keyword in wts_keywords):
                filtered_responses.append(response)
        return filtered_responses



    def launch_gui(self):
        """
        tkinter GUI를 실행하여 녹화 시작 및 중지를 제어합니다.
        """
        root = tk.Tk()
        root.title("Web Interaction Logger")

        start_button = tk.Button(root, text="녹화 시작", command=self.start_recording)
        start_button.pack(pady=10)

        stop_button = tk.Button(root, text="녹화 중지 및 종료", command=self.stop_recording)
        stop_button.pack(pady=10)

        root.mainloop()

    def start_recording(self):
        """
        상호작용 녹화를 시작합니다.
        """
        self.recording = True

    def stop_recording(self):
        """
        상호작용 녹화를 중지하고 GUI를 종료합니다.
        """
        if self.recording:
            self.save_interaction_log()
            self.driver.quit()

    def run(self):
        """
        웹 상호작용 로거를 실행합니다.
        """
        self.create_webdriver()
        self.login()
        self.driver.get(self.target_url)
        gui_thread = Thread(target=self.launch_gui)
        gui_thread.start()
        gui_thread.join()

if __name__ == "__main__":
    # 설정 부분
    CHROMEDRIVER_PATH = 'C:\\Users\\KRX\\Desktop\\201021\\chromedriver-win32\\chromedriver.exe'
    CHROME_BINARY_PATH = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe'
    LOGIN_URL = 'https://dataservice.koscom.co.kr/login?returnUrl=/krx/approval-list'
    TARGET_URL = 'https://dataservice.koscom.co.kr/krx/approval-list'
    LOG_FILE = 'page_interaction.log'
    JSON_LOG_FILE = 'json_responses.json'

    logger = WebInteractionLogger(
        CHROMEDRIVER_PATH, 
        CHROME_BINARY_PATH, 
        LOGIN_URL, 
        'goguma@krx.co.kr', 
        'wkrwjs12!@', 
        TARGET_URL, 
        LOG_FILE, 
        JSON_LOG_FILE
    )
    logger.run()

    # JSON 응답 출력
    logger.print_json_responses()
    json_responses_collected = logger.json_responses

    # 필터링 실행
    wts_keywords = ["fileuuid", "total", "referenceId"]
    filtered = WebInteractionLogger.filter_json_responses_by_keywords(json_responses_collected, wts_keywords)

    # 필터링된 결과 출력
    print(json.dumps(filtered, indent=4, ensure_ascii=False))

# %% - Deepest Json responses returns
# Request URL and files 
# https://dataservice.koscom.co.kr/apis/v1/user/standard-documents/100232 (주문서 UUID 포함 - "fileUUID")
# https://dataservice.koscom.co.kr/apis/v1/user/approvals/search ( - "files", "krxFiles", about 21)
# files : UUID  
import json
import time
import tkinter as tk
from threading import Thread
from seleniumwire import webdriver
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

class WebInteractionLogger:
    """
    웹 상호작용을 로깅하는 클래스입니다.
    Selenium WebDriver를 사용하여 웹 페이지와의 상호작용을 기록하고,
    결과를 로그 파일과 객체에 저장합니다.
    """
    def __init__(self, chromedriver_path, chrome_binary_path, login_url, username, password, target_url, log_file, json_log_file):
        self.chromedriver_path = chromedriver_path
        self.chrome_binary_path = chrome_binary_path
        self.login_url = login_url
        self.username = username
        self.password = password
        self.target_url = target_url
        self.log_file = log_file
        self.json_log_file = json_log_file
        self.driver = None
        self.json_responses = []
        self.recording = False

    def create_webdriver(self):
        chrome_options = Options()
        chrome_options.binary_location = self.chrome_binary_path
        chrome_options.add_argument("--disable-gpu")
        chrome_options.add_argument("--no-sandbox")
        chrome_options.add_argument("--start-maximized")
        service = ChromeService(executable_path=self.chromedriver_path)
        self.driver = webdriver.Chrome(service=service, options=chrome_options)

    def login(self):
        self.driver.get(self.login_url)
        WebDriverWait(self.driver, 10).until(EC.presence_of_element_located((By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[1]/div/div/input'))).send_keys(self.username)
        WebDriverWait(self.driver, 10).until(EC.presence_of_element_located((By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[2]/div/div/input'))).send_keys(self.password)
        WebDriverWait(self.driver, 10).until(EC.presence_of_element_located((By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[3]/button'))).click()
        time.sleep(5)

    def save_interaction_log(self):
        with open(self.log_file, 'w', encoding='utf-8') as file:
            for request in self.driver.requests:
                file.write(f"URL: {request.url}\n")
                file.write(f"Method: {request.method}\n")
                file.write(f"Headers: {request.headers}\n")
                if request.body:
                    file.write(f"Request Body: {request.body.decode('utf-8')}\n")
                if request.response:
                    file.write(f"Response Status: {request.response.status_code}\n")
                    file.write(f"Response Headers: {request.response.headers}\n")
                    try:
                        response_body = request.response.body.decode('utf-8')
                        file.write(f"Response Body: {response_body}\n")
                        if 'application/json' in request.response.headers.get('Content-Type', '') and self.recording:
                            json_data = json.loads(response_body)
                            self.json_responses.append({
                                'url': request.url,
                                'method': request.method,
                                'request_headers': dict(request.headers),
                                'request_body': request.body.decode('utf-8'),
                                'response_code': request.response.status_code,
                                'response_headers': dict(request.response.headers),
                                'response_body': json_data
                            })
                    except UnicodeDecodeError:
                        continue
                file.write("\n")
        self.recording = False
        self.print_json_responses()

    def print_json_responses(self):
        print("JSON Responses Collected:")
        for response in self.json_responses:
            print(f"URL: {response['url']}")
            print(f"Method: {response['method']}")
            print(f"Request Headers: {response['request_headers']}")
            print(f"Request Body: {response['request_body']}")
            print(f"Response Code: {response['response_code']}")
            print(f"Response Headers: {response['response_headers']}")
            print(json.dumps(response['response_body'], indent=4, ensure_ascii=False))

    @staticmethod
    def filter_json_responses_by_keywords(json_responses, wts_keywords):
        def find_deepest_matching_entries(data, current_depth, max_depth, found_entries):
            if isinstance(data, dict):
                if any(keyword in data for keyword in wts_keywords):
                    if current_depth >= max_depth['depth']:
                        if current_depth > max_depth['depth']:
                            found_entries.clear()
                            max_depth['depth'] = current_depth
                        found_entries.append(data)
                for key, value in data.items():
                    find_deepest_matching_entries(value, current_depth + 1, max_depth, found_entries)
            elif isinstance(data, list):
                for item in data:
                    find_deepest_matching_entries(item, current_depth + 1, max_depth, found_entries)

        deepest_entries = []
        for response in json_responses:
            find_deepest_matching_entries(response, 0, {'depth': -1}, deepest_entries)
        return deepest_entries

    def launch_gui(self):
        root = tk.Tk()
        root.title("Web Interaction Logger")

        start_button = tk.Button(root, text="녹화 시작", command=self.start_recording)
        start_button.pack(pady=10)

        stop_button = tk.Button(root, text="녹화 중지 및 종료", command=self.stop_recording)
        stop_button.pack(pady=10)

        root.mainloop()

    def start_recording(self):
        self.recording = True

    def stop_recording(self):
        if self.recording:
            self.save_interaction_log()
            self.driver.quit()

    def run(self):
        self.create_webdriver()
        self.login()
        self.driver.get(self.target_url)
        gui_thread = Thread(target=self.launch_gui)
        gui_thread.start()
        gui_thread.join()

if __name__ == "__main__":
    CHROMEDRIVER_PATH = 'C:\\Users\\KRX\\Desktop\\201021\\chromedriver-win32\\chromedriver.exe'
    CHROME_BINARY_PATH = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe'
    LOGIN_URL = 'https://dataservice.koscom.co.kr/login?returnUrl=/krx/approval-list'
    TARGET_URL = 'https://dataservice.koscom.co.kr/krx/approval-list'
    LOG_FILE = 'page_interaction.log'
    JSON_LOG_FILE = 'json_responses.json'

    logger = WebInteractionLogger(
        CHROMEDRIVER_PATH, 
        CHROME_BINARY_PATH, 
        LOGIN_URL, 
        'goguma@krx.co.kr', 
        'wkrwjs12!@', 
        TARGET_URL, 
        LOG_FILE, 
        JSON_LOG_FILE
    )
    logger.run()

    logger.print_json_responses()
    json_responses_collected = logger.json_responses

    wts_keywords = ["fileUUID", "total", "referenceId", "files", "krxFiles"]
    deepest_filtered = WebInteractionLogger.filter_json_responses_by_keywords(json_responses_collected, wts_keywords)

    print(json.dumps(deepest_filtered, indent=4, ensure_ascii=False))
# %% - Only Same level Json responses returns (+Meta Info)
# Request URL and files 
# total / referenceID - For Third API Requst Header 
# https://dataservice.koscom.co.kr/apis/v1/user/approvals/search : Full Search lists
# https://dataservice.koscom.co.kr/apis/v1/user/approvals/101014 : 계약 요약 ()
# =============================================================================
# 주문서, 일반정보이용계약, 추가 첨부파일 및 숨겨진 문서(*)(files OR KrxFiles)
# * 주문 해지 요청 메일 등 
# 작업 要 : 요약서류, 계약서류, 이용조건
# =============================================================================
# https://dataservice.koscom.co.kr/apis/v1/user/standard-documents/100232 (주문서 UUID 포함 - "fileUUID")
# https://dataservice.koscom.co.kr/apis/v1/user/standard-documents/100229 ("files" 內 有 : 이용조건 - about 26)
# https://dataservice.koscom.co.kr/apis/v1/user/approvals/search ("files" 內 有:, "krxFiles" : , about 21)
# https://dataservice.koscom.co.kr/apis/v1/common/snapshots/history ("fileUUID" : 일반정보이용계약 / 주문서 / 이용조건)
# ↑ 그 외 있는 정보 : dataFeedInstallationAddressList(데이터피드 장소) / \
    # definitePromiseMatter(프로모션 여부)
    # contactPlace (고객 정보)
    #

# files : UUID  
import json
import time
import tkinter as tk
from threading import Thread
from seleniumwire import webdriver
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

class WebInteractionLogger:
    """
    Web interaction logging class using Selenium WebDriver.
    Records interactions with a web page and saves the results in log files and objects.
    """
    def __init__(self, chromedriver_path, chrome_binary_path, login_url, username, password, target_url, log_file, json_log_file):
        self.chromedriver_path = chromedriver_path
        self.chrome_binary_path = chrome_binary_path
        self.login_url = login_url
        self.username = username
        self.password = password
        self.target_url = target_url
        self.log_file = log_file
        self.json_log_file = json_log_file
        self.driver = None
        self.json_responses = []
        self.recording = False

    def create_webdriver(self):
        """
        Creates an instance of Chrome WebDriver.
        """
        chrome_options = Options()
        chrome_options.binary_location = self.chrome_binary_path
        chrome_options.add_argument("--disable-gpu")
        chrome_options.add_argument("--no-sandbox")
        chrome_options.add_argument("--start-maximized")
        service = ChromeService(executable_path=self.chromedriver_path)
        self.driver = webdriver.Chrome(service=service, options=chrome_options)

    def login(self):
        """
        Performs automatic login on the login page.
        """
        self.driver.get(self.login_url)
        WebDriverWait(self.driver, 10).until(EC.presence_of_element_located((By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[1]/div/div/input'))).send_keys(self.username)
        WebDriverWait(self.driver, 10).until(EC.presence_of_element_located((By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[2]/div/div/input'))).send_keys(self.password)
        WebDriverWait(self.driver, 10).until(EC.presence_of_element_located((By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[3]/button'))).click()
        time.sleep(5)

    def save_interaction_log(self):
        """
        Saves interaction logs to a file and object.
        """
        with open(self.log_file, 'w', encoding='utf-8') as file:
            for request in self.driver.requests:
                file.write(f"URL: {request.url}\n")
                file.write(f"Method: {request.method}\n")
                file.write(f"Headers: {request.headers}\n")
                if request.body:
                    file.write(f"Request Body: {request.body.decode('utf-8')}\n")
                if request.response:
                    file.write(f"Response Status: {request.response.status_code}\n")
                    file.write(f"Response Headers: {request.response.headers}\n")
                    try:
                        response_body = request.response.body.decode('utf-8')
                        file.write(f"Response Body: {response_body}\n")
                        if 'application/json' in request.response.headers.get('Content-Type', '') and self.recording:
                            json_data = json.loads(response_body)
                            self.json_responses.append({
                                'url': request.url,
                                'method': request.method,
                                'request_headers': dict(request.headers),
                                'request_body': request.body.decode('utf-8'),
                                'response_code': request.response.status_code,
                                'response_headers': dict(request.response.headers),
                                'response_body': json_data
                            })
                    except UnicodeDecodeError:
                        continue
                file.write("\n")
        self.recording = False
        self.print_json_responses()

    def print_json_responses(self):
        """
        Prints collected JSON responses.
        """
        print("JSON Responses Collected:")
        for response in self.json_responses:
            print(f"URL: {response['url']}")
            print(f"Method: {response['method']}")
            print(f"Request Headers: {response['request_headers']}")
            print(f"Request Body: {response['request_body']}")
            print(f"Response Code: {response['response_code']}")
            print(f"Response Headers: {response['response_headers']}")
            print(json.dumps(response['response_body'], indent=4, ensure_ascii=False))

    @staticmethod
    def filter_json_responses_by_keywords(json_responses, wts_keywords):
        def find_matching_entries(data, keywords):
            if isinstance(data, dict):
                if any(keyword in data for keyword in keywords):
                    return [data]
                else:
                    matching_entries = []
                    for value in data.values():
                        matching_entries.extend(find_matching_entries(value, keywords))
                    return matching_entries
            elif isinstance(data, list):
                matching_entries = []
                for item in data:
                    matching_entries.extend(find_matching_entries(item, keywords))
                return matching_entries
            return []
        
        # JSON 응답 필터링
        filtered_responses = []
        for response in json_responses:
            matches = find_matching_entries(response['response_body'], wts_keywords)
            for match in matches:
                filtered_response = {
                    'url': response['url'],
                    'method': response['method'],
                    'request_headers': response['request_headers'],
                    'request_body': response['request_body'],
                    'response_code': response['response_code'],
                    'response_headers': response['response_headers'],
                    'response_body': match  # 여기서 match는 wts_keywords에 해당하는 항목만 포함
                }
                filtered_responses.append(filtered_response)
        return filtered_responses
    
    def launch_gui(self):
        """
        Launches a tkinter GUI to control the start and stop of recording.
        """
        root = tk.Tk()
        root.title("Web Interaction Logger")

        start_button = tk.Button(root, text="Start Recording", command=self.start_recording)
        start_button.pack(pady=10)

        stop_button = tk.Button(root, text="Stop Recording and Exit", command=self.stop_recording)
        stop_button.pack(pady=10)

        root.mainloop()

    def start_recording(self):
        """
        Starts recording interactions.
        """
        self.recording = True

    def stop_recording(self):
        """
        Stops recording interactions and exits the GUI.
        """
        if self.recording:
            self.save_interaction_log()
            self.driver.quit()

    def run(self):
        """
        Runs the web interaction logger.
        """
        self.create_webdriver()
        self.login()
        self.driver.get(self.target_url)
        gui_thread = Thread(target=self.launch_gui)
        gui_thread.start()
        gui_thread.join()

if __name__ == "__main__":
    # Configuration
    CHROMEDRIVER_PATH = 'C:\\Users\\KRX\\Desktop\\201021\\chromedriver-win32\\chromedriver.exe'
    CHROME_BINARY_PATH = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe'
    LOGIN_URL = 'https://dataservice.koscom.co.kr/login?returnUrl=/krx/approval-list'
    TARGET_URL = 'https://dataservice.koscom.co.kr/krx/approval-list'
    LOG_FILE = 'page_interaction.log'
    JSON_LOG_FILE = 'json_responses.json'

    # Initialize and run the logger
    logger = WebInteractionLogger(
        CHROMEDRIVER_PATH, 
        CHROME_BINARY_PATH, 
        LOGIN_URL, 
        'goguma@krx.co.kr', 
        'wkrwjs12!@', 
        TARGET_URL, 
        LOG_FILE, 
        JSON_LOG_FILE
    )
    logger.run()

    # Print collected JSON responses
    logger.print_json_responses()
    json_responses_collected = logger.json_responses
    # 필터링 실행
    wts_keywords = ["fileUUID", "krxFiles", "files"]
    filtered = WebInteractionLogger.filter_json_responses_by_keywords(json_responses_collected, wts_keywords)

    # 추가 필터링: 비어있는 리스트를 포함하지 않는 항목만 선택
    extra_filtered = []
    for response in filtered:
        for key in wts_keywords:
            # 키워드에 해당하는 항목이 존재하고, 그 값이 비어있지 않은 경우에만 추가
            if key in response['response_body'] and response['response_body'][key]:
                extra_filtered.append({
                    key: response['response_body'][key],
                    'request_details': {
                        'url': response['url'],
                        'method': response['method'],
                        'headers': response['request_headers'],
                        'body': response['request_body']
                    }
                })

    # 필터링된 결과 출력
    print(json.dumps(extra_filtered, indent=4, ensure_ascii=False))

# %% ○ (7) [FileDownloader] File downloads With uuid 
# %% - Hard Coding Ex Ver. 
# 파일 UUID는 하드코딩되어 있으며, 사용자가 이를 지정해야 합니다.
# download_file 함수는 파일을 다운로드할 때 고정된 파일 이름 (downloaded_file.pdf)을 사용합니다.
# 이 코드는 특정 파일 UUID에 대해 파일을 다운로드하는 간단한 로직을 포함합니다.

import time
from seleniumwire import webdriver
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import urllib3

class FileDownloader:
    def __init__(self, chromedriver_path, chrome_binary_path, login_url):
        self.chromedriver_path = chromedriver_path
        self.chrome_binary_path = chrome_binary_path
        self.login_url = login_url
        urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

    def create_webdriver(self):
        chrome_options = Options()
        chrome_options.binary_location = self.chrome_binary_path
        chrome_options.add_argument("--start-maximized")
        service = ChromeService(executable_path=self.chromedriver_path)
        return webdriver.Chrome(service=service, options=chrome_options)

    def login(self, driver, username, password):
        driver.get(self.login_url)
        WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[1]/div/div/input'))).send_keys(username)
        WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[2]/div/div/input'))).send_keys(password)
        WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[3]/button'))).click()
        time.sleep(5)

    def download_file(self, file_uuid, auth_token, save_path):
        base_url = "https://dataservice.koscom.co.kr"
        download_url = f"{base_url}/apis/v1/common/files?fileUUID={file_uuid}"
        headers = {'Authorization': auth_token}
        
        response = requests.get(download_url, headers=headers, verify=False)
        if response.status_code == 200:
            with open(save_path, 'wb') as file:
                file.write(response.content)
            print(f"File downloaded successfully and saved as {save_path}")
        else:
            print(f"Failed to download file: Status code {response.status_code}, Response: {response.text}")

if __name__ == "__main__":
    file_downloader = FileDownloader(
        'C:\\Users\\KRX\\Desktop\\201021\\chromedriver-win32\\chromedriver.exe',
        'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
        'https://dataservice.koscom.co.kr/login?returnUrl=/krx/approval-list'
    )

    driver = file_downloader.create_webdriver()
    try:
        file_downloader.login(driver, 'goguma@krx.co.kr', 'wkrwjs12!@')
        time.sleep(10)  # 인증 토큰 생성 대기

        auth_header = None
        for request in driver.requests:
            if 'Authorization' in request.headers:
                auth_header = request.headers['Authorization']
                break

        if auth_header:
            file_uuid = "1df807dc-9e8d-4698-9581-383f484f7a42.pdf"  # 예시 UUID
            save_path = "downloaded_file.pdf"  # 저장할 파일 경로
            file_downloader.download_file(file_uuid, auth_header, save_path)
        else:
            print("Failed to obtain Authorization header")

    except Exception as e:
        print(f"[ERROR] 메인 실행 중 오류 발생: {e}")
    finally:
        driver.quit()

# %% - Json Response Ver. 
# ① extra_filtered 가 선 정의되어야함
# 파일 정보를 JSON 응답에서 추출하여 파일 UUID와 fileSubject를 활용합니다.
# collect_file_info 함수는 JSON 응답을 파싱하여 파일 UUID와 fileSubject를 추출합니다.
# download_file 함수는 fileSubject를 파일 이름으로 사용하여 파일을 다운로드합니다.
# 이 코드는 JSON 응답에서 특정 데이터를 추출하고 이를 기반으로 파일 이름을 결정합니다.

# ② Snapshot Data로부터 UUID 추출 Ver 
import requests
import time
from seleniumwire import webdriver
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import urllib3
import json

class FileDownloader:
    def __init__(self, chromedriver_path, chrome_binary_path, login_url):
        self.chromedriver_path = chromedriver_path
        self.chrome_binary_path = chrome_binary_path
        self.login_url = login_url
        urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

    def create_webdriver(self):
        chrome_options = Options()
        chrome_options.binary_location = self.chrome_binary_path
        chrome_options.add_argument("--start-maximized")
        service = ChromeService(executable_path=self.chromedriver_path)
        return webdriver.Chrome(service=service, options=chrome_options)

    def login(self, driver, username, password):
        driver.get(self.login_url)
        WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[1]/div/div/input'))).send_keys(username)
        WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[2]/div/div/input'))).send_keys(password)
        WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[3]/button'))).click()
        time.sleep(5)

    def download_file(self, file_uuid, file_name, auth_token):
        base_url = "https://dataservice.koscom.co.kr"
        download_url = f"{base_url}/apis/v1/common/files?fileUUID={file_uuid}"
        headers = {'Authorization': auth_token}
        
        response = requests.get(download_url, headers=headers, verify=False)
        if response.status_code == 200:
            save_path = f"{file_name}.pdf"
            with open(save_path, 'wb') as file:
                file.write(response.content)
            print(f"File downloaded successfully and saved as {save_path}")
        else:
            print(f"Failed to download file: Status code {response.status_code}, Response: {response.text}")

    def collect_file_info_from_extra_filtered(self, extra_filtered):
        file_info = []
        for response in extra_filtered:
            for file_group in ['krxFiles', 'files']:
                for file in response.get(file_group, []):
                    file_uuid = file.get('fileUUID')
                    file_name = file.get('fileMapping', {}).get('fileSubject', 'Unnamed')
                    if file_uuid and file_name:
                        file_info.append({
                            'file_uuid': file_uuid,
                            'file_name': file_name
                        })
        return file_info

    def collect_file_info_from_json(self, json_data):
        file_info = []
        for item in json_data:
            file_uuid = item.get('fileUUID')
            file_name = item.get('originalFileName', 'Unnamed').split('.')[0]  # 파일 이름에서 확장자 제거
            if file_uuid and file_name:
                file_info.append({
                    'file_uuid': file_uuid,
                    'file_name': file_name
                })
        return file_info

if __name__ == "__main__":
    file_downloader = FileDownloader(
        'C:\\Users\\KRX\\Desktop\\201021\\chromedriver-win32\\chromedriver.exe',
        'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
        'https://dataservice.koscom.co.kr/login?returnUrl=/krx/approval-list'
    )

    driver = file_downloader.create_webdriver()
    try:
        file_downloader.login(driver, 'goguma@krx.co.kr', 'wkrwjs12!@')
        time.sleep(10)  # 인증 토큰 생성 대기

        auth_header = None
        for request in driver.requests:
            if 'Authorization' in request.headers:
                auth_header = request.headers['Authorization']
                break

        if auth_header:
            # 여기서 extra_filtered 는 이전에 수집한 JSON 응답 데이터입니다.
            json_responses = extra_filtered.copy()
            file_info_list = file_downloader.collect_file_info_from_extra_filtered(json_responses)

            # 추가된 JSON 응답 데이터 처리 로직
            json_data = [...]  # JSON 데이터를 여기에 할당
            file_info_list.extend(file_downloader.collect_file_info_from_json(json_data))

            for file_info in file_info_list:
                file_downloader.download_file(file_info['file_uuid'], file_info['file_name'], auth_header)
        else:
            print("Failed to obtain Authorization header")

    except Exception as e:
        print(f"[ERROR] 메인 실행 중 오류 발생: {e}")
    finally:
        driver.quit()

# %% - EX) File downloads (Working Good)
import requests
import time
from seleniumwire import webdriver
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# 설정 및 경로 정의
CHROMEDRIVER_PATH = 'C:\\Users\\KRX\\Desktop\\201021\\chromedriver-win32\\chromedriver.exe'
CHROME_BINARY_PATH = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe'
LOGIN_URL = 'https://dataservice.koscom.co.kr/login?returnUrl=/krx/approval-list'

# Chrome 옵션 설정
chrome_options = Options()
chrome_options.binary_location = CHROME_BINARY_PATH
chrome_options.add_argument("--start-maximized")

# WebDriver 인스턴스 생성 함수
def create_webdriver():
    service = ChromeService(executable_path=CHROMEDRIVER_PATH)
    driver = webdriver.Chrome(service=service, options=chrome_options)
    return driver

# 로그인 함수
def login(driver, username, password):
    driver.get(LOGIN_URL)
    WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[1]/div/div/input'))).send_keys(username)
    WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[2]/div/div/input'))).send_keys(password)
    WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[3]/button'))).click()
    time.sleep(5)

# 파일 다운로드 함수
def download_file(file_uuid, auth_token, save_path):
    """
    파일을 다운로드하는 함수

    :param file_uuid: 파일의 UUID
    :param auth_token: 인증 토큰 (Authorization header)
    :param save_path: 파일을 저장할 경로
    """
    base_url = "https://dataservice.koscom.co.kr"
    download_url = f"{base_url}/apis/v1/common/files?fileUUID={file_uuid}"

    headers = {'Authorization': auth_token}
    
    response = requests.get(download_url, headers=headers, verify=False)
    if response.status_code == 200:
        with open(save_path, 'wb') as file:
            file.write(response.content)
        print(f"File downloaded successfully and saved as {save_path}")
    else:
        print(f"Failed to download file: Status code {response.status_code}, Response: {response.text}")

# 메인 실행 코드
if __name__ == "__main__":
    driver = create_webdriver()
    try:
        login(driver, 'goguma@krx.co.kr', 'wkrwjs12!@')
        time.sleep(10)  # 인증 토큰 생성 대기

        # Authorization 헤더 추출
        auth_header = None
        for request in driver.requests:
            if 'Authorization' in request.headers:
                auth_header = request.headers['Authorization']
                break

        if auth_header:
            # 여기에 파일 UUID를 입력하세요
            file_uuid = "1df807dc-9e8d-4698-9581-383f484f7a42.pdf"  # JSON 응답에서 가져온 fileUUID
            save_path = "downloaded_file.pdf"  # 저장할 파일 이름

            # 파일 다운로드 및 저장
            download_file(file_uuid, auth_header, save_path)
        else:
            print("Failed to obtain Authorization header")

    except Exception as e:
        print(f"[ERROR] 메인 실행 중 오류 발생: {e}")
    finally:
        driver.quit()

# %% ○ (8) API 호출 
# %% - 231118 0030 cf) 셀레니움을 이용한 웹 페이지 네트워크 요청 캡처 및 분석 도구 (two pages, Filter)
import json
import time
from seleniumwire import webdriver
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By

# 설정 및 경로 정의
CHROMEDRIVER_PATH = 'C:\\Users\\KRX\\Desktop\\201021\\chromedriver-win32\\chromedriver.exe'
CHROME_BINARY_PATH = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe'
TARGET_URL = 'https://dataservice.koscom.co.kr/krx/approval-list'
JSON_LOG_FILE = 'referenceId_responses.json'
# WTS_keywords = 'referenceId' # URL 을 구성하는 숫자이자 Requset Header 에 쓰이는 Reference ID 
WTS_keywords = 'total' # 3rd API 의 request_body 에 포함된 
WTS_keywords = 'fileuuid' # 3rd API 의 request_body 에 포함된 

# Chrome 옵션 설정
chrome_options = Options()
chrome_options.binary_location = CHROME_BINARY_PATH
chrome_options.add_argument("--disable-gpu")
chrome_options.add_argument("--no-sandbox")
chrome_options.add_argument("--start-maximized")

# WebDriver 인스턴스 생성 함수
def create_webdriver():
    service = ChromeService(executable_path=CHROMEDRIVER_PATH)
    driver = webdriver.Chrome(service=service, options=chrome_options)
    driver.implicitly_wait(10)  # Implicit Wait 설정 (예: 10초)
    return driver

# JSON 응답 필터링 및 저장 함수 정의
def filter_and_save_json_responses(driver):
    referenceId_responses = []
    json_data_collected = []
    for request in driver.requests:
        if request.response and 'application/json' in request.response.headers.get('Content-Type', ''):
            try:
                json_data = json.loads(request.response.body.decode('utf-8'))
                response_info = {
                    'request_url': request.url,
                    'request_method': request.method,
                    'request_headers': dict(request.headers),
                    'response_code': request.response.status_code,
                    'response_headers': dict(request.response.headers),
                    'response_body': json_data
                }
                json_data_collected.append(response_info)
                if WTS_keywords in json.dumps(json_data):
                    referenceId_responses.append(response_info)
            except (json.JSONDecodeError, UnicodeDecodeError):
                continue

    with open(JSON_LOG_FILE, 'w', encoding='utf-8') as file:
        json.dump(referenceId_responses, file, ensure_ascii=False, indent=4)

    return referenceId_responses, json_data_collected

# 특정 요소 클릭 후 JSON 응답 필터링 함수 정의
# (2 Page 로 이동시에 변화를 보기 위함)
def filter_responses_after_click(driver, xpath, last_request_index):
    element_to_click = driver.find_element(By.XPATH, xpath)
    element_to_click.click()

    time.sleep(30)  # 네트워크 트래픽 대기

    referenceId_responses_temp = []
    for request in driver.requests[last_request_index:]:
        if request.response and 'application/json' in request.response.headers.get('Content-Type', ''):
            try:
                request_body = request.body.decode('utf-8') if request.body else None
                json_data = json.loads(request.response.body.decode('utf-8'))
                if WTS_keywords in json.dumps(json_data):
                    response_info = {
                        'request_url': request.url,
                        'request_method': request.method,
                        'request_body': request_body,  # 요청 본문 추가
                        'request_headers': dict(request.headers),
                        'response_code': request.response.status_code,
                        'response_headers': dict(request.response.headers),
                        'response_body': json_data
                    }
                    referenceId_responses_temp.append(response_info)
            except (json.JSONDecodeError, UnicodeDecodeError):
                continue
    return referenceId_responses_temp

# 메인 실행 코드
if __name__ == "__main__":
    driver = create_webdriver()
    try:
        login(driver, 'goguma@krx.co.kr', 'wkrwjs12!@')

        driver.get(TARGET_URL)
        time.sleep(10)  # 페이지 로드 대기

        # 첫 번째 요청 필터링 및 저장
        referenceId_responses, json_data_collected = filter_and_save_json_responses(driver)

        # 클릭 이벤트 전 마지막 요청의 인덱스 저장
        last_request_index = len(driver.requests)

        # XPath에 해당하는 요소 클릭 후 두 번째 요청 필터링 및 저장
        referenceId_responses_2_temp = filter_responses_after_click(driver, "/html/body/div[1]/div[2]/div[3]/div[2]/div[3]/div/ul/li[2]", last_request_index)

        # 필터링된 응답과 모든 JSON 데이터 출력
        print(f"Filtered Responses with {WTS_keywords}:")
        for response in referenceId_responses:
            print(json.dumps(response, indent=4, ensure_ascii=False))

        print("\nAll JSON Data Collected:")
        for data in json_data_collected:
            print(json.dumps(data, indent=4, ensure_ascii=False))

        print("\nFiltered Responses After Click:")
        for data in referenceId_responses_2_temp:
            print(json.dumps(data, indent=4, ensure_ascii=False))

    except Exception as e:
        print(f"[ERROR] 메인 실행 중 오류 발생: {e}")
    finally:
        driver.quit()


# %% - cf) PDF 저장 
import pdfkit
import os

# wkhtmltopdf의 설치 경로 (Windows 환경)
wkhtmltopdf_path = r'C:\Program Files (x86)\wkhtmltopdf\bin\wkhtmltopdf.exe'

# pdfkit 설정에 wkhtmltopdf 경로 지정
config = pdfkit.configuration(wkhtmltopdf=wkhtmltopdf_path)

# 변환할 웹페이지 URL
url = 'https://nasdaqtrader.com/Trader.aspx?id=PriceListTrading2'

# PDF 파일이 저장될 경로
pdf_path = os.path.join(os.path.expanduser('~'), 'nasdaq_trading_price_list.pdf')

# URL을 PDF로 변환하여 저장
pdfkit.from_url(url, pdf_path, configuration=config)

print(f'PDF saved to {pdf_path}')

# %% - 231123 0100 Full API Request codes (Third API added)
# ○ 첫 번째 API 요청 (First API Request):
# - URL: first_api_url = f'https://dataservice.koscom.co.kr/apis/v1/user/approvals/{REFERENCE_ID}'
# - 기능: 로그인 후 Authorization 헤더를 추출하고, 첫 번째 API URL로 GET 요청을 보내 응답 데이터에서 total 및 totalPage 값을 추출합니다.
# - 데이터 처리: 응답 데이터는 구조화된 데이터(structured_data)와 구조화되지 않은 데이터(unstructured_data)로 분류하여 처리합니다.
# - 저장: 응답 데이터를 "first_api_response.json" 파일로 저장합니다.

# ○ 두 번째 API 요청 (Second API Request):
# - URL: second_api_url = "https://dataservice.koscom.co.kr/apis/v1/common/snapshots/history"
# - 기능: 두 번째 API URL로 POST 요청을 보냅니다. 이 요청은 headers와 body가 필요합니다.
# - 데이터 처리: 응답 데이터를 다시 구조화 및 비구조화 데이터로 분류합니다.
# - 저장: 결과는 "second_api_response.json" 파일로 저장합니다.
# - 로깅: 성공 또는 실패 시 네트워크 로그를 파일로 저장합니다.

# ○ 세 번째 (새로운) API 요청 (Third API Request):
# - URL: third_api_url = "https://dataservice.koscom.co.kr/apis/v1/user/approvals/search"
# - 기능: 세 번째 API URL에 POST 요청을 보내고, 첫 번째 API 요청에서 추출한 total 및 totalPage 값을 요청 본문(third_api_body)에 포함시킵니다.
# - 데이터 처리: 응답 데이터를 다시 구조화 및 비구조화 데이터로 분류합니다.
# - 저장: 응답 데이터를 "third_api_response.json" 파일로 저장합니다.

import subprocess
import json
import time
import os
import datetime
from seleniumwire import webdriver
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.common.exceptions import WebDriverException, TimeoutException
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import traceback
import requests
from bs4 import BeautifulSoup
import urllib3

# SSL 경고 비활성화 (개발 환경에서만 사용)
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


# 설정 및 경로 정의
CHROMEDRIVER_PATH = 'C:\\Users\\KRX\\Desktop\\201021\\chromedriver-win32\\chromedriver.exe'
CHROME_BINARY_PATH = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe'
LOGIN_URL = 'https://dataservice.koscom.co.kr/login?returnUrl=/krx/approval-list'
TARGET_URL = 'https://dataservice.koscom.co.kr/krx/approval-list'
PROFILE_PATH = 'C:\\Users\\KRX\\Desktop\\201021'
PROFILE_NAME = 'Profile 4'
REFERENCE_ID = 100562  # 추가된 설정

# Chrome 옵션 설정
chrome_options = Options()
chrome_options.binary_location = CHROME_BINARY_PATH
chrome_options.add_argument("--disable-gpu")
chrome_options.add_argument("--no-sandbox")
chrome_options.add_argument("--start-maximized")
chrome_options.add_argument(f'user-data-dir={PROFILE_PATH}')
chrome_options.add_argument(f'profile-directory={PROFILE_NAME}')

# 기존 Chrome 작업 종료
def kill_chrome_tasks():
    try:
        subprocess.run(["taskkill", "/f", "/im", "chrome.exe"], check=True)
        print("Existing Chrome tasks terminated successfully.")
    except subprocess.CalledProcessError as e:
        print(f"Error terminating Chrome tasks: {e}")

# WebDriver 인스턴스 생성
def create_webdriver():
    service = ChromeService(executable_path=CHROMEDRIVER_PATH)
    driver = webdriver.Chrome(service=service, options=chrome_options)
    return driver

# 로그인 함수
def login(driver, app_id, app_pw):
    try:
        driver.get(LOGIN_URL)
        WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[1]/div/div/input')))
        id_box = driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[1]/div/div/input')
        password_box = driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[2]/div/div/input')
        login_button = driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[3]/button')
        id_box.send_keys(app_id)
        password_box.send_keys(app_pw)
        login_button.click()
        WebDriverWait(driver, 15).until(EC.url_to_be(TARGET_URL))
        print("[INFO] 로그인에 성공했습니다.")
    except TimeoutException as e:
        print("[ERROR] 이미 로그인 되었는지, 로그인 창으로 이동할 수 없습니다.")
        # print(e)
    except Exception as e:
        print("[ERROR] 로그인 중 다른 오류 발생:", traceback.format_exc())
        
# BeautifulSoup을 사용하여 HTML 컨텐츠 추출
def extract_data_from_html(html_content):
    soup = BeautifulSoup(html_content, 'html.parser')
    tables = soup.find_all('table')
    structured_data = []
    unstructured_data = []

    # 구조화된 데이터(테이블) 추출
    for table in tables:
        rows = table.find_all('tr')
        table_data = []

        for row in rows:
            
            cols = row.find_all(['td', 'th'])
            cols = [ele.text.strip() for ele in cols]
            table_data.append(cols)

        structured_data.append(table_data)

    # 구조화되지 않은 데이터 추출
    [s.extract() for s in soup(['style', 'script', '[document]', 'head', 'title'])]
    unstructured_data = soup.get_text(separator=' ', strip=True)

    return structured_data, unstructured_data

# API 요청 함수
def send_api_request(url, headers):
    response = requests.get(url, headers=headers, verify=False)
    if response.status_code == 200:
        html_content = response.content.decode('utf-8')
        structured_data, unstructured_data = extract_data_from_html(html_content)
        return response.json(), structured_data, unstructured_data
    else:
        print(f"[ERROR] API 요청 실패. Status Code: {response.status_code}")
        print(f"Response: {response.text}")
        return None, None, None

# POST 요청을 보내는 함수
def send_post_request(url, headers, body):
    try:
        response = requests.post(url, headers=headers, json=body, verify=False)  # SSL 검증 비활성화
        if response.status_code == 200:
            return response.json()
        else:
            print(f"[ERROR] POST 요청 실패. Status Code: {response.status_code}")
            print(f"Response: {response.text}")
            return None
    except Exception as e:
        print("[ERROR] POST 요청 중 오류 발생:", traceback.format_exc())
        return None
    
# 응답 데이터를 JSON 파일로 저장하는 함수
def save_response_as_json(response_data, file_path):
    with open(file_path, 'w', encoding='utf-8') as file:
        json.dump(response_data, file, ensure_ascii=False, indent=4)

# 두 번째 API 응답 데이터 분류
def classify_api_response(api_response):
    structured_data = {}   # 구조화된 데이터 저장
    unstructured_data = {} # 비구조화된 데이터 저장

    # 데이터를 적절한 구조화 또는 비구조화 범주에 할당
    for key, value in api_response.items():
        if isinstance(value, dict) or isinstance(value, list):
            structured_data[key] = value
        else:
            unstructured_data[key] = value

    return structured_data, unstructured_data

# 로그인 후 쿠키 확인 함수
def check_cookies(driver):
    cookies = driver.get_cookies()
    print("[INFO] 쿠키 정보:", cookies)

# 네트워크 로그를 파일로 저장하는 함수
def save_network_logs(driver, file_name):
    with open(file_name, 'w', encoding='utf-8') as file:
        for request in driver.requests:
            file.write(f"요청 URL: {request.url}\n")
            file.write(f"요청 헤더: {request.headers}\n")
            if 'Authorization' in request.headers:
                file.write(f"요청 Authorization 헤더: {request.headers['Authorization']}\n")
            if request.response:
                file.write(f"응답 코드: {request.response.status_code}\n")
                file.write(f"응답 헤더: {request.response.headers}\n")
                if 'Authorization' in request.response.headers:
                    file.write(f"응답 Authorization 헤더: {request.response.headers['Authorization']}\n")
            file.write("\n")

# 새로운 POST 요청을 보내는 함수
def send_third_api_request(url, headers, body):
    try:
        response = requests.post(url, headers=headers, json=body, verify=False)
        if response.status_code == 200:
            html_content = response.content.decode('utf-8')
            structured_data, unstructured_data = extract_data_from_html(html_content)
            return response.json(), structured_data, unstructured_data
        else:
            print(f"[ERROR] 새로운 POST 요청 실패. Status Code: {response.status_code}")
            print(f"Response: {response.text}")
            return None, None, None
    except Exception as e:
        print("[ERROR] 새로운 POST 요청 중 오류 발생:", traceback.format_exc())
        return None, None, None

# 메인 실행 코드
if __name__ == "__main__":
    driver = create_webdriver()
    try:
        login(driver, 'goguma@krx.co.kr', 'wkrwjs12!@')
        time.sleep(15)  # 로그인 후 인증 토큰 생성 대기
        
        # Authorization 헤더 추출
        auth_header = None
        for request in driver.requests:
            if request.url == "https://dataservice.koscom.co.kr/apis/v1/common/auth/my-information":
                auth_header = request.headers.get('Authorization')
                print(f"[INFO] 로그인 후 얻은 Authorization 헤더: {auth_header}")
                break

        if not auth_header:
            print("[ERROR] Authorization 헤더를 찾을 수 없습니다.")
            driver.quit()
            
        headers = {'Authorization': auth_header}
# =============================================================================
#             # 첫 번째 API 요청 실행
# =============================================================================

        first_api_url = f'https://dataservice.koscom.co.kr/apis/v1/user/approvals/{REFERENCE_ID}'

        for request in driver.requests:
            if 'Authorization' in request.headers:
                headers = {'Authorization': request.headers['Authorization']}
                break
        if not headers:
            print("[ERROR] Authorization 헤더를 찾을 수 없습니다.")
        else:
            first_api_response, structured_data, unstructured_data = send_api_request(first_api_url, headers)
            # print(f"[INFO] 첫 번째 API 요청 헤더: {headers}")
    
            if first_api_response or structured_data or unstructured_data:
                # 첫 번째 API 응답 처리
                print("[INFO] 첫 번째 API 응답:", first_api_response)
                print("[INFO] 구조화된 데이터:", structured_data)
                # print("[INFO] 구조화되지 않은 데이터:", unstructured_data)
                save_response_as_json({"first_api_response": first_api_response, "structured_data": structured_data, "unstructured_data": unstructured_data}, "first_api_response.json")
                # 첫 번째 API 응답에서 total 및 totalPage 추출
                total = first_api_response.get("page", {}).get("total", 0)
                totalPage = first_api_response.get("page", {}).get("totalPage", 0)

            else:
                print("[ERROR] 첫 번째 API 요청 실패. 재시도를 시도합니다.")
                # 재로그인을 시도하고 다시 헤더 추출
                login(driver, 'goguma@krx.co.kr', 'wkrwjs12!@')
                time.sleep(15)
                for request in driver.requests:
                    if request.url == "https://dataservice.koscom.co.kr/apis/v1/common/auth/my-information":
                        auth_header = request.headers.get('Authorization')
                        # print(f"[INFO] 첫 번째 API 요청 재시도 헤더: {auth_header}")
                        break

# =============================================================================
#         # 두 번째 API 요청
# =============================================================================
        second_api_url = "https://dataservice.koscom.co.kr/apis/v1/common/snapshots/history"
        
        # Authorization, Content-Type, Accept와 같은 헤더는 대부분의 API 요청에 필수적
        second_api_headers = {
            'Host': 'dataservice.koscom.co.kr',
            'Connection': 'keep-alive',
            # 'Content-Length': '105',
            'sec-ch-ua': '"Google Chrome";v="119", "Chromium";v="119", "Not?A_Brand";v="24"',
            # 'KMBS-LANGUAGE': 'ko',
            # 'sec-ch-ua-mobile': '?0',
            'Authorization': headers['Authorization'],
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36',
            'Content-Type': 'application/json',
            'Accept': 'application/json, text/plain, */*',
            # 'KMBS-PAGEID': '300238',
            'sec-ch-ua-platform': '"Windows"',
            'Origin': 'https://dataservice.koscom.co.kr',
            'Sec-Fetch-Site': 'same-origin',
            'Sec-Fetch-Mode': 'cors',
            'Sec-Fetch-Dest': 'empty',
            'Referer': 'https://dataservice.koscom.co.kr/krx/100562/approval-detail',
            'Accept-Encoding': 'gzip, deflate, br',
            'Accept-Language': 'ko-KR,ko;q=0.9,en-US;q=0.8,en;q=0.7'
        }
        second_api_body = {
            'snapshotsLargeClassificationCode': '04',
            'snapshotsSmallClassificationCode': '04_01',
            'referenceId': REFERENCE_ID
        }

        # 두 번째 API 요청 실행
        second_api_response = send_post_request(second_api_url, second_api_headers, second_api_body)
        # print(f"[INFO] 두 번째 API 요청 헤더: {second_api_headers}")

        if second_api_response:
            # print("[INFO] 두 번째 API 응답:", second_api_response)

            # 두 번째 API 응답 데이터 분류
            structured_data, unstructured_data = classify_api_response(second_api_response)
            # print("[INFO] 구조화된 데이터:", structured_data)
            # print("[INFO] 비구조화된 데이터:", unstructured_data)

            # JSON 파일로 저장
            save_response_as_json({"second_api_response": second_api_response, "structured_data": structured_data, "unstructured_data": unstructured_data}, "second_api_response.json")
            save_network_logs(driver, "network_logs_success.txt")
        else:
            print("[ERROR] 두 번째 API 요청 실패")
            save_network_logs(driver, "network_logs_fail.txt")

# =============================================================================
#         # 새로운(third) API 요청 및 응답 처리
# =============================================================================
        pageNumber = 0
        third_api_url = "https://dataservice.koscom.co.kr/apis/v1/user/approvals/search"
        third_api_body = {
            "startDate": "",
            "endDate": "",
            "sanctionTypeCode": "",
            "approvalStatusCode": "",
            "ordersSectionCode": "",
            "searchType": "SUBJECT",
            "searchText": "",
            "page": {
                "pageNumber": pageNumber, 
                "pageSize": 10,
                "total": total,   # 첫 번째 API 응답에서 추출한 total 값
                "totalPage": totalPage  # 첫 번째 API 응답에서 추출한 totalPage 값
            }
        }
        third_api_response, structured_data, unstructured_data = send_third_api_request(third_api_url, headers, third_api_body)
        if third_api_response or structured_data or unstructured_data:
            save_response_as_json({"third_api_response": third_api_response, "structured_data": structured_data, "unstructured_data": unstructured_data}, "third_api_response.json")
        else:
            print("[ERROR] 새로운 API 요청 실패")


    except Exception as e:
        print("[ERROR] 메인 실행 중 오류 발생:", traceback.format_exc())
    finally:
        driver.quit()
        print("세션을 종료하고 프로세스가 완료되었습니다")

# %% - 231127 1600 Refactoring Ver.
import requests
from seleniumwire import webdriver
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException
from bs4 import BeautifulSoup
import json
import traceback
import time
from tqdm import tqdm

class APIManager:
    def __init__(self):
        self.CHROMEDRIVER_PATH = 'C:\\Users\\KRX\\Desktop\\201021\\chromedriver-win32\\chromedriver.exe'
        self.CHROME_BINARY_PATH = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe'
        self.LOGIN_URL = 'https://dataservice.koscom.co.kr/login?returnUrl=/krx/approval-list'
        self.TARGET_URL = 'https://dataservice.koscom.co.kr/krx/approval-list'
        self.PROFILE_PATH = 'C:\\Users\\KRX\\Desktop\\201021'
        self.PROFILE_NAME = 'Profile 4'
        self.REFERENCE_ID = 100562
        self.driver = self.create_webdriver()
        self.all_responses = {}

    def create_webdriver(self):
        chrome_options = Options()
        chrome_options.binary_location = self.CHROME_BINARY_PATH
        chrome_options.add_argument("--disable-gpu")
        chrome_options.add_argument("--no-sandbox")
        chrome_options.add_argument("--start-maximized")
        chrome_options.add_argument(f'user-data-dir={self.PROFILE_PATH}')
        chrome_options.add_argument(f'profile-directory={self.PROFILE_NAME}')
        service = ChromeService(executable_path=self.CHROMEDRIVER_PATH)
        return webdriver.Chrome(service=service, options=chrome_options)

    def login(self, app_id, app_pw):
        try:
            self.driver.get(self.LOGIN_URL)
            WebDriverWait(self.driver, 10).until(EC.presence_of_element_located((By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[1]/div/div/input')))
            id_box = self.driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[1]/div/div/input')
            password_box = self.driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[2]/div/div/input')
            login_button = self.driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[3]/button')
            id_box.send_keys(app_id)
            password_box.send_keys(app_pw)
            login_button.click()
            WebDriverWait(self.driver, 15).until(EC.url_to_be(self.TARGET_URL))
            print("[INFO] 로그인에 성공했습니다. 코드를 재 실행주세요.")
            self.driver.quit()
        except TimeoutException as e:
            print("[ERROR] 이미 로그인 되었는지, 로그인 창으로 이동할 수 없습니다.")
        except Exception as e:
            print("[ERROR] 로그인 중 다른 오류 발생:", traceback.format_exc())

    def extract_data_from_html(self, html_content):
        soup = BeautifulSoup(html_content, 'html.parser')
        tables = soup.find_all('table')
        structured_data = []
        unstructured_data = []

        for table in tables:
            rows = table.find_all('tr')
            table_data = []

            for row in rows:
                cols = row.find_all(['td', 'th'])
                cols = [ele.text.strip() for ele in cols]
                table_data.append(cols)

            structured_data.append(table_data)

        [s.extract() for s in soup(['style', 'script', '[document]', 'head', 'title'])]
        unstructured_data = soup.get_text(separator=' ', strip=True)

        return structured_data, unstructured_data

    def send_api_request(self, url, headers):
        response = requests.get(url, headers=headers, verify=False)
        if response.status_code == 200:
            html_content = response.content.decode('utf-8')
            structured_data, unstructured_data = self.extract_data_from_html(html_content)
            return response.json(), structured_data, unstructured_data
        else:
            print(f"[ERROR] API 요청 실패. Status Code: {response.status_code}")
            print(f"Response: {response.text}")
            return None, None, None

    def send_post_request(self, url, headers, body):
        response = requests.post(url, headers=headers, json=body, verify=False)
        if response.status_code == 200:
            html_content = response.content.decode('utf-8')
            structured_data, unstructured_data = self.extract_data_from_html(html_content)
            return response.json(), structured_data, unstructured_data
        else:
            print(f"[ERROR] POST 요청 실패. Status Code: {response.status_code}")
            print(f"Response: {response.text}")
            return None, None, None

    def save_response_as_json(self, response_data, file_path):
        with open(file_path, 'w', encoding='utf-8') as file:
            json.dump(response_data, file, ensure_ascii=False, indent=4)

    def send_first_api_request(self):
        first_api_url = f'https://dataservice.koscom.co.kr/apis/v1/user/approvals/{self.REFERENCE_ID}'
        response_json, structured_data, unstructured_data = self.send_api_request(first_api_url, self.extract_auth_header())
        if response_json:
            self.total = response_json.get("page", {}).get("total", 0)
            self.totalPage = response_json.get("page", {}).get("totalPage", 0)
            self.save_response_as_json({"response": response_json, "structured": structured_data, "unstructured": unstructured_data}, "first_api_response.json")

    def send_second_api_request(self):
        second_api_url = "https://dataservice.koscom.co.kr/apis/v1/common/snapshots/history"
        body = {
            'snapshotsLargeClassificationCode': '04',
            'snapshotsSmallClassificationCode': '04_01',
            'referenceId': self.REFERENCE_ID
        }
        response_json, structured_data, unstructured_data = self.send_post_request(second_api_url, self.extract_auth_header(), body)
        self.save_response_as_json({"response": response_json, "structured": structured_data, "unstructured": unstructured_data}, "second_api_response.json")

    def send_third_api_request(self, page_number):
        third_api_url = "https://dataservice.koscom.co.kr/apis/v1/user/approvals/search"
        body = {
            "startDate": "",
            "endDate": "",
            "sanctionTypeCode": "",
            "approvalStatusCode": "",
            "ordersSectionCode": "",
            "searchType": "SUBJECT",
            "searchText": "",
            "page": {
                "pageNumber": page_number,
                "pageSize": 10,
                "total": self.total,
                "totalPage": self.totalPage
            }
        }
        response_json, structured_data, unstructured_data = self.send_post_request(third_api_url, self.extract_auth_header(), body)
        if response_json:
            print(f"페이지 {page_number}: 응답 일부 - {str(response_json)[:100]}")
            nested_response = {
                "page_info": response_json.get("page", {}),
                "contents": response_json.get("contents", [])
            }
            self.save_response_as_json(nested_response, f"third_api_response_page_{page_number}.json")
            self.all_responses[page_number] = nested_response

    def extract_auth_header(self):
        for request in self.driver.requests:
            if request.url == "https://dataservice.koscom.co.kr/apis/v1/common/auth/my-information":
                return {'Authorization': request.headers.get('Authorization')}
        return {}

# 메인 실행 코드
if __name__ == "__main__":
    api_manager = APIManager()
    api_manager.login('goguma@krx.co.kr', 'wkrwjs12!@')
    api_manager.send_first_api_request()
    api_manager.send_second_api_request()

    for page_number in tqdm(range(1, 11), desc="처리 중"):
        time.sleep(20)  # 페이지 요청 사이에 20초 지연
        api_manager.send_third_api_request(page_number)

    # 필요한 경우 여기에서 all_responses 객체를 사용하여 추가 처리
    # 예: 전체 응답 데이터를 하나의 파일로 저장
    with open('all_api_responses.json', 'w', encoding='utf-8') as file:
        json.dump(api_manager.all_responses, file, ensure_ascii=False, indent=4)
    all_responses = api_manager.all_responses
    api_manager.driver.quit()
# %% - SQL 저장
from mysql.connector import connect, Error

# 메인 실행 코드
if __name__ == "__main__":
    api_manager = APIManager()
    api_manager.login('goguma@krx.co.kr', 'wkrwjs12!@')
    api_manager.send_first_api_request()
    api_manager.send_second_api_request()

    for page_number in tqdm(range(1, 10), desc="처리 중"):
    # for page_number in tqdm(range(1, 800), desc="처리 중"):
        time.sleep(20)  # 페이지 요청 사이에 20초 지연
        api_manager.send_third_api_request(page_number)

    api_manager.driver.quit()

    # MySQL 데이터베이스에 데이터를 저장하는 코드
    try:
        connection = connect(
            host='localhost',
            database='First_API_Tables',
            user='root',
            password='wkrwjs12!@'
        )
        cursor = connection.cursor()
        for page, data in api_manager.all_responses.items():
            query = "INSERT INTO api_responses (page_number, response_data) VALUES (%s, %s)"
            cursor.execute(query, (page, json.dumps(data)))
            connection.commit()
        print("모든 응답 데이터가 MySQL 데이터베이스에 성공적으로 저장되었습니다.")
    except Error as e:
        print(f"MySQL 데이터베이스 저장 중 에러 발생: {e}")
    finally:
        if connection and connection.is_connected():
            cursor.close()
            connection.close()

# %% - `24.01.14. SQL 저장 - Describe 入 (Primary Key Error 有)
from mysql.connector import connect, Error

# 메인 실행 코드
if __name__ == "__main__":
    api_manager = APIManager()
    api_manager.login('goguma@krx.co.kr', 'wkrwjs12!@')
    api_manager.send_first_api_request()
    api_manager.send_second_api_request()

    for page_number in tqdm(range(1, 10), desc="처리 중"):
        time.sleep(20)  # 페이지 요청 사이에 20초 지연
        api_manager.send_third_api_request(page_number)

    api_manager.driver.quit()

    try:
        # MySQL 데이터베이스에 연결
        connection = connect(
            host='localhost',
            database='First_API_Tables',
            user='root',
            password='wkrwjs12!@'
        )
        cursor = connection.cursor()

        # api_responses 테이블의 스키마 정보 조회
        cursor.execute("DESCRIBE api_responses")
        schema_info = cursor.fetchall()
        print("api_responses 테이블 스키마 정보:")
        for column in schema_info:
            print(column)

        # 데이터 저장 로직
        for page, data in api_manager.all_responses.items():
            query = "INSERT INTO api_responses (page_number, response_data) VALUES (%s, %s)"
            cursor.execute(query, (page, json.dumps(data)))
            connection.commit()
        print("모든 응답 데이터가 MySQL 데이터베이스에 성공적으로 저장되었습니다.")

    except Error as e:
        print(f"MySQL 데이터베이스 작업 중 에러 발생: {e}")

    finally:
        # 데이터베이스 연결 종료
        if connection and connection.is_connected():
            cursor.close()
            connection.close()

# %% - `24.01.14. SQL 저장 - Describe 入 (Primary Key Error 有 - Delete 처리)
if __name__ == "__main__":
    api_manager = APIManager()
    api_manager.login('goguma@krx.co.kr', 'wkrwjs12!@')
    api_manager.send_first_api_request()
    api_manager.send_second_api_request()

    api_manager.all_responses = {}  # API 응답을 저장할 딕셔너리 초기화
    for page_number in tqdm(range(1, 10), desc="처리 중"):
        time.sleep(20)  # 페이지 요청 사이에 20초 지연
        api_manager.send_third_api_request(page_number)

    try:
        # MySQL 데이터베이스에 연결
        connection = connect(
            host='localhost',
            database='First_API_Tables',
            user='root',
            password='wkrwjs12!@'
        )
        cursor = connection.cursor()

        # api_responses 테이블에서 Primary Key 삭제
        cursor.execute("ALTER TABLE api_responses DROP PRIMARY KEY")
        print("Primary Key 삭제 완료")

        # 기존 데이터 삭제
        cursor.execute("DELETE FROM api_responses")
        connection.commit()
        print("기존 데이터 삭제 완료")

        # 데이터 저장 로직
        for page, data in api_manager.all_responses.items():
            query = "INSERT INTO api_responses (page_number, response_data) VALUES (%s, %s)"
            cursor.execute(query, (page, json.dumps(data)))
            connection.commit()
        print("모든 응답 데이터가 MySQL 데이터베이스에 성공적으로 저장되었습니다.")

    except Error as e:
        print(f"MySQL 데이터베이스 작업 중 에러 발생: {e}")
        
    finally:
        # 데이터베이스 연결 종료
        if connection and connection.is_connected():
            cursor.close()
            connection.close()



# %% - Unique Key ver. 
# krxSanctionSubject + sanctionId → Hash 
import json
import requests
from hashlib import md5
from seleniumwire import webdriver
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException
from bs4 import BeautifulSoup
from tqdm import tqdm
import time
from mysql.connector import connect, Error
import urllib3

class APIManager:
    def __init__(self):
        self.CHROMEDRIVER_PATH = 'C:\\Users\\KRX\\Desktop\\201021\\chromedriver-win32\\chromedriver.exe'
        self.CHROME_BINARY_PATH = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe'
        self.LOGIN_URL = 'https://dataservice.koscom.co.kr/login?returnUrl=/krx/approval-list'
        self.TARGET_URL = 'https://dataservice.koscom.co.kr/krx/approval-list'
        self.PROFILE_PATH = 'C:\\Users\\KRX\\Desktop\\201021'
        self.PROFILE_NAME = 'Profile 4'
        self.REFERENCE_ID = 100562
        self.driver = self.create_webdriver()
        self.all_responses = {}
        urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

    def create_webdriver(self):
        chrome_options = Options()
        chrome_options.binary_location = self.CHROME_BINARY_PATH
        chrome_options.add_argument("--disable-gpu")
        chrome_options.add_argument("--no-sandbox")
        chrome_options.add_argument("--start-maximized")
        chrome_options.add_argument(f'user-data-dir={self.PROFILE_PATH}')
        chrome_options.add_argument(f'profile-directory={self.PROFILE_NAME}')
        service = ChromeService(executable_path=self.CHROMEDRIVER_PATH)
        return webdriver.Chrome(service=service, options=chrome_options)

    def login(self, app_id, app_pw):
        try:
            self.driver.get(self.LOGIN_URL)
            WebDriverWait(self.driver, 10).until(EC.presence_of_element_located((By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[1]/div/div/input')))
            id_box = self.driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[1]/div/div/input')
            password_box = self.driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[2]/div/div/input')
            login_button = self.driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[3]/button')
            id_box.send_keys(app_id)
            password_box.send_keys(app_pw)
            login_button.click()
            WebDriverWait(self.driver, 15).until(EC.url_to_be(self.TARGET_URL))
            print("[INFO] 로그인에 성공했습니다.")
        except TimeoutException as e:
            print("[ERROR] 이미 로그인 되었는지, 로그인 창으로 이동할 수 없습니다.")
        except Exception as e:
            print("[ERROR] 로그인 중 다른 오류 발생:", traceback.format_exc())

    def extract_data_from_html(self, html_content):
        soup = BeautifulSoup(html_content, 'html.parser')
        tables = soup.find_all('table')
        structured_data = []
        unstructured_data = []

        for table in tables:
            rows = table.find_all('tr')
            table_data = []

            for row in rows:
                cols = row.find_all(['td', 'th'])
                cols = [ele.text.strip() for ele in cols]
                table_data.append(cols)

            structured_data.append(table_data)

        [s.extract() for s in soup(['style', 'script', '[document]', 'head', 'title'])]
        unstructured_data = soup.get_text(separator=' ', strip=True)

        return structured_data, unstructured_data

    def send_api_request(self, url, headers):
        response = requests.get(url, headers=headers, verify=False)
        if response.status_code == 200:
            html_content = response.content.decode('utf-8')
            structured_data, unstructured_data = self.extract_data_from_html(html_content)
            return response.json(), structured_data, unstructured_data
        else:
            print(f"[ERROR] API 요청 실패. Status Code: {response.status_code}")
            print(f"Response: {response.text}")
            return None, None, None

    def send_post_request(self, url, headers, body):
        response = requests.post(url, headers=headers, json=body, verify=False)
        if response.status_code == 200:
            html_content = response.content.decode('utf-8')
            structured_data, unstructured_data = self.extract_data_from_html(html_content)
            return response.json(), structured_data, unstructured_data
        else:
            print(f"[ERROR] POST 요청 실패. Status Code: {response.status_code}")
            print(f"Response: {response.text}")
            return None, None, None

    def save_response_as_json(self, response_data, file_path):
        with open(file_path, 'w', encoding='utf-8') as file:
            json.dump(response_data, file, ensure_ascii=False, indent=4)

    def send_first_api_request(self):
        first_api_url = f'https://dataservice.koscom.co.kr/apis/v1/user/approvals/{self.REFERENCE_ID}'
        response_json, structured_data, unstructured_data = self.send_api_request(first_api_url, self.extract_auth_header())
        if response_json:
            self.total = response_json.get("page", {}).get("total", 0)
            self.totalPage = response_json.get("page", {}).get("totalPage", 0)
            self.save_response_as_json({"response": response_json, "structured": structured_data, "unstructured": unstructured_data}, "first_api_response.json")

    def send_second_api_request(self):
        second_api_url = "https://dataservice.koscom.co.kr/apis/v1/common/snapshots/history"
        body = {
            'snapshotsLargeClassificationCode': '04',
            'snapshotsSmallClassificationCode': '04_01',
            'referenceId': self.REFERENCE_ID
        }
        response_json, structured_data, unstructured_data = self.send_post_request(second_api_url, self.extract_auth_header(), body)
        self.save_response_as_json({"response": response_json, "structured": structured_data, "unstructured": unstructured_data}, "second_api_response.json")

    def send_third_api_request(self, page_number):
        third_api_url = "https://dataservice.koscom.co.kr/apis/v1/user/approvals/search"
        body = {
            "startDate": "",
            "endDate": "",
            "sanctionTypeCode": "",
            "approvalStatusCode": "",
            "ordersSectionCode": "",
            "searchType": "SUBJECT",
            "searchText": "",
            "page": {
                "pageNumber": page_number,
                "pageSize": 10,
                "total": self.total,
                "totalPage": self.totalPage
            }
        }
        response_json, structured_data, unstructured_data = self.send_post_request(third_api_url, self.extract_auth_header(), body)
        if response_json:
            for content in response_json.get("contents", []):
                krx_sanction_subject = content.get("krxSanctionSubject", "")
                sanction_id = content.get("sanctionId", 0)
                unique_key = f"{krx_sanction_subject}-{sanction_id}"
                unique_key_hash = md5(unique_key.encode('utf-8')).hexdigest()
                nested_response = {
                    "page_info": response_json.get("page", {}),
                    "contents": content,
                    "unique_key_hash": unique_key_hash
                }
                self.all_responses[unique_key_hash] = nested_response

    def extract_auth_header(self):
        for request in self.driver.requests:
            if request.url == "https://dataservice.koscom.co.kr/apis/v1/common/auth/my-information":
                return {'Authorization': request.headers.get('Authorization')}
        return {}

# 메인 실행 코드
if __name__ == "__main__":
    api_manager = APIManager()
    api_manager.login('goguma@krx.co.kr', 'wkrwjs12!@')
    api_manager.send_first_api_request()
    api_manager.send_second_api_request()

    for page_number in tqdm(range(1, 11), desc="처리 중"):
        time.sleep(20)
        api_manager.send_third_api_request(page_number)

    api_manager.driver.quit()

    # MySQL 데이터베이스에 데이터를 저장하는 코드
    try:
        connection = connect(
            host='localhost',
            database='First_API_Tables',
            user='root',
            password='wkrwjs12!@'
        )
        cursor = connection.cursor()
        alter_query = """
        ALTER TABLE api_responses 
        ADD COLUMN sanction_subject VARCHAR(255),
        ADD COLUMN sanction_id INT,
        ADD COLUMN unique_key_hash VARCHAR(255);
        """
        cursor.execute(alter_query)
        connection.commit()

        for unique_key_hash, data in api_manager.all_responses.items():
            page_info = data["page_info"]
            page_number = page_info.get("pageNumber", 0)
            response_data = json.dumps(data)
            query = """
            INSERT INTO api_responses (page_number, response_data, unique_key_hash)
            VALUES (%s, %s, %s)
            ON DUPLICATE KEY UPDATE
            response_data = VALUES(response_data),
            unique_key_hash = VALUES(unique_key_hash)
            """
            cursor.execute(query, (page_number, response_data, unique_key_hash))
            connection.commit()
        print("모든 응답 데이터가 MySQL 데이터베이스에 성공적으로 저장되었습니다.")
    except Error as e:
        print(f"MySQL 데이터베이스 저장 중 에러 발생: {e}")
    finally:
        if connection and connection.is_connected():
            cursor.close()
            connection.close()

# %% - Unique Key 기반 중복 Passing Ver. 
# krxSanctionSubject + sanctionId → Hash 
import json
import requests
from hashlib import md5
from seleniumwire import webdriver
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException, WebDriverException
from bs4 import BeautifulSoup
from tqdm import tqdm
import time
from mysql.connector import connect, Error
import urllib3

class APIManager:
    def __init__(self):
        self.CHROMEDRIVER_PATH = 'C:\\Users\\KRX\\Desktop\\201021\\chromedriver-win32\\chromedriver.exe'
        self.CHROME_BINARY_PATH = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe'
        self.LOGIN_URL = 'https://dataservice.koscom.co.kr/login?returnUrl=/krx/approval-list'
        self.TARGET_URL = 'https://dataservice.koscom.co.kr/krx/approval-list'
        self.PROFILE_PATH = 'C:\\Users\\KRX\\Desktop\\201021'
        self.PROFILE_NAME = 'Profile 4'
        self.REFERENCE_ID = 100562
        self.driver = self.create_webdriver()
        self.all_responses = {}
        urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

        # 데이터베이스 연결 설정 수정
        self.connection = connect(
            host='localhost',
            database='first_api_tables',  # 데이터베이스 이름 수정
            user='root',
            password='wkrwjs12!@'
        )
        self.cursor = self.connection.cursor()
        self.existing_hashes_map = {}
        self.load_existing_hashes()

    def create_webdriver(self):
        chrome_options = Options()
        chrome_options.binary_location = self.CHROME_BINARY_PATH
        chrome_options.add_argument("--disable-gpu")
        chrome_options.add_argument("--no-sandbox")
        chrome_options.add_argument("--start-maximized")
        chrome_options.add_argument(f'user-data-dir={self.PROFILE_PATH}')
        chrome_options.add_argument(f'profile-directory={self.PROFILE_NAME}')
        service = ChromeService(executable_path=self.CHROMEDRIVER_PATH)
        return webdriver.Chrome(service=service, options=chrome_options)

    def login(self, app_id, app_pw):
        try:
            self.driver.get(self.LOGIN_URL)
            WebDriverWait(self.driver, 10).until(EC.presence_of_element_located((By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[1]/div/div/input')))
            id_box = self.driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[1]/div/div/input')
            password_box = self.driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[2]/div/div/input')
            login_button = self.driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[3]/button')
            id_box.send_keys(app_id)
            password_box.send_keys(app_pw)
            login_button.click()
            WebDriverWait(self.driver, 15).until(EC.url_to_be(self.TARGET_URL))
            print("[INFO] 로그인에 성공했습니다.")
        except TimeoutException as e:
            print("[ERROR] 이미 로그인 되었는지, 로그인 창으로 이동할 수 없습니다.")
        except Exception as e:
            print("[ERROR] 로그인 중 다른 오류 발생:", e)

    def extract_data_from_html(self, html_content):
        soup = BeautifulSoup(html_content, 'html.parser')
        tables = soup.find_all('table')
        structured_data = []
        unstructured_data = []

        for table in tables:
            rows = table.find_all('tr')
            table_data = []

            for row in rows:
                cols = row.find_all(['td', 'th'])
                cols = [ele.text.strip() for ele in cols]
                table_data.append(cols)

            structured_data.append(table_data)

        [s.extract() for s in soup(['style', 'script', '[document]', 'head', 'title'])]
        unstructured_data = soup.get_text(separator=' ', strip=True)

        return structured_data, unstructured_data

    def extract_auth_header(self):
        for request in self.driver.requests:
            if request.url == "https://dataservice.koscom.co.kr/apis/v1/common/auth/my-information":
                return {'Authorization': request.headers.get('Authorization')}
        return {}

    def send_api_request(self, url, headers):
        response = requests.get(url, headers=headers, verify=False)
        if response.status_code == 200:
            html_content = response.content.decode('utf-8')
            structured_data, unstructured_data = self.extract_data_from_html(html_content)
            return response.json(), structured_data, unstructured_data
        else:
            print(f"[ERROR] API 요청 실패. Status Code: {response.status_code}")
            print(f"Response: {response.text}")
            return None, None, None

    def send_post_request(self, url, headers, body):
        response = requests.post(url, headers=headers, json=body, verify=False)
        if response.status_code == 200:
            html_content = response.content.decode('utf-8')
            structured_data, unstructured_data = self.extract_data_from_html(html_content)
            return response.json(), structured_data, unstructured_data
        else:
            print(f"[ERROR] POST 요청 실패. Status Code: {response.status_code}")
            print(f"Response: {response.text}")
            return None, None, None

    def save_response_as_json(self, response_data, file_path):
        with open(file_path, 'w', encoding='utf-8') as file:
            json.dump(response_data, file, ensure_ascii=False, indent=4)

    def send_first_api_request(self):
        first_api_url = f'https://dataservice.koscom.co.kr/apis/v1/user/approvals/{self.REFERENCE_ID}'
        response_json, structured_data, unstructured_data = self.send_api_request(first_api_url, self.extract_auth_header())
        if response_json:
            self.total = response_json.get("page", {}).get("total", 0)
            self.totalPage = response_json.get("page", {}).get("totalPage", 0)
            self.save_response_as_json({"response": response_json, "structured": structured_data, "unstructured": unstructured_data}, "first_api_response.json")

    def send_second_api_request(self):
        second_api_url = "https://dataservice.koscom.co.kr/apis/v1/common/snapshots/history"
        body = {
            'snapshotsLargeClassificationCode': '04',
            'snapshotsSmallClassificationCode': '04_01',
            'referenceId': self.REFERENCE_ID
        }
        response_json, structured_data, unstructured_data = self.send_post_request(second_api_url, self.extract_auth_header(), body)
        self.save_response_as_json({"response": response_json, "structured": structured_data, "unstructured": unstructured_data}, "second_api_response.json")

    def send_third_api_request(self, page_number):
        third_api_url = "https://dataservice.koscom.co.kr/apis/v1/user/approvals/search"
        body = {
            "startDate": "",
            "endDate": "",
            "sanctionTypeCode": "",
            "approvalStatusCode": "",
            "ordersSectionCode": "",
            "searchType": "SUBJECT",
            "searchText": "",
            "page": {
                "pageNumber": page_number,
                "pageSize": 10,
                "total": self.total,
                "totalPage": self.totalPage
            }
        }
        response_json, structured_data, unstructured_data = self.send_post_request(third_api_url, self.extract_auth_header(), body)
        if response_json:
            for content in response_json.get("contents", []):
                krx_sanction_subject = content.get("krxSanctionSubject", "")
                sanction_id = content.get("sanctionId", 0)
                unique_key = f"{krx_sanction_subject}-{sanction_id}"
                unique_key_hash = md5(unique_key.encode('utf-8')).hexdigest()
    
                print(f"[DEBUG] Processing item: {unique_key}, Hash: {unique_key_hash}")
    
                if unique_key_hash not in self.existing_hashes_map:
                    nested_response = {
                        "page_info": response_json.get("page", {}),
                        "contents": content,
                        "unique_key_hash": unique_key_hash,
                        "sanction_subject": krx_sanction_subject,
                        "sanction_id": sanction_id
                    }
                    self.all_responses[unique_key_hash] = nested_response
                    print(f"Saction ID {sanction_id} ({krx_sanction_subject}) saved. Hash: {unique_key_hash}")
                    self.existing_hashes_map[unique_key_hash] = unique_key
                else:
                    print(f"Saction ID {sanction_id} ({krx_sanction_subject}) already exists in the database. Hash: {unique_key_hash}")

    def save_responses_to_database(self):
        print("[DEBUG] save_responses_to_database 함수 시작")
        self.connection.ping(reconnect=True)  # 데이터베이스 연결 확인 및 필요시 재연결
        for unique_key_hash, data in self.all_responses.items():
            # 각 항목에 대해 새 커서를 생성합니다.
            with self.connection.cursor() as cursor:
                page_info = data["page_info"]
                page_number = page_info.get("pageNumber", 0)
                response_data = json.dumps(data)
                sanction_id = data["sanction_id"]
                sanction_subject = data.get("sanction_subject", "")  # subject 추출

                query = """
                INSERT INTO api_responses (page_number, sanction_id, sanction_subject, response_data, unique_key_hash)
                VALUES (%s, %s, %s, %s, %s)
                ON DUPLICATE KEY UPDATE
                sanction_subject = VALUES(sanction_subject),
                response_data = VALUES(response_data),
                unique_key_hash = VALUES(unique_key_hash)
                """
                try:
                    cursor.execute(query, (page_number, sanction_id, sanction_subject, response_data, unique_key_hash))
                    self.connection.commit()  # 트랜잭션 커밋
                    print(f"[DEBUG] 데이터 저장 성공: {unique_key_hash}")
                except Error as e:
                    print(f"[ERROR] 데이터 저장 중 오류 발생: {e}")
                    self.connection.rollback()  # 트랜잭션 롤백
        print("[DEBUG] save_responses_to_database 함수 종료")
   
        
    def ensure_database_connection(self):
        if not self.connection.is_connected():
            print("[INFO] 데이터베이스 재연결 시도 중...")
            self.connection.reconnect(attempts=3, delay=5)

    def load_existing_hashes(self):
        self.ensure_database_connection()  # 데이터베이스 연결 확인 및 재연결 시도
        self.cursor = self.connection.cursor()  # 새 커서 생성
        print("[DEBUG] load_existing_hashes 함수 시작")
        self.existing_hashes_map.clear()
        try:
            query = "SELECT unique_key_hash, sanction_subject, sanction_id FROM api_responses"
            self.cursor.execute(query)
            results = self.cursor.fetchall()
            for hash_value, subject, id in results:
                if subject is not None and id is not None:
                    self.existing_hashes_map[hash_value] = f"{subject}-{id}"
        except Error as e:
            print(f"[ERROR] 데이터 불러오기 중 오류 발생: {e}")
        finally:
            self.cursor.close()  # 커서 닫기
        print("[INFO] Loaded existing hashes:", self.existing_hashes_map)
        print("[DEBUG] load_existing_hashes 함수 종료")
    
    def close(self):
        self.driver.quit()
        self.cursor.close()
        self.connection.close()
        print("[DEBUG] 데이터베이스 연결 닫힘")

if __name__ == "__main__":
    api_manager = APIManager()
    api_manager.login('goguma@krx.co.kr', 'wkrwjs12!@')
    api_manager.send_first_api_request()
    api_manager.send_second_api_request()
    for page_number in tqdm(range(0, 20), desc="Processing"):
        time.sleep(10)
        api_manager.send_third_api_request(page_number)
    api_manager.save_responses_to_database()
    api_manager.close()
    print("All tasks completed.")

# %% - + First, Second 
import json
import requests
from hashlib import md5
from seleniumwire import webdriver
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException, WebDriverException
from bs4 import BeautifulSoup
from tqdm import tqdm
import time
from mysql.connector import connect, Error
import urllib3

class APIManager:
    def __init__(self):
        self.CHROMEDRIVER_PATH = 'C:\\Users\\KRX\\Desktop\\201021\\chromedriver-win32\\chromedriver.exe'
        self.CHROME_BINARY_PATH = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe'
        self.LOGIN_URL = 'https://dataservice.koscom.co.kr/login?returnUrl=/krx/approval-list'
        self.TARGET_URL = 'https://dataservice.koscom.co.kr/krx/approval-list'
        self.PROFILE_PATH = 'C:\\Users\\KRX\\Desktop\\201021'
        self.PROFILE_NAME = 'Profile 4'
        self.REFERENCE_ID = 100562
        self.driver = self.create_webdriver()
        self.all_responses = {}
        urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

        self.connection = connect(
            host='localhost',
            database='first_api_tables',
            user='root',
            password='wkrwjs12!@'
        )
        self.cursor = self.connection.cursor()
        self.create_tables_if_not_exists()
        self.existing_hashes_map = {}
        self.load_existing_hashes()

    def create_tables_if_not_exists(self):
        create_table_queries = {
            'Table_1st_API': """
                CREATE TABLE IF NOT EXISTS Table_1st_API (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    response_data JSON
                );
            """,
            'Table_2st_API': """
                CREATE TABLE IF NOT EXISTS Table_2st_API (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    response_data JSON
                );
            """,
            'Table_3st_API': """
                CREATE TABLE IF NOT EXISTS Table_3st_API (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    page_number INT,
                    sanction_id INT,
                    sanction_subject VARCHAR(255),
                    response_data JSON,
                    unique_key_hash VARCHAR(64),
                    UNIQUE(unique_key_hash)
                );
            """
        }

        for table_name, query in create_table_queries.items():
            try:
                self.cursor.execute(query)
                self.connection.commit()
                print(f"[INFO] Table '{table_name}' checked/created.")
            except Error as e:
                print(f"[ERROR] Error while creating/checking table '{table_name}': {e}")
                self.connection.rollback()

    def create_webdriver(self):
        chrome_options = Options()
        chrome_options.binary_location = self.CHROME_BINARY_PATH
        chrome_options.add_argument("--disable-gpu")
        chrome_options.add_argument("--no-sandbox")
        chrome_options.add_argument("--start-maximized")
        chrome_options.add_argument(f'user-data-dir={self.PROFILE_PATH}')
        chrome_options.add_argument(f'profile-directory={self.PROFILE_NAME}')
        service = ChromeService(executable_path=self.CHROMEDRIVER_PATH)
        return webdriver.Chrome(service=service, options=chrome_options)

    def login(self, app_id, app_pw):
        try:
            self.driver.get(self.LOGIN_URL)
            WebDriverWait(self.driver, 10).until(EC.presence_of_element_located((By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[1]/div/div/input')))
            id_box = self.driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[1]/div/div/input')
            password_box = self.driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[2]/div/div/input')
            login_button = self.driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[3]/button')
            id_box.send_keys(app_id)
            password_box.send_keys(app_pw)
            login_button.click()
            WebDriverWait(self.driver, 15).until(EC.url_to_be(self.TARGET_URL))
            print("[INFO] 로그인에 성공했습니다.")
        except TimeoutException as e:
            print("[ERROR] 이미 로그인 되었는지, 로그인 창으로 이동할 수 없습니다.")
        except Exception as e:
            print("[ERROR] 로그인 중 다른 오류 발생:", e)

    def extract_data_from_html(self, html_content):
        soup = BeautifulSoup(html_content, 'html.parser')
        tables = soup.find_all('table')
        structured_data = []
        unstructured_data = []

        for table in tables:
            rows = table.find_all('tr')
            table_data = []

            for row in rows:
                cols = row.find_all(['td', 'th'])
                cols = [ele.text.strip() for ele in cols]
                table_data.append(cols)

            structured_data.append(table_data)

        [s.extract() for s in soup(['style', 'script', '[document]', 'head', 'title'])]
        unstructured_data = soup.get_text(separator=' ', strip=True)

        return structured_data, unstructured_data

    def extract_auth_header(self):
        for request in self.driver.requests:
            if request.url == "https://dataservice.koscom.co.kr/apis/v1/common/auth/my-information":
                return {'Authorization': request.headers.get('Authorization')}
        return {}

    def send_api_request(self, url, headers):
        response = requests.get(url, headers=headers, verify=False)
        if response.status_code == 200:
            html_content = response.content.decode('utf-8')
            structured_data, unstructured_data = self.extract_data_from_html(html_content)
            return response.json(), structured_data, unstructured_data
        else:
            print(f"[ERROR] API 요청 실패. Status Code: {response.status_code}")
            print(f"Response: {response.text}")
            return None, None, None

    def send_post_request(self, url, headers, body):
        response = requests.post(url, headers=headers, json=body, verify=False)
        if response.status_code == 200:
            html_content = response.content.decode('utf-8')
            structured_data, unstructured_data = self.extract_data_from_html(html_content)
            return response.json(), structured_data, unstructured_data
        else:
            print(f"[ERROR] POST 요청 실패. Status Code: {response.status_code}")
            print(f"Response: {response.text}")
            return None, None, None

    def save_response_as_json(self, response_data, file_path):
        with open(file_path, 'w', encoding='utf-8') as file:
            json.dump(response_data, file, ensure_ascii=False, indent=4)

    def send_first_api_request(self):
        first_api_url = f'https://dataservice.koscom.co.kr/apis/v1/user/approvals/{self.REFERENCE_ID}'
        response_json, structured_data, unstructured_data = self.send_api_request(first_api_url, self.extract_auth_header())
        if response_json:
            self.total = response_json.get("page", {}).get("total", 0)
            self.totalPage = response_json.get("page", {}).get("totalPage", 0)
            self.save_response_as_json({"response": response_json, "structured": structured_data, "unstructured": unstructured_data}, "first_api_response.json")

    def send_second_api_request(self):
        second_api_url = "https://dataservice.koscom.co.kr/apis/v1/common/snapshots/history"
        body = {
            'snapshotsLargeClassificationCode': '04',
            'snapshotsSmallClassificationCode': '04_01',
            'referenceId': self.REFERENCE_ID
        }
        response_json, structured_data, unstructured_data = self.send_post_request(second_api_url, self.extract_auth_header(), body)
        self.save_response_as_json({"response": response_json, "structured": structured_data, "unstructured": unstructured_data}, "second_api_response.json")

    def send_third_api_request(self, page_number):
        third_api_url = "https://dataservice.koscom.co.kr/apis/v1/user/approvals/search"
        body = {
            "startDate": "",
            "endDate": "",
            "sanctionTypeCode": "",
            "approvalStatusCode": "",
            "ordersSectionCode": "",
            "searchType": "SUBJECT",
            "searchText": "",
            "page": {
                "pageNumber": page_number,
                "pageSize": 10,
                "total": self.total,
                "totalPage": self.totalPage
            }
        }
        response_json, structured_data, unstructured_data = self.send_post_request(third_api_url, self.extract_auth_header(), body)
        if response_json:
            for content in response_json.get("contents", []):
                krx_sanction_subject = content.get("krxSanctionSubject", "")
                sanction_id = content.get("sanctionId", 0)
                unique_key = f"{krx_sanction_subject}-{sanction_id}"
                unique_key_hash = md5(unique_key.encode('utf-8')).hexdigest()
                print(f"[DEBUG] Processing item: {unique_key}, Hash: {unique_key_hash}")
    
                # 중복된 해시 값이 있는 경우, 데이터를 추가하지 않습니다.
                if unique_key_hash in self.existing_hashes_map:
                    print(f"[INFO] 중복 데이터 발견, 저장하지 않음: {unique_key_hash}")
                    continue
    
                # 중복되지 않은 경우, 데이터를 추가합니다.
                nested_response = {
                    "page_info": response_json.get("page", {}),
                    "contents": content,
                    "unique_key_hash": unique_key_hash,
                    "sanction_subject": krx_sanction_subject,
                    "sanction_id": sanction_id
                }
                self.all_responses[unique_key_hash] = nested_response
                print(f"Saction ID {sanction_id} ({krx_sanction_subject}) saved. Hash: {unique_key_hash}")

    def save_responses_to_database(self):
        print("[DEBUG] save_responses_to_database 함수 시작")
        self.connection.ping(reconnect=True)  # 데이터베이스 연결 확인 및 필요시 재연결
        for unique_key_hash, data in self.all_responses.items():
            with self.connection.cursor() as cursor:
                # 데이터베이스에서 unique_key_hash가 존재하는지 확인
                check_query = "SELECT COUNT(*) FROM Table_3st_API WHERE unique_key_hash = %s"
                cursor.execute(check_query, (unique_key_hash,))
                (count,) = cursor.fetchone()
        
                if count > 0:
                    print(f"[INFO] 중복 데이터 발견, 저장하지 않음: {unique_key_hash}")
                    continue  # 중복 데이터는 건너뜁니다.
                else:
                    print(f"[INFO] 새 데이터 발견, 저장 진행: {unique_key_hash}")
        
                # 중복이 아니면 새로운 데이터 저장
                page_info = data["page_info"]
                page_number = page_info.get("pageNumber", 0)
                response_data = json.dumps(data)
                sanction_id = data["sanction_id"]
                sanction_subject = data.get("sanction_subject", "") 
        
                insert_query = """
                INSERT INTO Table_3st_API (page_number, sanction_id, sanction_subject, response_data, unique_key_hash)
                VALUES (%s, %s, %s, %s, %s)
                """
                try:
                    cursor.execute(insert_query, (page_number, sanction_id, sanction_subject, response_data, unique_key_hash))
                    self.connection.commit() 
                    print(f"[DEBUG] 데이터 저장 성공: {unique_key_hash}")
                except Error as e:
                    print(f"[ERROR] 데이터 저장 중 오류 발생: {e}")
                    self.connection.rollback()
    
        print("[DEBUG] save_responses_to_database 함수 종료")

    def save_first_second_api_responses_to_database(self, file_name, table_name):
        try:
            with open(file_name, 'r', encoding='utf-8') as file:
                data = json.load(file)
                response_data = json.dumps(data)

                with self.connection.cursor() as cursor:
                    query = f"""
                    INSERT INTO {table_name} (response_data)
                    VALUES (%s)
                    ON DUPLICATE KEY UPDATE
                    response_data = VALUES(response_data)
                    """
                    cursor.execute(query, (response_data,))
                    self.connection.commit()
                    print(f"[DEBUG] {file_name} 데이터 저장 성공")
        except Error as e:
            print(f"[ERROR] {file_name} 데이터 저장 중 오류 발생: {e}")
            self.connection.rollback()
        except FileNotFoundError:
            print(f"[ERROR] 파일 {file_name}을 찾을 수 없습니다.")

    def ensure_database_connection(self):
        if not self.connection.is_connected():
            print("[INFO] 데이터베이스 재연결 시도 중...")
            self.connection.reconnect(attempts=3, delay=5)

    def load_existing_hashes(self):
        self.ensure_database_connection() 
        self.cursor = self.connection.cursor() 
        print("[DEBUG] load_existing_hashes 함수 시작")
        self.existing_hashes_map.clear()
        try:
            query = "SELECT unique_key_hash, sanction_subject, sanction_id FROM Table_3st_API"
            self.cursor.execute(query)
            results = self.cursor.fetchall()
            for hash_value, subject, id in results:
                if subject is not None and id is not None:
                    self.existing_hashes_map[hash_value] = f"{subject}-{id}"

            # 기술 통계량 추가
            total_hashes = len(self.existing_hashes_map)
            print("[INFO] Loaded existing hashes:", self.existing_hashes_map)
            print(f"[INFO] 총 해시 값 건수: {total_hashes}")
        except Error as e:
            print(f"[ERROR] 데이터 불러오기 중 오류 발생: {e}")
        finally:
            self.cursor.close() 
        print("[DEBUG] load_existing_hashes 함수 종료")
    
    def close(self):
        self.driver.quit()
        self.cursor.close()
        self.connection.close()
        print("[DEBUG] 데이터베이스 연결 닫힘")

def check_data_in_database(connection):
    tables = ['Table_1st_API', 'Table_2st_API', 'Table_3st_API']
    data_objects = {}

    for table in tables:
        data_objects[table] = []
        try:
            with connection.cursor() as cursor:
                query = f"SELECT * FROM {table} LIMIT 5"  # 각 테이블에서 상위 5개 데이터 조회
                cursor.execute(query)
                results = cursor.fetchall()
                data_objects[table].extend(results)
        except mysql.connector.Error as e:
            print(f"[ERROR] 데이터 확인 중 오류 발생 ({table}): {e}")

    return data_objects

# 메인 실행 코드
if __name__ == "__main__":
    api_manager = APIManager()
    api_manager.login('goguma@krx.co.kr', 'wkrwjs12!@')
    api_manager.send_first_api_request()
    api_manager.send_second_api_request()
    for page_number in tqdm(range(1, 3), desc="Processing"):
        time.sleep(10)
        api_manager.send_third_api_request(page_number)
    api_manager.save_responses_to_database()

    # 저장된 데이터 확인 및 객체에 저장
    database_data = check_data_in_database(api_manager.connection)

    # 객체에 저장된 데이터 출력
    # for table, data in database_data.items():
    #     print(f"\n[INFO] 데이터 확인 - {table}:")
    #     for row in data:
    #         print(row)

    api_manager.close()
    print("All tasks completed.")

# %% - temp : Extract
import mysql.connector
from mysql.connector import Error

def get_all_nested_data_from_db():
    try:
        connection = mysql.connector.connect(
            host='localhost',
            database='Table_3st_API',
            user='root',
            password='wkrwjs12!@'
        )

        cursor = connection.cursor()

        query = """
        SELECT
            JSON_EXTRACT(response_data, '$.contents.files.originalFileName'),
            JSON_EXTRACT(response_data, '$.contents.ordersSectionCode'),
            JSON_EXTRACT(response_data, '$.contents.files.fileMapping.fileSubject'),
            JSON_EXTRACT(response_data, '$.contents.krxFiles.fileMapping.fileId'),
            JSON_EXTRACT(response_data, '$.contents.createDateTime'),
            JSON_EXTRACT(response_data, '$.contents.files.fileUUID'),
            JSON_EXTRACT(response_data, '$.contents.sanctionId'),
            JSON_EXTRACT(response_data, '$.contents.createEnglishFullName'),
            JSON_EXTRACT(response_data, '$.contents.sanctionSubject'),
            JSON_EXTRACT(response_data, '$.contents.ordersApprovalMappings.companyName'),
            JSON_EXTRACT(response_data, '$.contents.cancelFiles.fileMapping.realmGroupCode'),
            JSON_EXTRACT(response_data, '$.contents.krxSanctionMemo'),
            JSON_EXTRACT(response_data, '$.contents.files.fileMapping.fileOrder'),
            JSON_EXTRACT(response_data, '$.contents.cancelFiles.fileMapping.referenceId'),
            JSON_EXTRACT(response_data, '$.contents.ordersSectionName'),
            JSON_EXTRACT(response_data, '$.contents.files.fileExtension'),
            JSON_EXTRACT(response_data, '$.contents.cancelFiles.fileSize'),
            JSON_EXTRACT(response_data, '$.contents.cancelFiles.fileMapping.fileDescription'),
            JSON_EXTRACT(response_data, '$.contents.cancelFiles.fileExtension'),
            JSON_EXTRACT(response_data, '$.contents.krxFiles'),
            JSON_EXTRACT(response_data, '$.contents.files.fileMapping.realmGroupCode'),
            JSON_EXTRACT(response_data, '$.contents.cancelFiles.fileMapping.fileOrder'),
            JSON_EXTRACT(response_data, '$.contents.files.fileMapping.fileMappingId'),
            JSON_EXTRACT(response_data, '$.contents.cancelFiles.fileId'),
            JSON_EXTRACT(response_data, '$.contents.createKoreanFullName'),
            JSON_EXTRACT(response_data, '$.contents.ordersApprovalMappings.companyId'),
            JSON_EXTRACT(response_data, '$.contents.approvalLines.sanctionerTypeCode'),
            JSON_EXTRACT(response_data, '$.contents.ordersApprovalMappings.ordersId'),
            JSON_EXTRACT(response_data, '$.contents.relateSanctionSubject'),
            JSON_EXTRACT(response_data, '$.contents.sanctionTypeCode'),
            JSON_EXTRACT(response_data, '$.contents.files'),
            JSON_EXTRACT(response_data, '$.contents.cancelFiles.fileMapping.fileTypeCode'),
            JSON_EXTRACT(response_data, '$.contents.cancelFiles.fileSecurityYn'),
            JSON_EXTRACT(response_data, '$.contents.files.fileSize'),
            JSON_EXTRACT(response_data, '$.contents.approvalLines.englishFullName'),
            JSON_EXTRACT(response_data, '$.contents.cancelFiles.fileUUID'),
            JSON_EXTRACT(response_data, '$.contents.ordersApprovalMappings.sanctionId'),
            JSON_EXTRACT(response_data, '$.contents.krxFiles.fileMapping.realmGroupCode'),
            JSON_EXTRACT(response_data, '$.contents.krxFiles.fileMapping.fileSubject'),
            JSON_EXTRACT(response_data, '$.contents.krxSanctionContents'),
            JSON_EXTRACT(response_data, '$.contents.files.fileMapping.referenceId'),
            JSON_EXTRACT(response_data, '$.contents.krxFiles.fileCloudPath'),
            JSON_EXTRACT(response_data, '$.contents.sanctionMemo'),
            JSON_EXTRACT(response_data, '$.contents.krxFiles.fileUUID'),
            JSON_EXTRACT(response_data, '$.contents.cancelFiles.fileCloudPath'),
            JSON_EXTRACT(response_data, '$.contents.cancelFiles'),
            JSON_EXTRACT(response_data, '$.contents.files.fileSecurityYn'),
            JSON_EXTRACT(response_data, '$.contents.approvalLines.sanctionOpinion'),
            JSON_EXTRACT(response_data, '$.page_info.total'),
            JSON_EXTRACT(response_data, '$.contents.approvalLines.managerId'),
            JSON_EXTRACT(response_data, '$.contents.approvalLines.sanctionStatusCode'),
            JSON_EXTRACT(response_data, '$.contents.approvalLines'),
            JSON_EXTRACT(response_data, '$.unique_key_hash'),
            JSON_EXTRACT(response_data, '$.contents.files.fileMapping'),
            JSON_EXTRACT(response_data, '$.contents.krxFiles.fileMapping.fileTypeCode'),
            JSON_EXTRACT(response_data, '$.contents.relateSanctionId'),
            JSON_EXTRACT(response_data, '$.contents.approvalLines.sanctionLineId'),
            JSON_EXTRACT(response_data, '$.page_info'),
            JSON_EXTRACT(response_data, '$.contents.sanctionStatusCode'),
            JSON_EXTRACT(response_data, '$.contents.cancelFiles.fileMapping.realmGroupName'),
            JSON_EXTRACT(response_data, '$.page_info.pageNumber'),
            JSON_EXTRACT(response_data, '$.contents.approvalLines.koreanFullName'),
            JSON_EXTRACT(response_data, '$.contents.approvalLines.officialPositionName'),
            JSON_EXTRACT(response_data, '$.contents.sanctionDocumentNumber'),
            JSON_EXTRACT(response_data, '$.contents.krxFiles.fileMapping.fileMappingId'),
            JSON_EXTRACT(response_data, '$.contents.sanctionReason'),
            JSON_EXTRACT(response_data, '$.contents.krxFiles.fileExtension'),
            JSON_EXTRACT(response_data, '$.contents.ordersApprovalMappings.ordersSanctionId'),
            JSON_EXTRACT(response_data, '$.contents.cancelFiles.fileMapping.fileMappingId'),
            JSON_EXTRACT(response_data, '$.contents.krxFiles.fileSize'),
            JSON_EXTRACT(response_data, '$.contents.sanctionContents'),
            JSON_EXTRACT(response_data, '$.contents.files.fileMapping.realmGroupName'),
            JSON_EXTRACT(response_data, '$.contents.cancelFiles.fileMapping.fileSubject'),
            JSON_EXTRACT(response_data, '$.contents.krxFiles.fileMapping'),
            JSON_EXTRACT(response_data, '$.contents.files.fileId'),
            JSON_EXTRACT(response_data, '$.contents.sanctionStatusName'),
            JSON_EXTRACT(response_data, '$.contents.approvalLines.sanctionStatusName'),
            JSON_EXTRACT(response_data, '$.contents.krxFiles.fileId'),
            JSON_EXTRACT(response_data, '$.contents.approvalLines.absenceReasonCode'),
            JSON_EXTRACT(response_data, '$.contents.ordersApprovalMappings.ordersTypeName'),
            JSON_EXTRACT(response_data, '$.contents.krxFiles.fileSecurityYn'),
            JSON_EXTRACT(response_data, '$.contents.sanctionTypeName'),
            JSON_EXTRACT(response_data, '$.contents.cancelFiles.originalFileName'),
            JSON_EXTRACT(response_data, '$.contents.files.fileMapping.fileTypeCode'),
            JSON_EXTRACT(response_data, '$.contents.krxSanctionSubject'),
            JSON_EXTRACT(response_data, '$.contents.krxFiles.originalFileName'),
            JSON_EXTRACT(response_data, '$.contents.cancelFiles.fileMapping.fileId'),
            JSON_EXTRACT(response_data, '$.contents.files.fileMapping.fileId'),
            JSON_EXTRACT(response_data, '$.contents.ordersApprovalMappings.ordersSectionCode'),
            JSON_EXTRACT(response_data, '$.contents.krxFiles.fileMapping.realmGroupName'),
            JSON_EXTRACT(response_data, '$.contents.approvalLines.absenceReasonDescription'),
            JSON_EXTRACT(response_data, '$.contents.approvalLines.userId'),
            JSON_EXTRACT(response_data, '$.contents.ordersPauseRequestApprovalMappings'),
            JSON_EXTRACT(response_data, '$.contents.files.fileCloudPath'),
            JSON_EXTRACT(response_data, '$.contents.files.fileMapping.fileDescription'),
            JSON_EXTRACT(response_data, '$.contents.krxFiles.fileMapping.fileDescription'),
            JSON_EXTRACT(response_data, '$.page_info.pageSize'),
            JSON_EXTRACT(response_data, '$.contents.approvalLines.sanctionOrder'),
            JSON_EXTRACT(response_data, '$.page_info.totalPage'),
            JSON_EXTRACT(response_data, '$.contents.ordersApprovalMappings'),
            JSON_EXTRACT(response_data, '$.sanction_subject'),
            JSON_EXTRACT(response_data, '$.contents.approvalLines.absenceYn'),
            JSON_EXTRACT(response_data, '$.contents.krxFiles.fileMapping.referenceId'),
            JSON_EXTRACT(response_data, '$.contents.cancelFiles.fileMapping'),
            JSON_EXTRACT(response_data, '$.contents.updateDateTime')
        FROM api_responses
        """
        cursor.execute(query)
        rows = cursor.fetchall()
        for row in rows:
            print(row)

        return rows  # rows 반환

    except Error as e:
        print(f"Error: {e}")
        return None  # 오류 발생 시 None 반환
    finally:
        if connection.is_connected():
            cursor.close()
            connection.close()

# 함수 호출 및 결과 저장
rows = get_all_nested_data_from_db()
# %% - temp : Nested Key
import mysql.connector
import json

def extract_nested_keys(data, parent_key=''):
    """
    재귀적으로 중첩된 JSON 키 추출
    :param data: JSON 데이터
    :param parent_key: 부모 키 (상위 계층의 키)
    :return: 중첩된 키들의 집합
    """
    nested_keys = set()

    if isinstance(data, dict):
        for key, value in data.items():
            full_key = f"{parent_key}.{key}" if parent_key else key
            nested_keys.add(full_key)
            nested_keys |= extract_nested_keys(value, full_key)

    elif isinstance(data, list):
        for item in data:
            nested_keys |= extract_nested_keys(item, parent_key)

    return nested_keys

try:
    # 데이터베이스 연결 설정
    connection = mysql.connector.connect(
        host='localhost',
        database='first_api_tables',  # 데이터베이스 이름
        user='root',                  # 사용자 이름
        password='wkrwjs12!@'         # 비밀번호
    )
    cursor = connection.cursor()
    query = "SELECT response_data FROM api_responses"  # 적절한 테이블 이름과 열 이름
    cursor.execute(query)
    results = cursor.fetchall()

    all_nested_keys = set()
    for (response_data,) in results:
        response_json = json.loads(response_data)
        nested_keys = extract_nested_keys(response_json)
        all_nested_keys |= nested_keys

    print("All nested data keys:", all_nested_keys)

except mysql.connector.Error as e:
    print(f"Error: {e}")

finally:
    if connection.is_connected():
        cursor.close()
        connection.close()
        print("MySQL connection is closed")
# %% - temp : Print 
import mysql.connector
from mysql.connector import Error

def show_databases(cursor):
    try:
        cursor.execute("SHOW DATABASES")
        databases = cursor.fetchall()
        print("Available databases:")
        for db in databases:
            print(db[0])
    except Error as e:
        print(f"[ERROR] 데이터베이스 조회 중 오류 발생: {e}")

def main():
    try:
        connection = mysql.connector.connect(
            host='localhost',
            user='root',
            password='wkrwjs12!@'
        )
        if connection.is_connected():
            cursor = connection.cursor()
            show_databases(cursor)
    except Error as e:
        print(f"[ERROR] 데이터베이스 연결 중 오류 발생: {e}")
    finally:
        if connection.is_connected():
            cursor.close()
            connection.close()
            print("[DEBUG] 데이터베이스 연결 닫힘")

if __name__ == "__main__":
    main()
# %% -temp : debugging
import mysql.connector
from mysql.connector import Error

try:
    # 데이터베이스 연결 설정
    connection = mysql.connector.connect(
        host='localhost',
        database='First_API_Tables',
        user='root',
        password='wkrwjs12!@'
    )

    if connection.is_connected():
        db_info = connection.get_server_info()
        print("MySQL 서버 버전:", db_info)

        cursor = connection.cursor()
        cursor.execute("SELECT * FROM api_responses")  # 예시로 api_responses 테이블을 사용
        records = cursor.fetchall()
        print("데이터베이스의 모든 데이터:")
        for row in records:
            print(row)

except Error as e:
    print("데이터베이스 연결 또는 쿼리 실행 중 오류 발생:", e)

finally:
    if connection.is_connected():
        cursor.close()
        connection.close()
        print("MySQL 연결 종료")

# %% - temp : Delete
import mysql.connector
from mysql.connector import Error

def connect_to_database(host, database, user, password):
    try:
        connection = mysql.connector.connect(
            host=host,
            database=database,
            user=user,
            password=password
        )
        return connection
    except Error as e:
        print(f"Error connecting to MySQL database: {e}")
        return None

def reset_table(connection, table_name):
    try:
        cursor = connection.cursor()
        cursor.execute(f"TRUNCATE TABLE {table_name}")
        connection.commit()
        print(f"Table '{table_name}' has been reset.")
    except Error as e:
        print(f"Error resetting table {table_name}: {e}")

def main():
    host = 'localhost'        # MySQL 서버 주소
    database = 'First_API_Tables'  # 데이터베이스 이름
    user = 'root'             # MySQL 사용자 이름
    password = 'wkrwjs12!@'    # MySQL 비밀번호
    table_name = 'api_responses'  # 초기화할 테이블 이름

    connection = connect_to_database(host, database, user, password)
    if connection is not None:
        reset_table(connection, table_name)
        connection.close()

if __name__ == "__main__":
    main()


# %% - temp
import mysql.connector
from mysql.connector import Error

def check_database():
    try:
        # 데이터베이스 연결 설정
        connection = mysql.connector.connect(
            host='localhost',
            database='First_API_Tables',
            user='root',
            password='wkrwjs12!@'
        )

        if connection.is_connected():
            db_info = connection.get_server_info()
            print("Connected to MySQL Server version ", db_info)
            cursor = connection.cursor()

            # api_responses 테이블에서 unique_key_hash, sanction_subject, sanction_id 조회
            cursor.execute("SELECT unique_key_hash, sanction_subject, sanction_id FROM api_responses")
            records = cursor.fetchall()

            print("Total number of rows in api_responses is: ", cursor.rowcount)
            print("\nPrinting each row")
            for row in records:
                print("Hash = ", row[0], )
                print("Subject = ", row[1])
                print("ID = ", row[2], "\n")

    except Error as e:
        print("Error while connecting to MySQL", e)
    finally:
        # 데이터베이스 연결 종료
        if connection.is_connected():
            cursor.close()
            connection.close()
            print("MySQL connection is closed")

# 함수 호출
check_database()

# %% - temp 
import mysql.connector
from mysql.connector import Error
import json

def fetch_and_analyze_json_data():
    try:
        # 데이터베이스 연결 설정
        connection = mysql.connector.connect(
            host='localhost',
            database='First_API_Tables',
            user='root',
            password='wkrwjs12!@'
        )
        if connection.is_connected():
            cursor = connection.cursor()
            query = "SELECT response_data FROM api_responses LIMIT 5"  # 첫 5개의 JSON 데이터를 추출
            cursor.execute(query)

            # 파일에 JSON 데이터 분석 결과 저장
            with open('json_data_analysis.txt', 'w', encoding='utf-8') as file:
                results = cursor.fetchall()
                for idx, result in enumerate(results, start=1):
                    json_data = json.loads(result[0])  # JSON 데이터 로딩
                    file.write(f"Data #{idx}:\n")
                    analyze_json_structure(json_data, 0, file)  # JSON 구조 분석 및 파일에 출력
                    file.write("-" * 50 + "\n")

    except Error as e:
        print(f"데이터베이스 접근 중 에러 발생: {e}")
    finally:
        if connection and connection.is_connected():
            cursor.close()
            connection.close()

def analyze_json_structure(data, level, file):
    indent = "  " * level
    if isinstance(data, dict):
        file.write(f"{indent}Object with keys: {list(data.keys())}\n")
        for key, value in data.items():
            file.write(f"{indent}  Key: {key}\n")
            analyze_json_structure(value, level + 1, file)
    elif isinstance(data, list):
        file.write(f"{indent}List with {len(data)} items\n")
        for item in data:
            analyze_json_structure(item, level + 1, file)
    else:
        file.write(f"{indent}Value: {type(data).__name__}\n")

# 함수 호출
fetch_and_analyze_json_data()
# %% ○ (9) DB SQL 
# %% (9)-(i)
import mysql.connector
from mysql.connector import Error

# 데이터베이스 연결 정보
host_name = "127.0.0.1"
port = 3306
username = "root"
password = "wkrwjs12!@"  # 제공하신 비밀번호로 설정
database_name = "First_API_Tables"  # 데이터베이스 이름을 'First_API_Tables'로 설정

# 데이터베이스 연결 및 테이블 생성 함수
def create_database_and_table():
    try:
        # MySQL 데이터베이스 연결
        connection = mysql.connector.connect(
            host=host_name,
            port=port,
            user=username,
            password=password
        )
        
        if connection.is_connected():
            db_cursor = connection.cursor()

            # 데이터베이스 'First_API_Tables' 생성
            db_cursor.execute(f"CREATE DATABASE IF NOT EXISTS {database_name}")
            db_cursor.execute(f"USE {database_name}")
            
            # 'api_responses' 테이블 생성
            create_table_query = '''
            CREATE TABLE IF NOT EXISTS api_responses (
                page_number INT PRIMARY KEY,
                response_data JSON
            );
            '''
            db_cursor.execute(create_table_query)
            print("데이터베이스 'First_API_Tables'와 테이블 'api_responses'가 성공적으로 생성되었습니다.")
            connection.commit()

    except Error as e:
        print("MySQL 데이터베이스와의 연결에서 에러가 발생했습니다:", e)
    finally:
        if connection.is_connected():
            db_cursor.close()
            connection.close()
            print("MySQL 연결이 종료되었습니다.")

# 실행
create_database_and_table()
 



