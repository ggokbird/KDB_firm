# %% 240116 Koscom_dataservice With FastAPI
"""
# http://127.0.0.1:8000/redoc
# http://127.0.0.1:8000/docs 
"""
    
# %% 동적 생성
# %% 240116 Koscom_dataservice With FastAPI
"""
# http://127.0.0.1:8000/redoc
# http://127.0.0.1:8000/docs 
# SET RUN_DATA_COLLECTION=true
# uvicorn main:app --reload
"""
import os
import asyncio
import json
import subprocess
import socket
from typing import Any, Dict, List, Type
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, create_model
import mysql.connector
from Koscom_dataservice import APIManager

app = FastAPI()

# 데이터베이스 연결 정보
db_host = os.getenv("DB_HOST", "localhost")
db_name = os.getenv("DB_NAME", "first_api_tables")
db_user = os.getenv("DB_USER", "root")
db_password = os.getenv("DB_PASSWORD", "wkrwjs12!@")

# 동적 Pydantic 모델 생성 함수
def generate_dynamic_model(data: Any, model_name: str = "DynamicModel") -> Type[BaseModel]:
    if isinstance(data, dict):
        fields = {k: (v, ...) for k, v in data.items()}
        return create_model(model_name, **fields)
    elif isinstance(data, list) and data:
        item_model = generate_dynamic_model(data[0], model_name + "Item")
        return create_model(model_name + "List", __root__=(List[item_model], ...))
    return create_model(model_name, __root__=(data, ...))

# 데이터베이스에서 데이터를 가져오는 API 경로
@app.get("/dynamic-items/{table_name}", response_model=List[BaseModel])
async def read_dynamic_items(table_name: str):
    connection = mysql.connector.connect(host=db_host, database=db_name, user=db_user, password=db_password)
    cursor = connection.cursor()
    cursor.execute(f"SELECT response_data FROM {table_name}")
    rows = cursor.fetchall()
    connection.close()
    if not rows:
        raise HTTPException(status_code=404, detail="Table not found")
    json_data = [json.loads(row[0]) for row in rows]
    DynamicModel = generate_dynamic_model(json_data[0])
    return [DynamicModel(**item) for item in json_data]

# 포트 사용 여부 확인 함수
def is_port_in_use(port):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        return s.connect_ex(('localhost', port)) == 0

# 특정 포트에서 프로세스 종료 함수 (Windows 전용)
def kill_process_on_port(port):
    try:
        print(f"Checking for processes on port {port}...")
        cmd_find_pid = f"netstat -ano | findstr :{port}"
        process = subprocess.Popen(cmd_find_pid, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        stdout, stderr = process.communicate()

        if stderr:
            print(f"Error finding process on port {port}: {stderr.decode()}")
            return False

        lines = stdout.decode().splitlines()
        if not lines:
            print(f"No processes found on port {port}.")
            return True

        for line in lines:
            parts = line.strip().split()
            if len(parts) > 4 and parts[1].endswith(f":{port}"):
                pid = parts[4]
                print(f"Process found on port {port}, PID: {pid}. Attempting to kill...")
                os.system(f"taskkill /PID {pid} /F")
                print(f"Killed process {pid} on port {port}")
                return True

    except Exception as e:
        print(f"Error occurred while trying to kill process on port {port}: {e}")
    return False

# 데이터 수집을 위한 백그라운드 작업 함수
async def background_data_collection():
    if os.getenv("RUN_DATA_COLLECTION", "false").lower() == "true":
        api_manager = APIManager()
        try:
            print("Data collection started")
            await asyncio.to_thread(api_manager.login, 'goguma@krx.co.kr', 'wkrwjs12!@')
            await asyncio.to_thread(api_manager.send_first_api_request)
            await asyncio.to_thread(api_manager.send_second_api_request)
            for page_number in range(1, api_manager.totalPage + 1):
                await asyncio.to_thread(api_manager.send_third_api_request, page_number)
            await asyncio.to_thread(api_manager.save_responses_to_database)
            print("Data collection completed")
        except Exception as e:
            print(f"Data collection error: {e}")
            api_manager.close()

def main():
    print("Starting application...")
    if is_port_in_use(8000):
        if not kill_process_on_port(8000):
            print("Failed to free port 8000. Exiting...")
            return
        else:
            print("Port 8000 freed successfully. Continuing...")

    loop = asyncio.get_event_loop()
    if not loop.is_running():
        asyncio.set_event_loop(loop)
        loop.create_task(background_data_collection())
        print("Background data collection task created.")

    from threading import Thread
    def run_server():
        import uvicorn
        print("Attempting to start the server...")
        uvicorn.run(app, host="0.0.0.0", port=8000, log_level="info")
        print("Server should be running now.")

    server_thread = Thread(target=run_server)
    server_thread.start()
    print("Server thread started.")

if __name__ == "__main__":
    main()

# %% Canclation 入 (Ctrl + C 可)
import os
import asyncio
import aiomysql
import socket
import logging
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, create_model
from typing import Any, List, Type
from dotenv import load_dotenv
from Koscom_dataservice import APIManager
import uvicorn
import subprocess
import json

# Configure logging
logging.basicConfig(level=logging.WARNING)  # 로그 레벨 변경
logger = logging.getLogger(__name__)

# SeleniumWire의 로거 레벨을 조정
seleniumwire_logger = logging.getLogger('seleniumwire.handler')
seleniumwire_logger.setLevel(logging.WARNING)

# Load environment variables
load_dotenv()

app = FastAPI()

# Database connection information
db_host = os.getenv("DB_HOST", "localhost")
db_name = os.getenv("DB_NAME", "first_api_tables")
db_user = os.getenv("DB_USER", "root")
db_password = os.getenv("DB_PASSWORD", "password")

# Function to generate dynamic Pydantic model
def generate_dynamic_model(data: Any, model_name: str = "DynamicModel") -> Type[BaseModel]:
    if isinstance(data, dict):
        fields = {k: (v, ...) for k, v in data.items()}
        return create_model(model_name, **fields)
    elif isinstance(data, list) and data:
        item_model = generate_dynamic_model(data[0], model_name + "Item")
        return create_model(model_name + "List", __root__=(List[item_model], ...))
    return create_model(model_name, __root__=(data, ...))

# Async function to get database connection
async def get_db_connection():
    return await aiomysql.connect(host=db_host, db=db_name, user=db_user, password=db_password, cursorclass=aiomysql.DictCursor)

# Async FastAPI route to read dynamic items
@app.get("/dynamic-items/{table_name}", response_model=List[BaseModel])
async def read_dynamic_items(table_name: str):
    connection = await get_db_connection()
    async with connection.cursor() as cursor:
        await cursor.execute(f"SELECT response_data FROM {table_name}")
        rows = await cursor.fetchall()
    connection.close()
    if not rows:
        raise HTTPException(status_code=404, detail="Table not found")
    json_data = [json.loads(row['response_data']) for row in rows]
    DynamicModel = generate_dynamic_model(json_data[0])
    return [DynamicModel(**item) for item in json_data]

# Function to check if a port is in use
def is_port_in_use(port):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        return s.connect_ex(('localhost', port)) == 0

# Function to kill process on a specific port
def kill_process_on_port(port):
    try:
        result = subprocess.run(['netstat', '-ano'], capture_output=True, text=True)
        lines = result.stdout.splitlines()
        for line in lines:
            if f":{port}" in line:
                parts = line.strip().split()
                pid = parts[-1]
                subprocess.run(f"taskkill /F /PID {pid}", shell=True)
                logger.info(f"Killed process with PID {pid} on port {port}")
                return True
    except Exception as e:
        logger.error(f"Error killing process on port {port}: {e}")
        return False

# Async background data collection function
async def background_data_collection():
    api_manager = APIManager()
    await api_manager.login('goguma@krx.co.kr', 'wkrwjs12!@')  # Use provided credentials

    # API data collection logic
    await api_manager.send_first_api_request()
    await api_manager.send_second_api_request()

    for page_number in range(1, 3):  # Example of iterating through page numbers
        await api_manager.send_third_api_request(page_number)
    
    await api_manager.save_responses_to_database()  # Save the collected data to the database

# FastAPI 앱을 비동기적으로 실행하는 함수
async def run_app():
    config = uvicorn.Config(app, host="0.0.0.0", port=8000, log_level="info")
    server = uvicorn.Server(config)
    await server.serve()

# 메인 함수
async def main():
    if is_port_in_use(8000):
        logger.info("Port 8000 is already in use. Attempting to free the port...")
        if not kill_process_on_port(8000):
            logger.error("Failed to free port 8000. Exiting...")
            return

    # 데이터 수집 작업
    bg_task = asyncio.create_task(background_data_collection())

    # 서버 실행 작업
    server_task = asyncio.create_task(run_app())

    # 데이터 수집 작업이 완료될 때까지 기다림
    await bg_task

    # 서버 작업을 계속 실행
    try:
        await server_task
    except KeyboardInterrupt:
        logger.info("Keyboard interrupt received, shutting down...")
    finally:
        server_task.cancel()
        logger.info("Server shut down successfully.")

# 메인 함수를 이벤트 루프에서 실행
if __name__ == "__main__":
    loop = asyncio.get_event_loop()
    if loop.is_running():
        loop.create_task(main())
    else:
        loop.run_until_complete(main())

# %% Canclation 入 (Ctrl + C 可)
import os
import asyncio
import aiomysql
import socket
import logging
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, create_model
from typing import Any, List, Type
from dotenv import load_dotenv
from Koscom_dataservice import APIManager
import uvicorn
import subprocess
import asyncio
import json

# Configure logging
logging.basicConfig(level=logging.WARNING)  # 로그 레벨 변경
logger = logging.getLogger(__name__)

# SeleniumWire의 로거 레벨을 조정
seleniumwire_logger = logging.getLogger('seleniumwire.handler')
seleniumwire_logger.setLevel(logging.WARNING)

# Load environment variables
load_dotenv()

app = FastAPI()

# Database connection information
db_host = os.getenv("DB_HOST", "localhost")
db_name = os.getenv("DB_NAME", "first_api_tables")
db_user = os.getenv("DB_USER", "root")
db_password = os.getenv("DB_PASSWORD", "password")

# Function to generate dynamic Pydantic model
def generate_dynamic_model(data: Any, model_name: str = "DynamicModel") -> Type[BaseModel]:
    if isinstance(data, dict):
        fields = {k: (v, ...) for k, v in data.items()}
        return create_model(model_name, **fields)
    elif isinstance(data, list) and data:
        item_model = generate_dynamic_model(data[0], model_name + "Item")
        return create_model(model_name + "List", __root__=(List[item_model], ...))
    return create_model(model_name, __root__=(data, ...))

# Async function to get database connection
async def get_db_connection():
    return await aiomysql.connect(host=db_host, db=db_name, user=db_user, password=db_password, cursorclass=aiomysql.DictCursor)

# Async FastAPI route to read dynamic items
@app.get("/dynamic-items/{table_name}", response_model=List[BaseModel])
async def read_dynamic_items(table_name: str):
    connection = await get_db_connection()
    async with connection.cursor() as cursor:
        await cursor.execute(f"SELECT response_data FROM {table_name}")
        rows = await cursor.fetchall()
    connection.close()
    if not rows:
        raise HTTPException(status_code=404, detail="Table not found")
    json_data = [json.loads(row['response_data']) for row in rows]
    DynamicModel = generate_dynamic_model(json_data[0])
    return [DynamicModel(**item) for item in json_data]

# Function to check if a port is in use
def is_port_in_use(port):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        return s.connect_ex(('localhost', port)) == 0

# Function to kill process on a specific port
def kill_process_on_port(port):
    try:
        result = subprocess.run(['netstat', '-ano'], capture_output=True, text=True)
        lines = result.stdout.splitlines()
        for line in lines:
            if f":{port}" in line:
                parts = line.strip().split()
                pid = parts[-1]
                subprocess.run(f"taskkill /F /PID {pid}", shell=True)
                logger.info(f"Killed process with PID {pid} on port {port}")
                return True
    except Exception as e:
        logger.error(f"Error killing process on port {port}: {e}")
        return False

# Async background data collection function
async def background_data_collection():
    api_manager = APIManager()
    await api_manager.login('goguma@krx.co.kr', 'wkrwjs12!@')  # Use provided credentials

    # API data collection logic
    await api_manager.send_first_api_request()
    await api_manager.send_second_api_request()

    for page_number in range(1, 3):  # Example of iterating through page numbers
        await api_manager.send_third_api_request(page_number)
    
    await api_manager.save_responses_to_database()  # Save the collected data to the database

# FastAPI 앱을 비동기적으로 실행하는 함수
async def run_app():
    config = uvicorn.Config(app, host="0.0.0.0", port=8000, log_level="info")
    server = uvicorn.Server(config)
    await server.serve()

# 메인 함수
async def main():
    if is_port_in_use(8000):
        logger.info("Port 8000 is already in use. Attempting to free the port...")
        if not kill_process_on_port(8000):
            logger.error("Failed to free port 8000. Exiting...")
            return

    # 데이터 수집 작업
    bg_task = asyncio.create_task(background_data_collection())

    # 서버 실행 작업
    server_task = asyncio.create_task(run_app())

    # 데이터 수집 작업이 완료될 때까지 기다림
    await bg_task

    # 서버 작업을 계속 실행
    try:
        await server_task
    except KeyboardInterrupt:
        logger.info("Keyboard interrupt received, shutting down...")
    finally:
        server_task.cancel()
        logger.info("Server shut down successfully.")

# 메인 함수를 이벤트 루프에서 실행
if __name__ == "__main__":
    loop = asyncio.get_event_loop()
    if loop.is_running():
        loop.create_task(main())
    else:
        loop.run_until_complete(main())

# %%
import os
import asyncio
import aiomysql
import socket
import logging
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, create_model
from typing import Any, List, Type
from dotenv import load_dotenv
from Koscom_dataservice import APIManager
import uvicorn
import subprocess
import json

# 로깅 설정
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# SeleniumWire의 로거 레벨 조정
seleniumwire_logger = logging.getLogger('seleniumwire.handler')
seleniumwire_logger.setLevel(logging.WARNING)

# 환경 변수 로드
load_dotenv()

# FastAPI 앱 인스턴스 생성
app = FastAPI()

# 데이터베이스 연결 정보
db_host = os.getenv("DB_HOST", "localhost")
db_name = os.getenv("DB_NAME", "first_api_tables")
db_user = os.getenv("DB_USER", "root")
db_password = os.getenv("DB_PASSWORD", "password")

# 동적 Pydantic 모델 생성 함수
def generate_dynamic_model(data: Any, model_name: str = "DynamicModel") -> Type[BaseModel]:
    if isinstance(data, dict):
        fields = {k: (v, ...) for k, v in data.items()}
        return create_model(model_name, **fields)
    elif isinstance(data, list) and data:
        item_model = generate_dynamic_model(data[0], model_name + "Item")
        return create_model(model_name + "List", __root__=(List[item_model], ...))
    return create_model(model_name, __root__=(data, ...))

# 데이터베이스 연결을 위한 비동기 함수
async def get_db_connection():
    return await aiomysql.connect(host=db_host, db=db_name, user=db_user, password=db_password, cursorclass=aiomysql.DictCursor)

# 동적 아이템을 읽기 위한 FastAPI 경로
@app.get("/dynamic-items/{table_name}", response_model=List[BaseModel])
async def read_dynamic_items(table_name: str):
    connection = await get_db_connection()
    async with connection.cursor() as cursor:
        await cursor.execute(f"SELECT response_data FROM {table_name}")
        rows = await cursor.fetchall()
    connection.close()
    if not rows:
        raise HTTPException(status_code=404, detail="Table not found")
    json_data = [json.loads(row['response_data']) for row in rows]
    DynamicModel = generate_dynamic_model(json_data[0])
    return [DynamicModel(**item) for item in json_data]

# 포트 사용 여부 확인 함수
def is_port_in_use(port):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        return s.connect_ex(('localhost', port)) == 0

# 특정 포트에서 프로세스 종료 함수
def kill_process_on_port(port):
    try:
        result = subprocess.run(['netstat', '-ano'], capture_output=True, text=True)
        lines = result.stdout.splitlines()
        for line in lines:
            if f":{port}" in line:
                parts = line.strip().split()
                pid = parts[-1]
                subprocess.run(f"taskkill /F /PID {pid}", shell=True)
                logger.info(f"Killed process with PID {pid} on port {port}")
                return True
    except Exception as e:
        logger.error(f"Error killing process on port {port}: {e}")
        return False

# 비동기적으로 백그라운드 데이터 수집 함수
async def background_data_collection():
    api_manager = APIManager()
    await api_manager.login('goguma@krx.co.kr', 'wkrwjs12!@')

    # API 데이터 수집 로직
    await api_manager.send_first_api_request()
    await api_manager.send_second_api_request()

    for page_number in range(1, 3):
        await api_manager.send_third_api_request(page_number)

    await api_manager.save_responses_to_database()

# FastAPI 앱을 비동기적으로 실행하는 함수
async def run_app():
    config = uvicorn.Config(app, host="0.0.0.0", port=8000, log_level="info")
    server = uvicorn.Server(config)
    await server.serve()

# 메인 함수
async def main():
    if is_port_in_use(8000):
        logger.info("Port 8000 is already in use. Attempting to free the port...")
        if not kill_process_on_port(8000):
            logger.error("Failed to free port 8000. Exiting...")
            return

    # 데이터 수집 작업
    bg_task = asyncio.create_task(background_data_collection())

    # 서버 실행 작업
    server_task = asyncio.create_task(run_app())

    # 데이터 수집 작업이 완료될 때까지 기다림
    await bg_task

    # 서버 작업을 계속 실행
    try:
        await server_task
    except KeyboardInterrupt:
        logger.info("Keyboard interrupt received, shutting down...")
    finally:
        server_task.cancel()
        logger.info("Server shut down successfully.")

# 메인 함수를 이벤트 루프에서 실행
if __name__ == "__main__":
    loop = asyncio.get_event_loop()
    loop.run_until_complete(main())

# %% Structure Main
from fastapi import FastAPI, HTTPException, Depends
from pydantic import BaseModel, create_model
from typing import Any, List, Dict
import aiomysql
import uvicorn
import asyncio
import json

app = FastAPI()

DATABASE_CONFIG = {
    'host': 'localhost',
    'port': 3306,
    'user': 'root',
    'password': 'wkrwjs12!@',
    'db': 'first_api_tables'
}

async def get_db_connection():
    print("Connecting to the database...")
    conn = await aiomysql.connect(
        host=DATABASE_CONFIG['host'],
        port=DATABASE_CONFIG['port'],
        user=DATABASE_CONFIG['user'],
        password=DATABASE_CONFIG['password'],
        db=DATABASE_CONFIG['db'],
        cursorclass=aiomysql.DictCursor
    )
    print("Database connection established.")
    try:
        yield conn
    finally:
        conn.close()
        print("Database connection closed.")

def get_paths_from_json(json_obj: Dict, parent_key: str = '') -> List[str]:
    paths = []
    for k, v in json_obj.items():
        full_key = f"{parent_key}.{k}" if parent_key else k
        if isinstance(v, dict):
            paths.extend(get_paths_from_json(v, full_key))
        else:
            paths.append(full_key)
    return paths

async def generate_paths_and_response_model(conn: aiomysql.Connection) -> (str, Any):
    print("Generating paths and response model...")
    async with conn.cursor() as cursor:
        await cursor.execute("SELECT response_data FROM api_responses LIMIT 1")
        result = await cursor.fetchone()
        if not result:
            raise HTTPException(status_code=404, detail="No data found for introspection")
        
        sample_json = result['response_data']
        paths = get_paths_from_json(sample_json)
        
        select_clause = []
        response_fields = {}
        for path in paths:
            alias = path.split('.')[-1].replace('$', '')  # Sanitize the JSON path to create a valid alias
            select_clause.append(f"JSON_EXTRACT(response_data, '{path}') AS `{alias}`")
            response_fields[alias] = (Any, None)
        
        DynamicModel = create_model('DynamicModel', **response_fields)  # Dynamically create a Pydantic model
        print(f"Generated SELECT clause: {select_clause}")
        print(f"Generated model fields: {response_fields}")
        return ", ".join(select_clause), DynamicModel

@app.get("/items/all", response_model=List[Any])
async def read_all_items(conn: aiomysql.Connection = Depends(get_db_connection)):
    print("Reading all items...")
    select_clause, response_model = await generate_paths_and_response_model(conn)
    query = f"""
    SELECT {select_clause}
    FROM api_responses
    """
    async with conn.cursor() as cursor:
        await cursor.execute(query)
        rows = await cursor.fetchall()
        if rows:
            print(f"Retrieved rows: {json.dumps([dict(row) for row in rows], indent=2)}")
            return [dict(row) for row in rows]
        else:
            print("No items found.")
            raise HTTPException(status_code=404, detail="Items not found")

if __name__ == "__main__":
    # Check if the event loop is already running
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:  # No running event loop
        loop = None
    
    if loop and loop.is_running():
        # Running inside existing event loop
        config = uvicorn.Config(app=app, host="0.0.0.0", port=8000)
        server = uvicorn.Server(config)
        loop.create_task(server.serve())
    else:
        # Start Uvicorn with the standard method
        uvicorn.run(app, host="0.0.0.0", port=8000)

# %% Unit test 
from typing import Dict, List, Any
from pydantic import create_model
import json

# Sample JSON data for demonstration purposes
sample_json_data = {
    "contents": {
        "files": {
            "originalFileName": "example.txt",
            "fileUUID": "123e4567-e89b-12d3-a456-426614174000"
        },
        "ordersSectionCode": "ABC123",
        "createDateTime": "2021-01-01T12:00:00Z"
    }
}

# Function to extract JSON paths
def get_paths_from_json(json_obj: Dict, parent_key: str = '') -> List[str]:
    paths = []
    for k, v in json_obj.items():
        full_key = f"{parent_key}.{k}" if parent_key else k
        if isinstance(v, dict):
            paths.extend(get_paths_from_json(v, full_key))
        else:
            paths.append(full_key)
    return paths

# Function to generate SQL SELECT clause and Pydantic model based on JSON paths
def generate_paths_and_response_model(json_data: Dict) -> (str, Any):
    paths = get_paths_from_json(json_data)
    
    select_clause = []
    response_fields = {}
    for path in paths:
        alias = path.split('.')[-1].replace('$', '')  # Sanitize the JSON path to create a valid alias
        select_clause.append(f"JSON_EXTRACT(response_data, '{path}') AS `{alias}`")
        response_fields[alias] = (Any, ...)
    
    DynamicModel = create_model('DynamicModel', **response_fields)
    
    return ", ".join(select_clause), DynamicModel

# Call the function and store the results in variables
select_clause, dynamic_response_model = generate_paths_and_response_model(sample_json_data)

# Convert the dynamic model to a dictionary for Variable Explorer
# Use __annotations__ to access the types of the fields
dynamic_model_dict = {name: str(annotation) for name, annotation in dynamic_response_model.__annotations__.items()}

# Print the output for debugging purposes
print("SQL SELECT Clause:")
print(select_clause)
print("\nDynamic Response Model:")
print(dynamic_model_dict)
# %% Unit test + SQL 
import mysql.connector
from mysql.connector import Error
import json
from typing import Dict, List, Any
from pydantic import create_model

# 데이터베이스 설정
DATABASE_CONFIG = {
    'host': 'localhost',
    'database': 'first_api_tables',
    'user': 'root',
    'password': 'wkrwjs12!@'
}

# 데이터베이스 연결 함수
def get_db_connection():
    return mysql.connector.connect(**DATABASE_CONFIG)

# JSON 경로 추출 함수
def get_paths_from_json(json_obj: Dict, parent_key: str = '') -> List[str]:
    paths = []
    for k, v in json_obj.items():
        full_key = f"{parent_key}.{k}" if parent_key else k
        if isinstance(v, dict):
            paths.extend(get_paths_from_json(v, full_key))
        elif isinstance(v, list) and v and isinstance(v[0], dict):
            # 리스트 내의 첫 번째 항목이 딕셔너리인 경우, 해당 구조를 반복
            for item in v:
                paths.extend(get_paths_from_json(item, full_key))
        else:
            paths.append(full_key)
    return paths

# 동적 SQL 절 및 Pydantic 모델 생성 함수
def generate_dynamic_query_and_model(json_data: Dict) -> (str, Any):
    paths = get_paths_from_json(json_data)
    select_clause = ", ".join([f"JSON_EXTRACT(response_data, '{path}') AS `{path.split('.')[-1]}`" for path in paths])
    response_fields = {path.split('.')[-1]: (Any, ...) for path in paths}
    DynamicModel = create_model('DynamicModel', **response_fields)
    return select_clause, DynamicModel

# 메인 함수
def main():
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT response_data FROM api_responses LIMIT 1")
        row = cursor.fetchone()
        if row:
            json_data = json.loads(row[0])
            select_clause, DynamicModel = generate_dynamic_query_and_model(json_data)
            print("SQL SELECT Clause:", select_clause)
            print("Dynamic Model:", DynamicModel.schema_json(indent=2))
        else:
            print("No data found.")
    except Error as e:
        print("Database error:", e)
    finally:
        if conn.is_connected():
            cursor.close()
            conn.close()

if __name__ == "__main__":
    main()

# %% Unit test + SQL + Fast API
from fastapi import FastAPI, HTTPException, APIRouter
import mysql.connector
from mysql.connector import Error
import json
from typing import Dict, List

app = FastAPI()
router = APIRouter()

# 데이터베이스 설정
DATABASE_CONFIG = {
    'host': 'localhost',
    'database': 'first_api_tables',
    'user': 'root',
    'password': 'wkrwjs12!@'
}

# 데이터베이스 연결 함수
def get_db_connection():
    try:
        return mysql.connector.connect(**DATABASE_CONFIG)
    except Error as e:
        print(f"Error connecting to the database: {e}")
        return None

# JSON 경로 추출 함수
def get_paths_from_json(json_obj: dict, parent_key: str = '') -> list:
    paths = []
    for k, v in json_obj.items():
        full_key = f"{parent_key}.{k}" if parent_key else k
        if isinstance(v, dict):
            paths.extend(get_paths_from_json(v, full_key))
        elif isinstance(v, list) and v and isinstance(v[0], dict):
            for item in v:
                paths.extend(get_paths_from_json(item, full_key))
        else:
            paths.append(full_key)
    return paths

# SQL 쿼리 및 엔드포인트 생성 함수
def create_endpoints_from_query():
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT response_data FROM api_responses LIMIT 1")
        row = cursor.fetchone()
        if row:
            json_data = json.loads(row[0])
            paths = get_paths_from_json(json_data)

            for path in paths:
                endpoint_path = path.replace('.', '_') # 경로를 엔드포인트 경로로 변환
                json_path = "$." + path # JSON 경로 형식으로 변환

                @router.get(f"/{endpoint_path}", summary=f"Get data for {path}", description=f"Retrieves data from the path {path} in the database.")
                async def endpoint_function():
                    try:
                        conn_inner = get_db_connection()
                        cursor_inner = conn_inner.cursor()
                        query = f"SELECT JSON_UNQUOTE(JSON_EXTRACT(response_data, '{json_path}')) FROM api_responses WHERE JSON_EXTRACT(response_data, '{json_path}') IS NOT NULL"
                        cursor_inner.execute(query)
                        result = cursor_inner.fetchone()
                        return {path: result[0] if result else None}
                    except Error as e:
                        raise HTTPException(status_code=500, detail=str(e))
                    finally:
                        if conn_inner.is_connected():
                            cursor_inner.close()
                            conn_inner.close()

    except Error as e:
        print("Database error:", e)
    finally:
        if conn and conn.is_connected():
            cursor.close()
            conn.close()

# 메인 함수
def main():
    create_endpoints_from_query()
    app.include_router(router)

if __name__ == "__main__":
    main()
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
    
# %% Unit test + SQL + Fast API + contents involvedfrom fastapi import FastAPI, HTTPException
import mysql.connector
from mysql.connector import Error
import json

app = FastAPI()

# 데이터베이스 설정
DATABASE_CONFIG = {
    'host': 'localhost',
    'database': 'first_api_tables',
    'user': 'root',
    'password': 'wkrwjs12!@'
}

# 데이터베이스 연결 함수
def get_db_connection():
    try:
        return mysql.connector.connect(**DATABASE_CONFIG)
    except Error as e:
        print(f"Error connecting to the database: {e}")
        return None

# JSON 경로 추출 함수
def get_paths_from_json(json_obj: dict, parent_key: str = '') -> list:
    paths = []
    for k, v in json_obj.items():
        full_key = f"{parent_key}.{k}" if parent_key else k
        if isinstance(v, dict):
            paths.extend(get_paths_from_json(v, full_key))
        elif isinstance(v, list):
            for i, item in enumerate(v):
                if isinstance(item, dict):
                    paths.extend(get_paths_from_json(item, f"{full_key}[{i}]"))
                else:
                    paths.append(f"{full_key}[{i}]")
        else:
            paths.append(full_key)
    return paths

# 특정 JSON 경로의 데이터를 조회하는 함수
def fetch_data_for_path(json_path: str):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        query = f"SELECT JSON_UNQUOTE(JSON_EXTRACT(response_data, '$.{json_path}')) FROM api_responses WHERE JSON_EXTRACT(response_data, '$.{json_path}') IS NOT NULL LIMIT 1"
        cursor.execute(query)
        result = cursor.fetchone()
        return result[0] if result else None
    except Error as e:
        print(f"Database error for path '{json_path}': {e}")
        return None
    finally:
        if conn and conn.is_connected():
            cursor.close()
            conn.close()

# 엔드포인트 생성 함수
def create_endpoints_from_json_data(json_data: dict):
    paths = get_paths_from_json(json_data)
    for path in paths:
        endpoint_name = path.replace('.', '_').replace('[', '_').replace(']', '') # 경로를 엔드포인트 이름으로 변환

        @app.get(f"/{endpoint_name}", summary=f"Get data for {path}", description=f"Retrieves data from the path {path} in the database.")
        def generic_endpoint(_path=path): # 클로저를 사용하여 각 엔드포인트에 대한 올바른 경로를 유지
            data = fetch_data_for_path(_path)
            if data is None:
                raise HTTPException(status_code=404, detail="Data not found")
            return {_path: data}  # 여기에서 _path를 key로 사용

# 메인 함수
def main():
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT response_data FROM api_responses LIMIT 1")
        row = cursor.fetchone()
        if row:
            json_data = json.loads(row[0])
            print(f"Creating endpoints for paths: {get_paths_from_json(json_data)}")
            create_endpoints_from_json_data(json_data)
        else:
            print("No data found.")
    except Error as e:
        print(f"Database error: {e}")
    finally:
        if conn and conn.is_connected():
            cursor.close()
            conn.close()
            print("Closing database connection.")

if __name__ == "__main__":
    main()
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)

# %% Unit test + SQL + Fast API + contents involved + Example added
import json
import requests
from fastapi import FastAPI, HTTPException
import mysql.connector
from mysql.connector import Error
import uvicorn
import asyncio
import nest_asyncio

app = FastAPI()

# 데이터베이스 설정
DATABASE_CONFIG = {
    'host': 'localhost',
    'database': 'first_api_tables',
    'user': 'root',
    'password': 'wkrwjs12!@'
}

# 엔드포인트 목록을 저장할 변수
created_endpoints = []

# 데이터베이스 연결 함수
def get_db_connection():
    try:
        return mysql.connector.connect(**DATABASE_CONFIG)
    except Error as e:
        print(f"Error connecting to the database: {e}")
        return None

# JSON 경로 추출 함수
def get_paths_from_json(json_obj: dict, parent_key: str = '') -> list:
    paths = []
    for k, v in json_obj.items():
        full_key = f"{parent_key}.{k}" if parent_key else k
        if isinstance(v, dict):
            paths.extend(get_paths_from_json(v, full_key))
        elif isinstance(v, list):
            for i, item in enumerate(v):
                if isinstance(item, dict):
                    paths.extend(get_paths_from_json(item, f"{full_key}[{i}]"))
                else:
                    paths.append(f"{full_key}[{i}]")
        else:
            paths.append(full_key)
    return paths

# 특정 JSON 경로의 데이터를 조회하는 함수
def fetch_data_for_path(json_path: str):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        query = f"SELECT JSON_UNQUOTE(JSON_EXTRACT(response_data, '$.{json_path}')) FROM api_responses WHERE JSON_EXTRACT(response_data, '$.{json_path}') IS NOT NULL LIMIT 1"
        cursor.execute(query)
        result = cursor.fetchone()
        return result[0] if result else None
    except Error as e:
        print(f"Database error for path '{json_path}': {e}")
        return None
    finally:
        if conn and conn.is_connected():
            cursor.close()
            conn.close()

# 엔드포인트 생성 함수
def create_endpoints_from_json_data(json_data: dict):
    paths = get_paths_from_json(json_data)
    for path in paths:
        endpoint_name = path.replace('.', '_').replace('[', '_').replace(']', '')
        created_endpoints.append(endpoint_name)  # 엔드포인트 목록에 추가

        @app.get(f"/{endpoint_name}", summary=f"Get data for {path}", description=f"Retrieves data from the path {path} in the database.")
        def generic_endpoint(_path=path): # 클로저를 사용하여 각 엔드포인트에 대한 올바른 경로를 유지
            data = fetch_data_for_path(_path)
            if data is None:
                raise HTTPException(status_code=404, detail="Data not found")
            return {_path: data}  # 여기에서 _path를 key로 사용

# 데이터를 수집하고 저장하는 함수
def collect_and_save_endpoint_data(base_url):
    data_examples = {}
    for endpoint in created_endpoints:
        response = requests.get(f"{base_url}/{endpoint}")
        if response.status_code == 200:
            data_examples[endpoint] = response.json()
    with open('api_data_examples.json', 'w') as file:
        json.dump(data_examples, file, indent=4)

# 서버를 비동기적으로 실행하는 함수
async def run_server():
    config = uvicorn.Config(app=app, host="0.0.0.0", port=8000)
    server = uvicorn.Server(config)
    await server.serve()

# 메인 함수
def main():
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT response_data FROM api_responses LIMIT 1")
        row = cursor.fetchone()
        if row:
            json_data = json.loads(row[0])
            create_endpoints_from_json_data(json_data)
            print("Endpoints created.")
        else:
            print("No data found.")
    except Error as e:
        print(f"Database error: {e}")
    finally:
        if conn and conn.is_connected():
            cursor.close()
            conn.close()
            print("Closing database connection.")

if __name__ == "__main__":
    main()

    nest_asyncio.apply()
    asyncio.run(run_server())
    
# %% Unit test + SQL + Fast API + contents involved + Example added
# collect_and_save_endpoint_data 결과를 보기 위해 코드 수정 (`24.02.06.)
import json
import requests
from fastapi import FastAPI, HTTPException
import mysql.connector
from mysql.connector import Error
import uvicorn
import asyncio
import nest_asyncio

app = FastAPI()

# 데이터베이스 설정
DATABASE_CONFIG = {
    'host': 'localhost',
    'database': 'first_api_tables',
    'user': 'root',
    'password': 'wkrwjs12!@'
}

# 엔드포인트 목록을 저장할 변수
created_endpoints = []

# 데이터베이스 연결 함수
def get_db_connection():
    try:
        return mysql.connector.connect(**DATABASE_CONFIG)
    except Error as e:
        print(f"Error connecting to the database: {e}")
        return None

# JSON 경로 추출 함수
def get_paths_from_json(json_obj: dict, parent_key: str = '') -> list:
    paths = []
    for k, v in json_obj.items():
        full_key = f"{parent_key}.{k}" if parent_key else k
        if isinstance(v, dict):
            paths.extend(get_paths_from_json(v, full_key))
        elif isinstance(v, list):
            for i, item in enumerate(v):
                if isinstance(item, dict):
                    paths.extend(get_paths_from_json(item, f"{full_key}[{i}]"))
                else:
                    paths.append(f"{full_key}[{i}]")
        else:
            paths.append(full_key)
    return paths

# 특정 JSON 경로의 데이터를 조회하는 함수
def fetch_data_for_path(json_path: str):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        query = f"SELECT JSON_UNQUOTE(JSON_EXTRACT(response_data, '$.{json_path}')) FROM api_responses WHERE JSON_EXTRACT(response_data, '$.{json_path}') IS NOT NULL LIMIT 1"
        cursor.execute(query)
        result = cursor.fetchone()
        return result[0] if result else None
    except Error as e:
        print(f"Database error for path '{json_path}': {e}")
        return None
    finally:
        if conn and conn.is_connected():
            cursor.close()
            conn.close()

# 엔드포인트 생성 함수
def create_endpoints_from_json_data(json_data: dict):
    paths = get_paths_from_json(json_data)
    for path in paths:
        endpoint_name = path.replace('.', '_').replace('[', '_').replace(']', '')
        if endpoint_name not in created_endpoints:
            created_endpoints.append(endpoint_name)  # 엔드포인트 목록에 추가

            @app.get(f"/{endpoint_name}", summary=f"Get data for {path}", description=f"Retrieves data from the path {path} in the database.")
            def generic_endpoint(_path=path): # 클로저를 사용하여 각 엔드포인트에 대한 올바른 경로를 유지
                data = fetch_data_for_path(_path)
                if data is None:
                    raise HTTPException(status_code=404, detail="Data not found")
                return {_path: data}  # 여기에서 _path를 key로 사용

# 데이터를 수집하고 저장하는 비동기 함수
async def collect_and_save_endpoint_data(base_url):
    data_examples = {}
    for endpoint in created_endpoints:
        response = await asyncio.get_event_loop().run_in_executor(None, requests.get, f"{base_url}/{endpoint}")
        if response.status_code == 200:
            data_examples[endpoint] = response.json()
    with open('api_data_examples.json', 'w') as file:
        json.dump(data_examples, file, indent=4)

# 서버 실행과 데이터 수집을 함께 처리하는 비동기 함수
async def run_server_and_collect_data():
    config = uvicorn.Config(app=app, host="0.0.0.0", port=8000, loop="asyncio")
    server = uvicorn.Server(config)
    server_task = asyncio.create_task(server.serve())
    
    await asyncio.sleep(1)  # 서버가 시작될 때까지 기다림

    await collect_and_save_endpoint_data("http://localhost:8000")
    
    await server_task

# 메인 함수
def main():
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT response_data FROM api_responses LIMIT 1")
        row = cursor.fetchone()
        if row:
            json_data = json.loads(row[0])
            create_endpoints_from_json_data(json_data)
            print("Endpoints created.")
        else:
            print("No data found.")
    except Error as e:
        print(f"Database error: {e}")
    finally:
        if conn and conn.is_connected():
            cursor.close()
            conn.close()
            print("Database connection closed.")

if __name__ == "__main__":
    main()
    nest_asyncio.apply()
    asyncio.run(run_server_and_collect_data())

# %% `24.02.06. 디버깅
import json
import requests
from fastapi import FastAPI, HTTPException
import mysql.connector
from mysql.connector import Error
import uvicorn
import asyncio
import nest_asyncio

app = FastAPI()

# 데이터베이스 설정
DATABASE_CONFIG = {
    'host': 'localhost',
    'database': 'first_api_tables',
    'user': 'root',
    'password': 'wkrwjs12!@'
}

# 엔드포인트 목록을 저장할 변수
created_endpoints = []

# 데이터베이스 연결 함수
def get_db_connection():
    try:
        return mysql.connector.connect(**DATABASE_CONFIG)
    except Error as e:
        print(f"Error connecting to the database: {e}")
        return None

# JSON 경로 추출 함수
def get_paths_from_json(json_obj: dict, parent_key: str = '') -> list:
    paths = []
    for k, v in json_obj.items():
        full_key = f"{parent_key}.{k}" if parent_key else k
        if isinstance(v, dict):
            paths.extend(get_paths_from_json(v, full_key))
        elif isinstance(v, list):
            for i, item in enumerate(v):
                if isinstance(item, dict):
                    paths.extend(get_paths_from_json(item, f"{full_key}[{i}]"))
                else:
                    paths.append(f"{full_key}[{i}]")
        else:
            paths.append(full_key)
    return paths

# 특정 JSON 경로의 데이터를 조회하는 함수
def fetch_data_for_path(json_path: str):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        query = f"SELECT JSON_UNQUOTE(JSON_EXTRACT(response_data, '$.{json_path}')) FROM api_responses WHERE JSON_EXTRACT(response_data, '$.{json_path}') IS NOT NULL LIMIT 1"
        cursor.execute(query)
        result = cursor.fetchone()
        return result[0] if result else None
    except Error as e:
        print(f"Database error for path '{json_path}': {e}")
        return None
    finally:
        if conn and conn.is_connected():
            cursor.close()
            conn.close()

# 엔드포인트 생성 함수
def create_endpoints_from_json_data(json_data: dict, examples: dict):
    paths = get_paths_from_json(json_data)
    for path in paths:
        endpoint_name = path.replace('.', '_').replace('[', '_').replace(']', '')
        if endpoint_name not in created_endpoints:
            created_endpoints.append(endpoint_name)  # 엔드포인트 목록에 추가

            @app.get(f"/{endpoint_name}", summary=f"Get data for {path}", description=f"Retrieves data from the path {path} in the database.", responses={200: {"content": {"application/json": {"example": examples.get(endpoint_name, {})}}}})
            def generic_endpoint(_path=path): # 클로저를 사용하여 각 엔드포인트에 대한 올바른 경로를 유지
                data = fetch_data_for_path(_path)
                if data is None:
                    raise HTTPException(status_code=404, detail="Data not found")
                return {_path: data}  # 여기에서 _path를 key로 사용

# 데이터를 수집하고 저장하는 비동기 함수
async def collect_and_save_endpoint_data(base_url):
    data_examples = {}
    for endpoint in created_endpoints:
        response = await asyncio.get_event_loop().run_in_executor(None, requests.get, f"{base_url}/{endpoint}")
        if response.status_code == 200:
            data_examples[endpoint] = response.json()
    with open('api_data_examples.json', 'w') as file:
        json.dump(data_examples, file, indent=4)

# 예제 데이터 파일 로딩
def load_example_data():
    try:
        with open('api_data_examples.json', 'r') as file:
            return json.load(file)
    except FileNotFoundError:
        print("Example data file not found. Generating without examples.")
        return {}

# 서버 실행과 데이터 수집을 함께 처리하는 비동기 함수
async def run_server_and_collect_data():
    config = uvicorn.Config(app=app, host="0.0.0.0", port=8000, loop="asyncio")
    server = uvicorn.Server(config)
    server_task = asyncio.create_task(server.serve())
    
    await asyncio.sleep(1)  # 서버가 시작될 때까지 기다림

    await collect_and_save_endpoint_data("http://localhost:8000")
    
    await server_task

# 메인 함수
def main():
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT response_data FROM api_responses LIMIT 1")
        row = cursor.fetchone()
        if row:
            json_data = json.loads(row[0])
            examples = load_example_data()  # 예제 데이터 로딩
            create_endpoints_from_json_data(json_data, examples)
            print("Endpoints created.")
        else:
            print("No data found.")
    except Error as e:
        print(f"Database error: {e}")
    finally:
        if conn and conn.is_connected():
            cursor.close()
            conn.close()
            print("Database connection closed.")

if __name__ == "__main__":
    main()
    nest_asyncio.apply()
    asyncio.run(run_server_and_collect_data())
# %% + Shp File 
from fastapi import FastAPI
from fastapi.responses import HTMLResponse
import geopandas as gpd
from bokeh.embed import file_html
from bokeh.resources import CDN
from bokeh.models import GeoJSONDataSource, LinearColorMapper, ColorBar
from bokeh.plotting import figure
import random

app = FastAPI()

@app.get("/visualize_map", response_class=HTMLResponse)
async def visualize_map():
    # 지정된 .shp 파일 경로
    shapefile_path = r'D:\KRX\Interactive-Choropleth-Map-Using-Python-master\Interactive-Choropleth-Map-Using-Python-master\bokeh-app\data\countries_110m\ne_110m_admin_0_countries.shp'
    gdf = gpd.read_file(shapefile_path)
    
    # 임의의 데이터 생성
    gdf['random_value'] = [random.randint(1, 100) for _ in range(len(gdf))]
    
    geosource = GeoJSONDataSource(geojson=gdf.to_json())
    color_mapper = LinearColorMapper(palette="Viridis256", low=min(gdf['random_value']), high=max(gdf['random_value']))
    
    # 가로로 더 크게 그려지도록 width 값을 조정
    p = figure(title="World Map with Random Values", width=1200, height=600)
    p.patches('xs', 'ys', source=geosource,
              fill_color={'field': 'random_value', 'transform': color_mapper},
              line_color='black', line_width=0.25)
    color_bar = ColorBar(color_mapper=color_mapper, label_standoff=12, location=(0,0))
    p.add_layout(color_bar, 'right')

    # HTML 페이지로 변환
    html = file_html(p, CDN, "World Map with Random Values")

    return html

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)


# %% MVP code
# 추후 해야할 코드 업무 : 발급된 Geo API Key 로 상기 endpoint 를 통해 호출한 주소 정보 Mapping
import geopandas as gpd
from bokeh.plotting import figure, output_file, show
from bokeh.models import GeoJSONDataSource, LinearColorMapper, ColorBar
import random

# 지정된 .shp 파일 경로
shapefile_path = r'D:\KRX\Interactive-Choropleth-Map-Using-Python-master\Interactive-Choropleth-Map-Using-Python-master\bokeh-app\data\countries_110m\ne_110m_admin_0_countries.shp'
gdf = gpd.read_file(shapefile_path)

# 임의의 데이터 생성 및 추가
gdf['random_value'] = [random.randint(1, 100) for _ in range(len(gdf))]

# GeoJSONDataSource 생성
geosource = GeoJSONDataSource(geojson=gdf.to_json())

# Color mapper 설정
color_mapper = LinearColorMapper(palette="Viridis256", low=min(gdf['random_value']), high=max(gdf['random_value']))

# Bokeh Figure 설정
p = figure(title="World Map with Random Values")
p.patches('xs', 'ys', source=geosource,
          fill_color={'field': 'random_value', 'transform': color_mapper},
          line_color='black', line_width=0.25)

# Color Bar 추가
color_bar = ColorBar(color_mapper=color_mapper, label_standoff=12, location=(0,0))
p.add_layout(color_bar, 'right')

# 결과를 HTML 파일로 저장 및 보여주기
output_file("world_map_random_values.html")
show(p)
