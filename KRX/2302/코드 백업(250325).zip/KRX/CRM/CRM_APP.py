# -*- coding: utf-8 -*-
"""
Created on Wed Jan 10 23:11:46 2024

@author: 221016
"""

from flask import Flask, render_template
from bokeh.plotting import figure
from bokeh.embed import components
from bokeh.models import ColumnDataSource, HoverTool
import pandas as pd

app = Flask(__name__)

# Sample data
data = {
    "type": ["direct", "indirect", "indirect", "direct"],
    "latitude": [37.5665, 37.456, 37.5759, 37.5701],
    "longitude": [126.9780, 126.7052, 126.9770, 126.9827],
    "sales": [1000, 1500, 2000, 1200],
    "product": ["Product A", "Product B", "Product A", "Product C"],
    "vendor": ["", "Vendor 1", "Vendor 2", ""]
}

@app.route('/')
def index():
    df = pd.DataFrame(data)
    source = ColumnDataSource(df)

    # Create a figure
    p = figure(title="Data Sales Customers on Korea Exchange", x_axis_label='Latitude', y_axis_label='Longitude')
    
    # Differentiate between direct and indirect with colors
    color_map = {'direct': 'blue', 'indirect': 'green'}
    df['color'] = df['type'].map(color_map)

    # Add circles to the plot
    p.circle('latitude', 'longitude', source=source, color='color', size=10)

    # Add hover tool
    hover = HoverTool()
    hover.tooltips = [("Type", "@type"), ("Sales", "@sales"), ("Product", "@product"), ("Vendor", "@vendor")]
    p.add_tools(hover)

    # Embed plot into HTML via Flask Render
    script, div = components(p)
    return render_template("index.html", script=script, div=div)

if __name__ == '__main__':
    app.run(debug=True)
