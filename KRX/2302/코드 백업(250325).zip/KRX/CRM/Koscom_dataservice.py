# -*- coding: utf-8 -*-
"""
Created on Tue Jan 16 20:17:26 2024

@author: 221016
"""

"""
1. send_first_api_request 함수는 https://dataservice.koscom.co.kr/apis/v1/user/approvals/{self.REFERENCE_ID} 주소로 GET 요청을 보내는 것으로 보입니다. 이는 특정 사용자의 승인 목록을 조회하는 API
# (Wd 에 파일로 저장됨)
# (input 은 Reference ID -> Third API 에서 선 수집 필요)

2. send_second_api_request 함수는 https://dataservice.koscom.co.kr/apis/v1/common/snapshots/history 주소로 POST 요청을 보내고, 특정 조건에 맞는 스냅샷의 히스토리 데이터를 조회하는 API
# (Wd 에 파일로 저장됨)
# (input 은 Reference ID -> Third API 에서 선 수집 필요)

3. send_third_api_request 함수는 https://dataservice.koscom.co.kr/apis/v1/user/approvals/search 주소로 POST 요청을 보내고, 특정 조건을 만족하는 승인 요청들을 검색하는 API
# (sql db 에 저장됨)
# (input 은 Page Number)
"""
# %% - + First, Second 
import json
import requests
from hashlib import md5
from seleniumwire import webdriver
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException, WebDriverException
from bs4 import BeautifulSoup
from tqdm import tqdm
import time
from mysql.connector import connect, Error
import urllib3

class APIManager:
    def __init__(self):
        self.CHROMEDRIVER_PATH = 'C:\\Users\\KRX\\Desktop\\201021\\chromedriver-win32\\chromedriver.exe'
        self.CHROME_BINARY_PATH = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe'
        self.LOGIN_URL = 'https://dataservice.koscom.co.kr/login?returnUrl=/krx/approval-list'
        self.TARGET_URL = 'https://dataservice.koscom.co.kr/krx/approval-list'
        self.PROFILE_PATH = 'C:\\Users\\KRX\\Desktop\\201021'
        self.PROFILE_NAME = 'Profile 4'
        self.REFERENCE_ID = 100562
        self.driver = self.create_webdriver()
        self.all_responses = {}
        urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

        self.connection = connect(
            host='localhost',
            database='first_api_tables',
            user='root',
            password='wkrwjs12!@'
        )
        self.cursor = self.connection.cursor()
        self.create_tables_if_not_exists()
        self.existing_hashes_map = {}
        self.load_existing_hashes()

    def create_tables_if_not_exists(self):
        create_table_queries = {
            'Table_1st_API': """
                CREATE TABLE IF NOT EXISTS table_1st_api (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    response_data JSON
                );
            """,
            'Table_2st_API': """
                CREATE TABLE IF NOT EXISTS table_2st_api (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    response_data JSON
                );
            """,
            'Table_3st_API': """
                CREATE TABLE IF NOT EXISTS table_3st_api (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    page_number INT,
                    sanction_id INT,
                    sanction_subject VARCHAR(255),
                    response_data JSON,
                    unique_key_hash VARCHAR(64),
                    UNIQUE(unique_key_hash)
                );
            """
        }

        for table_name, query in create_table_queries.items():
            try:
                self.cursor.execute(query)
                self.connection.commit()
                print(f"[INFO] Table '{table_name}' checked/created.")
            except Error as e:
                print(f"[ERROR] Error while creating/checking table '{table_name}': {e}")
                self.connection.rollback()

    def create_webdriver(self):
        chrome_options = Options()
        chrome_options.binary_location = self.CHROME_BINARY_PATH
        chrome_options.add_argument("--disable-gpu")
        chrome_options.add_argument("--no-sandbox")
        chrome_options.add_argument("--start-maximized")
        chrome_options.add_argument(f'user-data-dir={self.PROFILE_PATH}')
        chrome_options.add_argument(f'profile-directory={self.PROFILE_NAME}')
        service = ChromeService(executable_path=self.CHROMEDRIVER_PATH)
        return webdriver.Chrome(service=service, options=chrome_options)

    def login(self, app_id, app_pw):
        try:
            self.driver.get(self.LOGIN_URL)
            WebDriverWait(self.driver, 10).until(EC.presence_of_element_located((By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[1]/div/div/input')))
            id_box = self.driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[1]/div/div/input')
            password_box = self.driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[2]/div/div/input')
            login_button = self.driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[3]/button')
            id_box.send_keys(app_id)
            password_box.send_keys(app_pw)
            login_button.click()
            WebDriverWait(self.driver, 15).until(EC.url_to_be(self.TARGET_URL))
            print("[INFO] 로그인에 성공했습니다.")
        except TimeoutException as e:
            print("[ERROR] 이미 로그인 되었는지, 로그인 창으로 이동할 수 없습니다.")
        except Exception as e:
            print("[ERROR] 로그인 중 다른 오류 발생:", e)

    def extract_data_from_html(self, html_content):
        soup = BeautifulSoup(html_content, 'html.parser')
        tables = soup.find_all('table')
        structured_data = []
        unstructured_data = []

        for table in tables:
            rows = table.find_all('tr')
            table_data = []

            for row in rows:
                cols = row.find_all(['td', 'th'])
                cols = [ele.text.strip() for ele in cols]
                table_data.append(cols)

            structured_data.append(table_data)

        [s.extract() for s in soup(['style', 'script', '[document]', 'head', 'title'])]
        unstructured_data = soup.get_text(separator=' ', strip=True)

        return structured_data, unstructured_data

    def extract_auth_header(self):
        for request in self.driver.requests:
            if request.url == "https://dataservice.koscom.co.kr/apis/v1/common/auth/my-information":
                return {'Authorization': request.headers.get('Authorization')}
        return {}

    def send_api_request(self, url, headers):
        response = requests.get(url, headers=headers, verify=False)
        if response.status_code == 200:
            html_content = response.content.decode('utf-8')
            structured_data, unstructured_data = self.extract_data_from_html(html_content)
            return response.json(), structured_data, unstructured_data
        else:
            print(f"[ERROR] API 요청 실패. Status Code: {response.status_code}")
            print(f"Response: {response.text}")
            return None, None, None

    def send_post_request(self, url, headers, body):
        response = requests.post(url, headers=headers, json=body, verify=False)
        if response.status_code == 200:
            html_content = response.content.decode('utf-8')
            structured_data, unstructured_data = self.extract_data_from_html(html_content)
            return response.json(), structured_data, unstructured_data
        else:
            print(f"[ERROR] POST 요청 실패. Status Code: {response.status_code}")
            print(f"Response: {response.text}")
            return None, None, None

    def save_response_as_json(self, response_data, file_path):
        with open(file_path, 'w', encoding='utf-8') as file:
            json.dump(response_data, file, ensure_ascii=False, indent=4)

    def send_first_api_request(self):
        first_api_url = f'https://dataservice.koscom.co.kr/apis/v1/user/approvals/{self.REFERENCE_ID}'
        response_json, structured_data, unstructured_data = self.send_api_request(first_api_url, self.extract_auth_header())
        if response_json:
            self.total = response_json.get("page", {}).get("total", 0)
            self.totalPage = response_json.get("page", {}).get("totalPage", 0)
            self.save_response_as_json({"response": response_json, "structured": structured_data, "unstructured": unstructured_data}, "first_api_response.json")    

    
    def send_second_api_request(self):
        second_api_url = "https://dataservice.koscom.co.kr/apis/v1/common/snapshots/history"
        body = {
            'snapshotsLargeClassificationCode': '04',
            'snapshotsSmallClassificationCode': '04_01',
            'referenceId': self.REFERENCE_ID
        }
        response_json, structured_data, unstructured_data = self.send_post_request(second_api_url, self.extract_auth_header(), body)
        self.save_response_as_json({"response": response_json, "structured": structured_data, "unstructured": unstructured_data}, "second_api_response.json")

    def send_third_api_request(self, page_number):
        third_api_url = "https://dataservice.koscom.co.kr/apis/v1/user/approvals/search"
        body = {
            "startDate": "",
            "endDate": "",
            "sanctionTypeCode": "",
            "approvalStatusCode": "",
            "ordersSectionCode": "",
            "searchType": "SUBJECT",
            "searchText": "",
            "page": {
                "pageNumber": page_number,
                "pageSize": 10,
                "total": self.total,
                "totalPage": self.totalPage
            }
        }
        response_json, structured_data, unstructured_data = self.send_post_request(third_api_url, self.extract_auth_header(), body)
        if response_json:
            for content in response_json.get("contents", []):
                krx_sanction_subject = content.get("krxSanctionSubject", "")
                sanction_id = content.get("sanctionId", 0)
                unique_key = f"{krx_sanction_subject}-{sanction_id}"
                unique_key_hash = md5(unique_key.encode('utf-8')).hexdigest()
                print(f"[DEBUG] Processing item: {unique_key}, Hash: {unique_key_hash}")
    
                # 중복된 해시 값이 있는 경우, 데이터를 추가하지 않습니다.
                if unique_key_hash in self.existing_hashes_map:
                    print(f"[INFO] 중복 데이터 발견, 저장하지 않음: {unique_key_hash}")
                    continue
    
                # 중복되지 않은 경우, 데이터를 추가합니다.
                nested_response = {
                    "page_info": response_json.get("page", {}),
                    "contents": content,
                    "unique_key_hash": unique_key_hash,
                    "sanction_subject": krx_sanction_subject,
                    "sanction_id": sanction_id
                }
                self.all_responses[unique_key_hash] = nested_response
                print(f"Saction ID {sanction_id} ({krx_sanction_subject}) saved. Hash: {unique_key_hash}")

    def save_responses_to_database(self):
        print("[DEBUG] save_responses_to_database 함수 시작")
        self.connection.ping(reconnect=True)  # 데이터베이스 연결 확인 및 필요시 재연결
        for unique_key_hash, data in self.all_responses.items():
            with self.connection.cursor() as cursor:
                # 데이터베이스에서 unique_key_hash가 존재하는지 확인
                check_query = "SELECT COUNT(*) FROM Table_3st_API WHERE unique_key_hash = %s"
                cursor.execute(check_query, (unique_key_hash,))
                (count,) = cursor.fetchone()
        
                if count > 0:
                    print(f"[INFO] 중복 데이터 발견, 저장하지 않음: {unique_key_hash}")
                    continue  # 중복 데이터는 건너뜁니다.
                else:
                    print(f"[INFO] 새 데이터 발견, 저장 진행: {unique_key_hash}")
        
                # 중복이 아니면 새로운 데이터 저장
                page_info = data["page_info"]
                page_number = page_info.get("pageNumber", 0)
                response_data = json.dumps(data)
                sanction_id = data["sanction_id"]
                sanction_subject = data.get("sanction_subject", "") 
        
                insert_query = """
                INSERT INTO Table_3st_API (page_number, sanction_id, sanction_subject, response_data, unique_key_hash)
                VALUES (%s, %s, %s, %s, %s)
                """
                try:
                    cursor.execute(insert_query, (page_number, sanction_id, sanction_subject, response_data, unique_key_hash))
                    self.connection.commit() 
                    print(f"[DEBUG] 데이터 저장 성공: {unique_key_hash}")
                except Error as e:
                    print(f"[ERROR] 데이터 저장 중 오류 발생: {e}")
                    self.connection.rollback()
    
        print("[DEBUG] save_responses_to_database 함수 종료")

    def save_first_second_api_responses_to_database(self, file_name, table_name):
        try:
            with open(file_name, 'r', encoding='utf-8') as file:
                data = json.load(file)
                response_data = json.dumps(data)

                with self.connection.cursor() as cursor:
                    query = f"""
                    INSERT INTO {table_name} (response_data)
                    VALUES (%s)
                    ON DUPLICATE KEY UPDATE
                    response_data = VALUES(response_data)
                    """
                    cursor.execute(query, (response_data,))
                    self.connection.commit()
                    print(f"[DEBUG] {file_name} 데이터 저장 성공")
        except Error as e:
            print(f"[ERROR] {file_name} 데이터 저장 중 오류 발생: {e}")
            self.connection.rollback()
        except FileNotFoundError:
            print(f"[ERROR] 파일 {file_name}을 찾을 수 없습니다.")

    def ensure_database_connection(self):
        if not self.connection.is_connected():
            print("[INFO] 데이터베이스 재연결 시도 중...")
            self.connection.reconnect(attempts=3, delay=5)

    def load_existing_hashes(self):
        self.ensure_database_connection() 
        self.cursor = self.connection.cursor() 
        print("[DEBUG] load_existing_hashes 함수 시작")
        self.existing_hashes_map.clear()
        try:
            query = "SELECT unique_key_hash, sanction_subject, sanction_id FROM Table_3st_API"
            self.cursor.execute(query)
            results = self.cursor.fetchall()
            for hash_value, subject, id in results:
                if subject is not None and id is not None:
                    self.existing_hashes_map[hash_value] = f"{subject}-{id}"
    
            # 기술 통계량 추가 (여기서 출력을 줄임)
            total_hashes = len(self.existing_hashes_map)
            print(f"[INFO] 총 해시 값 건수: {total_hashes}")
        except Error as e:
            print(f"[ERROR] 데이터 불러오기 중 오류 발생: {e}")
        finally:
            self.cursor.close() 
        print("[DEBUG] load_existing_hashes 함수 종료")
    
    def close(self):
        self.driver.quit()
        self.cursor.close()
        self.connection.close()
        print("[DEBUG] 데이터베이스 연결 닫힘")

def check_data_in_database(connection):
    tables = ['Table_1st_API', 'Table_2st_API', 'Table_3st_API']
    data_objects = {}

    for table in tables:
        data_objects[table] = []
        try:
            with connection.cursor() as cursor:
                query = f"SELECT * FROM {table} LIMIT 5"  # 각 테이블에서 상위 5개 데이터 조회
                cursor.execute(query)
                results = cursor.fetchall()
                data_objects[table].extend(results)
        except mysql.connector.Error as e:
            print(f"[ERROR] 데이터 확인 중 오류 발생 ({table}): {e}")

    return data_objects

# 메인 실행 코드
if __name__ == "__main__":
    api_manager = APIManager()
    api_manager.login('goguma@krx.co.kr', 'wkrwjs12!@')
    api_manager.send_first_api_request()
    api_manager.send_second_api_request()
    for page_number in tqdm(range(1, 2), desc="Processing"):
        time.sleep(10)
        api_manager.send_third_api_request(page_number)
    api_manager.save_responses_to_database()

    # 저장된 데이터 확인 및 객체에 저장
    database_data = check_data_in_database(api_manager.connection)

    # 객체에 저장된 데이터 출력
    # for table, data in database_data.items():
    #     print(f"\n[INFO] 데이터 확인 - {table}:")
    #     for row in data:
    #         print(row)

    api_manager.close()
    print("All tasks completed.")
    
# %% ○ [FileDownloader] File downloads With uuid 
# %% - Hard Coding Ex Ver. 
# 파일 UUID는 하드코딩되어 있으며, 사용자가 이를 지정해야 합니다.
# download_file 함수는 파일을 다운로드할 때 고정된 파일 이름 (downloaded_file.pdf)을 사용합니다.
# 이 코드는 특정 파일 UUID에 대해 파일을 다운로드하는 간단한 로직을 포함합니다.

import time
from seleniumwire import webdriver
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import urllib3

class FileDownloader:
    def __init__(self, chromedriver_path, chrome_binary_path, login_url):
        self.chromedriver_path = chromedriver_path
        self.chrome_binary_path = chrome_binary_path
        self.login_url = login_url
        urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

    def create_webdriver(self):
        chrome_options = Options()
        chrome_options.binary_location = self.chrome_binary_path
        chrome_options.add_argument("--start-maximized")
        service = ChromeService(executable_path=self.chromedriver_path)
        return webdriver.Chrome(service=service, options=chrome_options)

    def login(self, driver, username, password):
        driver.get(self.login_url)
        WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[1]/div/div/input'))).send_keys(username)
        WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[2]/div/div/input'))).send_keys(password)
        WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[3]/button'))).click()
        time.sleep(5)

    def download_file(self, file_uuid, auth_token, save_path):
        base_url = "https://dataservice.koscom.co.kr"
        download_url = f"{base_url}/apis/v1/common/files?fileUUID={file_uuid}"
        headers = {'Authorization': auth_token}
        
        response = requests.get(download_url, headers=headers, verify=False)
        if response.status_code == 200:
            with open(save_path, 'wb') as file:
                file.write(response.content)
            print(f"File downloaded successfully and saved as {save_path}")
        else:
            print(f"Failed to download file: Status code {response.status_code}, Response: {response.text}")

if __name__ == "__main__":
    file_downloader = FileDownloader(
        'C:\\Users\\KRX\\Desktop\\201021\\chromedriver-win32\\chromedriver.exe',
        'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
        'https://dataservice.koscom.co.kr/login?returnUrl=/krx/approval-list'
    )

    driver = file_downloader.create_webdriver()
    try:
        file_downloader.login(driver, 'goguma@krx.co.kr', 'wkrwjs12!@')
        time.sleep(10)  # 인증 토큰 생성 대기

        auth_header = None
        for request in driver.requests:
            if 'Authorization' in request.headers:
                auth_header = request.headers['Authorization']
                break

        if auth_header:
            file_uuid = "1df807dc-9e8d-4698-9581-383f484f7a42.pdf"  # 예시 UUID
            save_path = "downloaded_file.pdf"  # 저장할 파일 경로
            file_downloader.download_file(file_uuid, auth_header, save_path)
        else:
            print("Failed to obtain Authorization header")

    except Exception as e:
        print(f"[ERROR] 메인 실행 중 오류 발생: {e}")
    finally:
        driver.quit()

# %% ○ [KMDS] API - SQL 
# %% `24.02.28. 위 코드는 1-2 api 결과는 SQL 에 저장하지 않아, 후에 Fast API 와 연계되지 않는 부분이 있음 
# 로컬 저장 뿐만 아니라, SQL 에도 저장하여 동적 연계가 가능하도록 수정 
import json
import requests
from hashlib import md5
from seleniumwire import webdriver
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException, WebDriverException
from bs4 import BeautifulSoup
from tqdm import tqdm
import time
from mysql.connector import connect, Error
import urllib3
import sys


class APIManager:
    def __init__(self):
        self.CHROMEDRIVER_PATH = 'C:\\Users\\KRX\\Desktop\\201021\\chromedriver-win32\\chromedriver.exe'
        self.CHROME_BINARY_PATH = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe'
        self.LOGIN_URL = 'https://dataservice.koscom.co.kr/login?returnUrl=/krx/approval-list'
        self.TARGET_URL = 'https://dataservice.koscom.co.kr/krx/approval-list'
        self.PROFILE_PATH = 'C:\\Users\\KRX\\Desktop\\201021'
        self.PROFILE_NAME = 'Profile 4'
        self.REFERENCE_ID = None # third API 결과에서 얻어와야함 
        self.driver = self.create_webdriver()
        self.all_responses = {}
        urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

        self.connection = connect(
            host='localhost',
            database='first_api_tables',
            user='root',
            password='wkrwjs12!@'
        )
        self.cursor = self.connection.cursor()
        self.create_tables_if_not_exists()
        self.existing_hashes_map = {}
        self.load_existing_hashes()

    def create_tables_if_not_exists(self):
        create_table_queries = {
            'Table_1st_API': """
                CREATE TABLE IF NOT EXISTS table_1st_api (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    response_data JSON
                );
            """,
            'Table_2st_API': """
                CREATE TABLE IF NOT EXISTS table_2st_api (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    response_data JSON
                );
            """,
            'Table_3st_API': """
                CREATE TABLE IF NOT EXISTS table_3st_api (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    page_number INT,
                    sanction_id INT,
                    sanction_subject VARCHAR(255),
                    response_data JSON,
                    unique_key_hash VARCHAR(64),
                    UNIQUE(unique_key_hash)
                );
            """
        }

        for table_name, query in create_table_queries.items():
            try:
                self.cursor.execute(query)
                self.connection.commit()
                print(f"[INFO] Table '{table_name}' checked/created.")
            except Error as e:
                print(f"[ERROR] Error while creating/checking table '{table_name}': {e}")
                self.connection.rollback()

    def create_webdriver(self):
        chrome_options = Options()
        chrome_options.binary_location = self.CHROME_BINARY_PATH
        chrome_options.add_argument("--disable-gpu")
        chrome_options.add_argument("--no-sandbox")
        chrome_options.add_argument("--start-maximized")
        # chrome_options.add_argument(f'user-data-dir={self.PROFILE_PATH}')
        # chrome_options.add_argument(f'profile-directory={self.PROFILE_NAME}')
        service = ChromeService(executable_path=self.CHROMEDRIVER_PATH)
        return webdriver.Chrome(service=service, options=chrome_options)

    def login(self, app_id, app_pw):
        try:
            self.driver.get(self.LOGIN_URL)
            WebDriverWait(self.driver, 10).until(EC.presence_of_element_located((By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[1]/div/div/input')))
            id_box = self.driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[1]/div/div/input')
            password_box = self.driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[2]/div/div/input')
            login_button = self.driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[3]/button')
            id_box.send_keys(app_id)
            password_box.send_keys(app_pw)
            login_button.click()
            WebDriverWait(self.driver, 15).until(EC.url_to_be(self.TARGET_URL))
            print("[INFO] 로그인에 성공했습니다.")
        except TimeoutException as e:
            print("[ERROR] 이미 로그인 되었는지, 로그인 창으로 이동할 수 없습니다.")
        except Exception as e:
            print("[ERROR] 로그인 중 다른 오류 발생:", e)

    def extract_data_from_html(self, html_content):
        soup = BeautifulSoup(html_content, 'html.parser')
        tables = soup.find_all('table')
        structured_data = []
        unstructured_data = []

        for table in tables:
            rows = table.find_all('tr')
            table_data = []

            for row in rows:
                cols = row.find_all(['td', 'th'])
                cols = [ele.text.strip() for ele in cols]
                table_data.append(cols)

            structured_data.append(table_data)

        [s.extract() for s in soup(['style', 'script', '[document]', 'head', 'title'])]
        unstructured_data = soup.get_text(separator=' ', strip=True)

        return structured_data, unstructured_data

    def extract_auth_header(self):
        for request in self.driver.requests:
            if request.url == "https://dataservice.koscom.co.kr/apis/v1/common/auth/my-information":
                return {'Authorization': request.headers.get('Authorization')}
        return {}

    def send_api_request(self, url, headers):
        response = requests.get(url, headers=headers, verify=False)
        if response.status_code == 200:
            html_content = response.content.decode('utf-8')
            structured_data, unstructured_data = self.extract_data_from_html(html_content)
            return response.json(), structured_data, unstructured_data
        else:
            print(f"[ERROR] API 요청 실패. Status Code: {response.status_code}")
            print(f"Response: {response.text}")
            return None, None, None

    ### `24.03.21. debugging 용도
    def send_post_request(self, url, headers, body):
        # 요청 정보 디버깅을 위한 로그 출력
        print("[DEBUG] Sending POST request")
        print("[DEBUG] URL:", url)
        print("[DEBUG] Headers:", headers)
        print("[DEBUG] Body:", body)
    
        response = requests.post(url, headers=headers, json=body, verify=False)
    
        # 응답 정보 디버깅을 위한 로그 출력
        print("[DEBUG] Response Status Code:", response.status_code)
        print("[DEBUG] Response Body:", response.text)
    
        if response.status_code == 200:
            html_content = response.content.decode('utf-8')
            structured_data, unstructured_data = self.extract_data_from_html(html_content)
            return response.json(), structured_data, unstructured_data
        else:
            print(f"[ERROR] POST 요청 실패. Status Code: {response.status_code}")
            print(f"Response: {response.text}")
            return None, None, None

    def save_response_as_json(self, response_data, file_path):
        with open(file_path, 'w', encoding='utf-8') as file:
            json.dump(response_data, file, ensure_ascii=False, indent=4)


    def send_first_api_request(self, reference_id):
        self.REFERENCE_ID = reference_id 
        first_api_url = f'https://dataservice.koscom.co.kr/apis/v1/user/approvals/{self.REFERENCE_ID}'
        response_json, structured_data, unstructured_data = self.send_api_request(first_api_url, self.extract_auth_header())
        if response_json:
            for content in response_json.get("contents", []):
                # 여기에서 적절한 필드명으로 수정해야 할 수 있습니다.
                subject = content.get("subjectField", "")
                id = content.get("idField", 0)
                unique_key = f"{subject}-{id}"
                unique_key_hash = md5(unique_key.encode('utf-8')).hexdigest()
                print(f"[DEBUG] Processing item: {unique_key}, Hash: {unique_key_hash}")
    
                if unique_key_hash in self.existing_hashes_map:
                    print(f"[INFO] 중복 데이터 발견, 저장하지 않음: {unique_key_hash}")
                    continue
    
                nested_response = {
                    "page_info": response_json.get("page", {}),
                    "contents": content,
                    "unique_key_hash": unique_key_hash,
                    "subject": subject,
                    "id": id
                }
                self.all_responses[unique_key_hash] = nested_response
                print(f"ID {id} ({subject}) saved. Hash: {unique_key_hash}")
    
        self.save_response_as_json({"response": response_json, "structured": structured_data, "unstructured": unstructured_data}, "first_api_response.json")

    
    # total, totalpage 잘 가져올 수 있도록 수정 (`24.03.12.)
    def send_second_api_request(self, reference_id):
        self.REFERENCE_ID = reference_id 
        second_api_url = "https://dataservice.koscom.co.kr/apis/v1/common/snapshots/history"
        body = {
            'snapshotsLargeClassificationCode': '04',
            'snapshotsSmallClassificationCode': '04_01',
            'referenceId': self.REFERENCE_ID
        }
        response_json, structured_data, unstructured_data = self.send_post_request(second_api_url, self.extract_auth_header(), body)
        if response_json:
            # 페이지 정보 추출 및 클래스 변수에 저장
            self.total = response_json.get("page", {}).get("total", 0)
            self.totalPage = response_json.get("page", {}).get("totalPage", 0)
    
            for content in response_json.get("contents", []):
                # 적절한 필드명으로 수정. 예시에서는 subject와 id 필드명이 가정됨
                subject = content.get("subjectField", "")
                id = content.get("idField", 0)
                unique_key = f"{subject}-{id}"
                unique_key_hash = md5(unique_key.encode('utf-8')).hexdigest()
                print(f"[DEBUG] Processing item: {unique_key}, Hash: {unique_key_hash}")
    
                if unique_key_hash in self.existing_hashes_map:
                    print(f"[INFO] 중복 데이터 발견, 저장하지 않음: {unique_key_hash}")
                    continue
    
                nested_response = {
                    "page_info": response_json.get("page", {}),
                    "contents": content,
                    "unique_key_hash": unique_key_hash,
                    "subject": subject,
                    "id": id
                }
                self.all_responses[unique_key_hash] = nested_response
                print(f"ID {id} ({subject}) saved. Hash: {unique_key_hash}")
    
        # 응답 데이터 저장
        self.save_response_as_json({"response": response_json, "structured": structured_data, "unstructured": unstructured_data}, "second_api_response.json")

    def send_third_api_request(self, page_number):
        third_api_url = "https://dataservice.koscom.co.kr/apis/v1/user/approvals/search"
        body = {
            "startDate": "",
            "endDate": "",
            "sanctionTypeCode": "",
            "approvalStatusCode": "",
            "ordersSectionCode": "",
            "searchType": "SUBJECT",
            "searchText": "",
            "page": {
                "pageNumber": page_number,
                "pageSize": 10,
                "total": self.total,
                "totalPage": self.totalPage
            }
        }
        response_json, structured_data, unstructured_data = self.send_post_request(third_api_url, self.extract_auth_header(), body)
        if response_json:
            for content in response_json.get("contents", []):
                krx_sanction_subject = content.get("krxSanctionSubject", "")
                sanction_id = content.get("sanctionId", 0)
                unique_key = f"{krx_sanction_subject}-{sanction_id}"
                unique_key_hash = md5(unique_key.encode('utf-8')).hexdigest()
                print(f"[DEBUG] Processing item: {unique_key}, Hash: {unique_key_hash}")
    
                # 중복된 해시 값이 있는 경우, 데이터를 추가하지 않습니다.
                if unique_key_hash in self.existing_hashes_map:
                    print(f"[INFO] 중복 데이터 발견, 저장하지 않음: {unique_key_hash}")
                    continue
    
                # 중복되지 않은 경우, 데이터를 추가합니다.
                nested_response = {
                    "page_info": response_json.get("page", {}),
                    "contents": content,
                    "unique_key_hash": unique_key_hash,
                    "sanction_subject": krx_sanction_subject,
                    "sanction_id": sanction_id
                }
                self.all_responses[unique_key_hash] = nested_response
                print(f"Saction ID {sanction_id} ({krx_sanction_subject}) saved. Hash: {unique_key_hash}")

    def save_responses_to_database(self):
        print("[DEBUG] save_responses_to_database 함수 시작")
        self.connection.ping(reconnect=True)  # 데이터베이스 연결 확인 및 필요시 재연결
        for unique_key_hash, data in self.all_responses.items():
            with self.connection.cursor() as cursor:
                # 데이터베이스에서 unique_key_hash가 존재하는지 확인
                check_query = "SELECT COUNT(*) FROM Table_3st_API WHERE unique_key_hash = %s"
                cursor.execute(check_query, (unique_key_hash,))
                (count,) = cursor.fetchone()
        
                if count > 0:
                    print(f"[INFO] 중복 데이터 발견, 저장하지 않음: {unique_key_hash}")
                    continue  # 중복 데이터는 건너뜁니다.
                else:
                    print(f"[INFO] 새 데이터 발견, 저장 진행: {unique_key_hash}")
        
                # 중복이 아니면 새로운 데이터 저장
                page_info = data["page_info"]
                page_number = page_info.get("pageNumber", 0)
                response_data = json.dumps(data)
                sanction_id = data["sanction_id"]
                sanction_subject = data.get("sanction_subject", "") 
        
                insert_query = """
                INSERT INTO Table_3st_API (page_number, sanction_id, sanction_subject, response_data, unique_key_hash)
                VALUES (%s, %s, %s, %s, %s)
                """
                try:
                    cursor.execute(insert_query, (page_number, sanction_id, sanction_subject, response_data, unique_key_hash))
                    self.connection.commit() 
                    print(f"[DEBUG] 데이터 저장 성공: {unique_key_hash}")
                except Error as e:
                    print(f"[ERROR] 데이터 저장 중 오류 발생: {e}")
                    self.connection.rollback()
    
        print("[DEBUG] save_responses_to_database 함수 종료")

    # 현재는 용도가 별도로 없는 부분 (동시 파일 저장을 위해 구성했으나, 불용 예정)
    def save_first_second_api_responses_to_database(self, file_name, table_name):
        try:
            with open(file_name, 'r', encoding='utf-8') as file:
                data = json.load(file)
                response_data = json.dumps(data)

                with self.connection.cursor() as cursor:
                    query = f"""
                    INSERT INTO {table_name} (response_data)
                    VALUES (%s)
                    ON DUPLICATE KEY UPDATE
                    response_data = VALUES(response_data)
                    """
                    cursor.execute(query, (response_data,))
                    self.connection.commit()
                    print(f"[DEBUG] {file_name} 데이터 저장 성공")
        except Error as e:
            print(f"[ERROR] {file_name} 데이터 저장 중 오류 발생: {e}")
            self.connection.rollback()
        except FileNotFoundError:
            print(f"[ERROR] 파일 {file_name}을 찾을 수 없습니다.")

    def ensure_database_connection(self):
        if not self.connection.is_connected():
            print("[INFO] 데이터베이스 재연결 시도 중...")
            self.connection.reconnect(attempts=3, delay=5)

    def load_existing_hashes(self):
        self.ensure_database_connection() 
        self.cursor = self.connection.cursor() 
        print("[DEBUG] load_existing_hashes 함수 시작")
        self.existing_hashes_map.clear()
        try:
            query = "SELECT unique_key_hash, sanction_subject, sanction_id FROM Table_3st_API"
            self.cursor.execute(query)
            results = self.cursor.fetchall()
            for hash_value, subject, id in results:
                if subject is not None and id is not None:
                    self.existing_hashes_map[hash_value] = f"{subject}-{id}"
    
            # 기술 통계량 추가 (여기서 출력을 줄임)
            total_hashes = len(self.existing_hashes_map)
            print(f"[INFO] 총 해시 값 건수: {total_hashes}")
        except Error as e:
            print(f"[ERROR] 데이터 불러오기 중 오류 발생: {e}")
        finally:
            self.cursor.close() 
        print("[DEBUG] load_existing_hashes 함수 종료")
    
    def close(self):
        self.driver.quit()
        self.cursor.close()
        self.connection.close()
        print("[DEBUG] 데이터베이스 연결 닫힘")

    def check_data_in_specific_table(self, table_name):
        try:
            with self.connection.cursor() as cursor:
                query = f"SELECT * FROM {table_name} LIMIT 5"
                cursor.execute(query)
                results = cursor.fetchall()
                # for row in results:
                #     print(row)
        except Error as e:
            print(f"[ERROR] 데이터 확인 중 오류 발생 ({table_name}): {e}")


    # For debugging(`24.03.28.)
    def explore_and_extract_files(self, data, path=''):
        extracted_files = []
        debug_messages = []
    
        try:
            if isinstance(data, dict):
                for key, value in data.items():
                    new_path = f"{path}.{key}" if path else key
                    if key == 'fileUUID' and isinstance(value, str):
                        file_details, debug_message = self.extract_file_info(data, path)
                        extracted_files.append(file_details)
                        debug_messages.append(debug_message)
                    else:
                        child_files, child_messages = self.explore_and_extract_files(value, new_path)
                        extracted_files.extend(child_files)
                        debug_messages.extend(child_messages)
    
            elif isinstance(data, list):
                for index, item in enumerate(data):
                    new_path = f"{path}[{index}]"
                    child_files, child_messages = self.explore_and_extract_files(item, new_path)
                    extracted_files.extend(child_files)
                    debug_messages.extend(child_messages)
    
        except Exception as e:
            debug_message = f"[ERROR] 예외 발생: {e} 위치: {path}"
            debug_messages.append(debug_message)
    
        # 비어있지 않은 경우에만 extracted_files 출력
        if extracted_files:  # 이 조건을 통해 비어있지 않을 때만 출력합니다.
            for file in extracted_files:
                print(file)
                
        return extracted_files, debug_messages
        
    def extract_file_info(self, file_info, path):
        # 파일 정보를 안전하게 추출합니다.
        file_details = {
            'fileUUID': file_info.get('fileUUID', ''),
            'referenceId': file_info.get('referenceId', 'N/A'),  # 참조 ID가 없는 경우 'N/A'
            'fileSubject': file_info.get('fileSubject', 'N/A'),  # 파일 주제가 없는 경우 'N/A'
            'fileOrder': file_info.get('fileOrder', 0),
            'fileExtension': file_info.get('fileExtension', 'N/A'),  # 파일 확장자가 없는 경우 'N/A'
            'fileSecurityYn': file_info.get('fileSecurityYn', 'N'),  # 파일 보안 여부가 지정되지 않은 경우 'N'
            'fileCloudPath': file_info.get('fileCloudPath', 'N/A')  # 파일 클라우드 경로가 없는 경우 'N/A'
        }
        debug_message = f"[DEBUG] 파일 상세 정보 추출됨: {file_details} 위치: {path}"
        print(debug_message)
        return file_details, debug_message

    # ReferenceID 및 다운로드에 필요한 정보 추출용
    ### ① 3st API 에 저장되는 fileuuid 는 i) 주문서 / ii) 요약본 / iii) 이용조건 / iv) 계약서류 중 iv) "계약서류" + 추가 첨부파일 
    ### ② 2st API 에 저장되는 fileuuid 는 i) 주문서 / ii) 요약본 / iii) 이용조건 / iv) 계약서류 중 iii) "이용조건", "계약서류"
    def extract_details_from_database(self, table_choice):
        details = []
        # debug_messages = []  # 디버깅 메시지를 저장할 리스트
        self.debug_messages = []
        
        self.debug_messages.append(f"[DEBUG] 추출 시작: 테이블 {table_choice}")  # 디버깅 시작 메시지 추가
    
        if table_choice == '2':
            query = "SELECT response_data FROM Table_2st_API"
        elif table_choice == '3':
            query = "SELECT response_data FROM Table_3st_API"
        else:
            self.debug_messages.append("[ERROR] 잘못된 테이블 선택")
            return details
    
        try:
            with self.connection.cursor() as cursor:
                cursor.execute(query)
                results = cursor.fetchall()
                for result in results:
                    response_data = result[0]
                    if not isinstance(response_data, dict):
                        data = json.loads(response_data)
                    else:
                        data = response_data
                    
                    # # added (`24.03.28.)
                    # if table_choice == '2' or table_choice == '3':
                    #     # print("디버깅 시작")
                    #     child_details, child_debug_messages = self.explore_and_extract_files(data)
                    #     # print("디버깅 끝")
                    #     details.extend(child_details)
                    #     debug_messages.extend(child_debug_messages)

                    # if table_choice == '2':
                    #     try:
                    #         with self.connection.cursor() as cursor:
                    #             query = "SELECT response_data FROM Table_2st_API"
                    #             cursor.execute(query)
                    #             results = cursor.fetchall()
                    #             for result in results:
                    #                 response_data = result[0]
                    #                 if not isinstance(response_data, dict):
                    #                     data = json.loads(response_data)
                    #                 else:
                    #                     data = response_data
                                    
                    #                 # 파일 정보를 추출하는 함수 호출
                    #                 extracted_files, extract_debug_messages = self.explore_and_extract_files(data)
                    #                 details.extend(extracted_files)
                    #                 debug_messages.extend(extract_debug_messages)
                    #     except Exception as e:
                    #         debug_messages.append(f"[ERROR] 데이터 로드 중 오류 발생: {e}")
    
                    if table_choice == '2':
                        extracted_files, extract_debug_messages = self.explore_and_extract_files(data)
                        details.extend(extracted_files)
                        
                    elif table_choice == '3':
                        contents = data.get("contents", {})
                        if isinstance(contents, str):
                            contents = json.loads(contents)
                        file_mappings = contents.get("files", []) + contents.get("krxFiles", [])
                        for index, file_mapping in enumerate(file_mappings):
                            file_details = {
                                'fileUUID': file_mapping.get("fileUUID"),
                                'referenceId': file_mapping.get("fileMapping", {}).get("referenceId"),
                                'sanctionSubject': data.get("sanction_subject"),
                                'fileSubject': file_mapping.get("fileMapping", {}).get("fileSubject"),
                                'fileOrder': index + 1,
                                'fileExtension': file_mapping.get("fileExtension")
                            }
                            details.append(file_details)
    
        except Exception as e:
            self.debug_messages.append(f"[ERROR] 데이터 로드 중 오류 발생: {e}")
    
        # 디버깅 메시지를 파일에 저장
        with open('debug_info.txt', 'w', encoding='utf-8') as file:
            for message in self.debug_messages:
                file.write(f"{message}\n")
        
        self.summarize_json_structure(data) # `24.04.03. added 

        return details, data, self.debug_messages
    
    def summarize_json_structure(self, data, path=''):
        """JSON 데이터 구조를 요약하여 출력합니다."""
        """debugging messages 내에 데이터 구조 추가"""
        
        if isinstance(data, dict):
            for key, value in data.items():
                new_path = f"{path}.{key}" if path else key
                if isinstance(value, dict):
                    self.debug_messages.append(f"[STRUCTURE] {new_path}: Object")
                    self.summarize_json_structure(value, new_path)
                elif isinstance(value, list):
                    self.debug_messages.append(f"[STRUCTURE] {new_path}: Array")
                    if value:  # 리스트가 비어있지 않은 경우에만 첫 항목을 분석합니다.
                        self.summarize_json_structure(value[0], new_path + "[0]")
                else:
                    self.debug_messages.append(f"[STRUCTURE] {new_path}: {type(value).__name__}")
        elif isinstance(data, list):
            if data:  # 리스트가 비어있지 않은 경우에만 첫 항목을 분석합니다.
                self.summarize_json_structure(data[0], path + "[0]")
        
    # download_file 함수 수정
    def download_file(self, file_uuid, file_extension, sanction_subject, file_subject, file_order):
        base_url = "https://dataservice.koscom.co.kr"
        download_url = f"{base_url}/apis/v1/common/files?fileUUID={file_uuid}"
        
        headers = self.extract_auth_header()
        
        # 파일 이름 생성 방식 수정: sanctionSubject, fileSubject, referenceId, fileOrder 정보를 결합
        sanitized_file_subject = file_subject.replace("/", "_").replace(" ", "_")
        save_path = f"downloaded_{sanction_subject}_{sanitized_file_subject}_{file_order}.{file_extension}"
        
        response = requests.get(download_url, headers=headers, verify=False)
        if response.status_code == 200:
            with open(save_path, 'wb') as file:
                file.write(response.content)
            print(f"File downloaded successfully and saved as {save_path}")
        else:
            print(f"Failed to download file: Status code {response.status_code}, Response: {response.text}")

# 메인 실행 코드
if __name__ == "__main__":
    api_manager = APIManager()
    api_manager.login('goguma@krx.co.kr', 'wkrwjs12!@')

    request_input = input("실행할 API 요청을 선택하세요 (1: 첫 번째, 2: 두 번째, 3: 세 번째, 예: 1,2,3): ")
    selected_requests = request_input.split(',')

    if '1' in selected_requests:
        print("\n[INFO] 첫 번째 API 요청에 해당하는 데이터:")
        api_manager.check_data_in_specific_table('Table_1st_API')
        api_manager.send_first_api_request("100562")  # '100562'는 예시입니다. 적절한 값으로 교체해주세요.

    if '2' in selected_requests:
        print("\n[INFO] 두 번째 API 요청에 해당하는 데이터:")
        api_manager.check_data_in_specific_table('Table_2st_API')
        api_manager.send_second_api_request("100562")  # '100562'는 예시입니다. 적절한 값으로 교체해주세요.

    if '3' in selected_requests:
        print("\n[INFO] 세 번째 API 요청에 해당하는 데이터:")
        api_manager.check_data_in_specific_table('Table_3st_API')
        # '2' 요청이 없더라도 '3'이 선택될 경우 두 번째 API 요청을 통해 필요한 페이지 정보를 설정
        if '2' not in selected_requests:
            api_manager.send_second_api_request("100562")  # '100562'는 예시입니다. 적절한 값으로 교체해주세요.
        for page_number in range(1, api_manager.totalPage + 1):
            api_manager.send_third_api_request(page_number)

    api_manager.save_responses_to_database()

    # 사용자로부터 파일 정보를 추출할 테이블 선택 받기
    table_selection = input("파일 정보를 추출할 테이블을 선택하세요 (2: 두 번째 테이블, 3: 세 번째 테이블): ")

    # 파일 정보 추출 및 파일 다운로드 (Table 3은 정상 기능 중)
    file_details, json_data, debug_messages = api_manager.extract_details_from_database(table_selection)
    # for detail in file_details:
    #     file_uuid = detail['fileUUID']
    #     file_extension = detail['fileExtension']
    #     sanction_subject = detail['sanctionSubject'].replace("/", "_").replace(" ", "_")
    #     file_subject = detail['fileSubject']
    #     file_order = detail['fileOrder']
    #     api_manager.download_file(file_uuid, file_extension, sanction_subject, file_subject, file_order)

    api_manager.close()
    print("All tasks completed.")


# %% - temp : debugging
import mysql.connector
from mysql.connector import Error
import json

def connect_to_database():
    """데이터베이스에 연결하고 연결 객체를 반환합니다."""
    try:
        connection = mysql.connector.connect(
            host='localhost',
            database='first_api_tables',
            user='root',
            password='wkrwjs12!@'
        )
        if connection.is_connected():
            print("데이터베이스에 성공적으로 연결되었습니다.")
            return connection
    except Error as e:
        print(f"데이터베이스 연결 중 오류 발생: {e}")
        return None

def explore_and_extract_files(data, path=''):
    """재귀적으로 데이터를 탐색하며 파일 정보를 추출합니다."""
    extracted_files = []
    if isinstance(data, dict):
        # 파일 정보를 직접 추출하는 조건을 개선합니다.
        if 'fileUUID' in data and isinstance(data.get('fileUUID'), str):
            file_details = extract_file_info(data)
            extracted_files.append(file_details)
            print(f"[DEBUG] 파일 정보 발견: {file_details} 위치: {path}")
        else:
            # 딕셔너리의 모든 키-값 쌍에 대해 재귀적으로 탐색합니다.
            for key, value in data.items():
                child_files = explore_and_extract_files(value, f"{path}.{key}" if path else key)
                extracted_files.extend(child_files)
    elif isinstance(data, list):
        # 리스트의 각 항목에 대해 재귀적으로 탐색합니다.
        for index, item in enumerate(data):
            child_files = explore_and_extract_files(item, f"{path}[{index}]")
            extracted_files.extend(child_files)
    return extracted_files

def extract_file_info(file_info):
    """파일 정보를 추출하는 로직입니다."""
    return {
        'fileUUID': file_info.get('fileUUID', ''),
        'referenceId': file_info.get('referenceId', ''),
        'fileSubject': file_info.get('fileSubject', ''),
        'fileOrder': file_info.get('fileOrder', 0),
        'fileExtension': file_info.get('fileExtension', ''),
        'fileSecurityYn': file_info.get('fileSecurityYn', 'N'),
        'fileCloudPath': file_info.get('fileCloudPath', '')
    }

def query_response_data_structure(connection):
    """Table_2st_API 테이블에서 response_data를 조회하고, 파일 정보를 추출합니다."""
    try:
        cursor = connection.cursor()
        query = "SELECT response_data FROM Table_2st_API"
        cursor.execute(query)
        rows = cursor.fetchall()
        for row in rows:
            response_data = json.loads(row[0])
            extracted_files = explore_and_extract_files(response_data)
            print("추출된 파일 정보:")
            for file in extracted_files:
                print(file)
    except Error as e:
        print(f"데이터 조회 중 오류 발생: {e}")

def main():
    connection = connect_to_database()
    if connection is not None:
        query_response_data_structure(connection)
        connection.close()
        print("데이터베이스 연결이 종료되었습니다.")

if __name__ == "__main__":
    main()
