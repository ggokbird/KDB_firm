from flask import Flask, render_template
import logging
from bokeh.plotting import figure
from bokeh.embed import components
from bokeh.models import ColumnDataSource, HoverTool
import pandas as pd

import os

# 원하는 워킹 디렉토리로 변경
os.chdir('C:\\Users\\221016\\Desktop\\KRX\\CRM')

# 현재 워킹 디렉토리 확인
print("Current Working Directory: ", os.getcwd())

app = Flask(__name__)

# 로깅 설정
logging.basicConfig(level=logging.DEBUG)

# 데이터 샘플
data = {
    "type": ["direct", "indirect", "indirect", "direct"],
    "latitude": [37.5665, 37.456, 37.5759, 37.5701],
    "longitude": [126.9780, 126.7052, 126.9770, 126.9827],
    "sales": [1000, 1500, 2000, 1200],
    "product": ["Product A", "Product B", "Product A", "Product C"],
    "vendor": ["", "Vendor 1", "Vendor 2", ""]
}

@app.route('/')
def index():
    try:
        df = pd.DataFrame(data)
        source = ColumnDataSource(df)

        # 지도 생성
        p = figure(title="Data Sales Customers on Korea Exchange", x_axis_label='Latitude', y_axis_label='Longitude')

        # 색상 구분
        color_map = {'direct': 'blue', 'indirect': 'green'}
        df['color'] = df['type'].map(color_map)

        # 원형 마커 추가
        p.circle('latitude', 'longitude', source=source, color='color', size=10)

        # 호버 도구 추가
        hover = HoverTool()
        hover.tooltips = [("Type", "@type"), ("Sales", "@sales"), ("Product", "@product"), ("Vendor", "@vendor")]
        p.add_tools(hover)

        # HTML에 삽입
        script, div = components(p)
        return render_template("index.html", script=script, div=div)
    except Exception as e:
        app.logger.error('오류 발생: %s', e)
        return "오류가 발생했습니다"

if __name__ == '__main__':
    app.run(debug=True, use_reloader=False)
