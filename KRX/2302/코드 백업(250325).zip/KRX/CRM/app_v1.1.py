# -*- coding: utf-8 -*-
"""
Created on Sun Jan 14 17:33:43 2024

@author: 221016

# use_reloader = False → 필수 
# JS Bockeh 버전 수시 확인 (ex 3.3.3)
"""

from flask import Flask, render_template
from bokeh.plotting import figure
from bokeh.embed import components
from bokeh.models import ColumnDataSource, HoverTool
import pandas as pd

app = Flask(__name__)

# 데이터 샘플을 정의합니다.
data = {
    "type": ["direct", "indirect", "indirect", "direct"],
    "latitude": [37.5665, 37.456, 37.5759, 37.5701],
    "longitude": [126.9780, 126.7052, 126.9770, 126.9827],
    "sales": [1000, 1500, 2000, 1200],
    "product": ["Product A", "Product B", "Product A", "Product C"],
    "vendor": ["", "Vendor 1", "Vendor 2", ""]
}

@app.route('/')
def index():
    df = pd.DataFrame(data)

    # 색상 구분을 위해 'color' 열을 데이터프레임에 추가합니다.
    color_map = {'direct': 'blue', 'indirect': 'green'}
    df['color'] = df['type'].map(color_map)

    source = ColumnDataSource(df)
    
    # 그래프를 생성합니다.
    p = figure(title="Data Sales Customers on Korea Exchange", x_axis_label='Latitude', y_axis_label='Longitude')
    
    # 그래프에 원형 마커를 추가합니다.
    p.circle('latitude', 'longitude', source=source, color='color', size=10)
    
    # 호버 도구를 추가합니다.
    hover = HoverTool()
    hover.tooltips = [("Type", "@type"), ("Sales", "@sales"), ("Product", "@product"), ("Vendor", "@vendor")]
    p.add_tools(hover)
    
    # Bokeh 컴포넌트를 생성합니다.
    script, div = components(p)
    
    # 'index.html' 템플릿을 렌더링하고 Bokeh 스크립트와 div를 전달합니다.
    return render_template("index.html", the_script=script, the_div=div)

# 메인 함수에서 애플리케이션을 실행합니다.
if __name__ == '__main__':
    app.run(debug=True, use_reloader=False)
