# -*- coding: utf-8 -*-
"""
Created on Tue Jan 16 20:17:26 2024

@author: 221016
"""

"""
1. send_first_api_request 함수는 https://dataservice.koscom.co.kr/apis/v1/user/approvals/{self.REFERENCE_ID} 주소로 GET 요청을 보내는 것으로 보입니다. 이는 특정 사용자의 승인 목록을 조회하는 API
# (Wd 에 파일로 저장됨)
# (input 은 Reference ID -> Third API 에서 선 수집 필요)

2. send_second_api_request 함수는 https://dataservice.koscom.co.kr/apis/v1/common/snapshots/history 주소로 POST 요청을 보내고, 특정 조건에 맞는 스냅샷의 히스토리 데이터를 조회하는 API
# (Wd 에 파일로 저장됨)
# (input 은 Reference ID -> Third API 에서 선 수집 필요)

3. send_third_api_request 함수는 https://dataservice.koscom.co.kr/apis/v1/user/approvals/search 주소로 POST 요청을 보내고, 특정 조건을 만족하는 승인 요청들을 검색하는 API
# (sql db 에 저장됨)
# (input 은 Page Number)
"""
# %% - + First, Second 
import json
import requests
from hashlib import md5
from seleniumwire import webdriver
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException, WebDriverException
from bs4 import BeautifulSoup
from tqdm import tqdm
import time
from mysql.connector import connect, Error
import urllib3

class APIManager:
    def __init__(self):
        self.CHROMEDRIVER_PATH = 'C:\\Users\\KRX\\Desktop\\201021\\chromedriver-win32\\chromedriver.exe'
        self.CHROME_BINARY_PATH = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe'
        self.LOGIN_URL = 'https://dataservice.koscom.co.kr/login?returnUrl=/krx/approval-list'
        self.TARGET_URL = 'https://dataservice.koscom.co.kr/krx/approval-list'
        self.PROFILE_PATH = 'C:\\Users\\KRX\\Desktop\\201021'
        self.PROFILE_NAME = 'Profile 4'
        self.REFERENCE_ID = 100562
        self.driver = self.create_webdriver()
        self.all_responses = {}
        urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

        self.connection = connect(
            host='localhost',
            database='first_api_tables',
            user='root',
            password='wkrwjs12!@'
        )
        self.cursor = self.connection.cursor()
        self.create_tables_if_not_exists()
        self.existing_hashes_map = {}
        self.load_existing_hashes()

    def create_tables_if_not_exists(self):
        create_table_queries = {
            'Table_1st_API': """
                CREATE TABLE IF NOT EXISTS table_1st_api (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    response_data JSON
                );
            """,
            'Table_2st_API': """
                CREATE TABLE IF NOT EXISTS table_2st_api (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    response_data JSON
                );
            """,
            'Table_3st_API': """
                CREATE TABLE IF NOT EXISTS table_3st_api (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    page_number INT,
                    sanction_id INT,
                    sanction_subject VARCHAR(255),
                    response_data JSON,
                    unique_key_hash VARCHAR(64),
                    UNIQUE(unique_key_hash)
                );
            """
        }

        for table_name, query in create_table_queries.items():
            try:
                self.cursor.execute(query)
                self.connection.commit()
                print(f"[INFO] Table '{table_name}' checked/created.")
            except Error as e:
                print(f"[ERROR] Error while creating/checking table '{table_name}': {e}")
                self.connection.rollback()

    def create_webdriver(self):
        chrome_options = Options()
        chrome_options.binary_location = self.CHROME_BINARY_PATH
        chrome_options.add_argument("--disable-gpu")
        chrome_options.add_argument("--no-sandbox")
        chrome_options.add_argument("--start-maximized")
        chrome_options.add_argument(f'user-data-dir={self.PROFILE_PATH}')
        chrome_options.add_argument(f'profile-directory={self.PROFILE_NAME}')
        service = ChromeService(executable_path=self.CHROMEDRIVER_PATH)
        return webdriver.Chrome(service=service, options=chrome_options)

    def login(self, app_id, app_pw):
        try:
            self.driver.get(self.LOGIN_URL)
            WebDriverWait(self.driver, 10).until(EC.presence_of_element_located((By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[1]/div/div/input')))
            id_box = self.driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[1]/div/div/input')
            password_box = self.driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[2]/div/div/input')
            login_button = self.driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[3]/button')
            id_box.send_keys(app_id)
            password_box.send_keys(app_pw)
            login_button.click()
            WebDriverWait(self.driver, 15).until(EC.url_to_be(self.TARGET_URL))
            print("[INFO] 로그인에 성공했습니다.")
        except TimeoutException as e:
            print("[ERROR] 이미 로그인 되었는지, 로그인 창으로 이동할 수 없습니다.")
        except Exception as e:
            print("[ERROR] 로그인 중 다른 오류 발생:", e)

    def extract_data_from_html(self, html_content):
        soup = BeautifulSoup(html_content, 'html.parser')
        tables = soup.find_all('table')
        structured_data = []
        unstructured_data = []

        for table in tables:
            rows = table.find_all('tr')
            table_data = []

            for row in rows:
                cols = row.find_all(['td', 'th'])
                cols = [ele.text.strip() for ele in cols]
                table_data.append(cols)

            structured_data.append(table_data)

        [s.extract() for s in soup(['style', 'script', '[document]', 'head', 'title'])]
        unstructured_data = soup.get_text(separator=' ', strip=True)

        return structured_data, unstructured_data

    def extract_auth_header(self):
        for request in self.driver.requests:
            if request.url == "https://dataservice.koscom.co.kr/apis/v1/common/auth/my-information":
                return {'Authorization': request.headers.get('Authorization')}
        return {}

    def send_api_request(self, url, headers):
        response = requests.get(url, headers=headers, verify=False)
        if response.status_code == 200:
            html_content = response.content.decode('utf-8')
            structured_data, unstructured_data = self.extract_data_from_html(html_content)
            return response.json(), structured_data, unstructured_data
        else:
            print(f"[ERROR] API 요청 실패. Status Code: {response.status_code}")
            print(f"Response: {response.text}")
            return None, None, None

    def send_post_request(self, url, headers, body):
        response = requests.post(url, headers=headers, json=body, verify=False)
        if response.status_code == 200:
            html_content = response.content.decode('utf-8')
            structured_data, unstructured_data = self.extract_data_from_html(html_content)
            return response.json(), structured_data, unstructured_data
        else:
            print(f"[ERROR] POST 요청 실패. Status Code: {response.status_code}")
            print(f"Response: {response.text}")
            return None, None, None

    def save_response_as_json(self, response_data, file_path):
        with open(file_path, 'w', encoding='utf-8') as file:
            json.dump(response_data, file, ensure_ascii=False, indent=4)

    def send_first_api_request(self):
        first_api_url = f'https://dataservice.koscom.co.kr/apis/v1/user/approvals/{self.REFERENCE_ID}'
        response_json, structured_data, unstructured_data = self.send_api_request(first_api_url, self.extract_auth_header())
        if response_json:
            self.total = response_json.get("page", {}).get("total", 0)
            self.totalPage = response_json.get("page", {}).get("totalPage", 0)
            self.save_response_as_json({"response": response_json, "structured": structured_data, "unstructured": unstructured_data}, "first_api_response.json")    

    
    def send_second_api_request(self):
        second_api_url = "https://dataservice.koscom.co.kr/apis/v1/common/snapshots/history"
        body = {
            'snapshotsLargeClassificationCode': '04',
            'snapshotsSmallClassificationCode': '04_01',
            'referenceId': self.REFERENCE_ID
        }
        response_json, structured_data, unstructured_data = self.send_post_request(second_api_url, self.extract_auth_header(), body)
        self.save_response_as_json({"response": response_json, "structured": structured_data, "unstructured": unstructured_data}, "second_api_response.json")

    def send_third_api_request(self, page_number):
        third_api_url = "https://dataservice.koscom.co.kr/apis/v1/user/approvals/search"
        body = {
            "startDate": "",
            "endDate": "",
            "sanctionTypeCode": "",
            "approvalStatusCode": "",
            "ordersSectionCode": "",
            "searchType": "SUBJECT",
            "searchText": "",
            "page": {
                "pageNumber": page_number,
                "pageSize": 10,
                "total": self.total,
                "totalPage": self.totalPage
            }
        }
        response_json, structured_data, unstructured_data = self.send_post_request(third_api_url, self.extract_auth_header(), body)
        if response_json:
            for content in response_json.get("contents", []):
                krx_sanction_subject = content.get("krxSanctionSubject", "")
                sanction_id = content.get("sanctionId", 0)
                unique_key = f"{krx_sanction_subject}-{sanction_id}"
                unique_key_hash = md5(unique_key.encode('utf-8')).hexdigest()
                print(f"[DEBUG] Processing item: {unique_key}, Hash: {unique_key_hash}")
    
                # 중복된 해시 값이 있는 경우, 데이터를 추가하지 않습니다.
                if unique_key_hash in self.existing_hashes_map:
                    print(f"[INFO] 중복 데이터 발견, 저장하지 않음: {unique_key_hash}")
                    continue
    
                # 중복되지 않은 경우, 데이터를 추가합니다.
                nested_response = {
                    "page_info": response_json.get("page", {}),
                    "contents": content,
                    "unique_key_hash": unique_key_hash,
                    "sanction_subject": krx_sanction_subject,
                    "sanction_id": sanction_id
                }
                self.all_responses[unique_key_hash] = nested_response
                print(f"Saction ID {sanction_id} ({krx_sanction_subject}) saved. Hash: {unique_key_hash}")

    def save_responses_to_database(self):
        print("[DEBUG] save_responses_to_database 함수 시작")
        self.connection.ping(reconnect=True)  # 데이터베이스 연결 확인 및 필요시 재연결
        for unique_key_hash, data in self.all_responses.items():
            with self.connection.cursor() as cursor:
                # 데이터베이스에서 unique_key_hash가 존재하는지 확인
                check_query = "SELECT COUNT(*) FROM Table_3st_API WHERE unique_key_hash = %s"
                cursor.execute(check_query, (unique_key_hash,))
                (count,) = cursor.fetchone()
        
                if count > 0:
                    print(f"[INFO] 중복 데이터 발견, 저장하지 않음: {unique_key_hash}")
                    continue  # 중복 데이터는 건너뜁니다.
                else:
                    print(f"[INFO] 새 데이터 발견, 저장 진행: {unique_key_hash}")
        
                # 중복이 아니면 새로운 데이터 저장
                page_info = data["page_info"]
                page_number = page_info.get("pageNumber", 0)
                response_data = json.dumps(data)
                sanction_id = data["sanction_id"]
                sanction_subject = data.get("sanction_subject", "") 
        
                insert_query = """
                INSERT INTO Table_3st_API (page_number, sanction_id, sanction_subject, response_data, unique_key_hash)
                VALUES (%s, %s, %s, %s, %s)
                """
                try:
                    cursor.execute(insert_query, (page_number, sanction_id, sanction_subject, response_data, unique_key_hash))
                    self.connection.commit() 
                    print(f"[DEBUG] 데이터 저장 성공: {unique_key_hash}")
                except Error as e:
                    print(f"[ERROR] 데이터 저장 중 오류 발생: {e}")
                    self.connection.rollback()
    
        print("[DEBUG] save_responses_to_database 함수 종료")

    def save_first_second_api_responses_to_database(self, file_name, table_name):
        try:
            with open(file_name, 'r', encoding='utf-8') as file:
                data = json.load(file)
                response_data = json.dumps(data)

                with self.connection.cursor() as cursor:
                    query = f"""
                    INSERT INTO {table_name} (response_data)
                    VALUES (%s)
                    ON DUPLICATE KEY UPDATE
                    response_data = VALUES(response_data)
                    """
                    cursor.execute(query, (response_data,))
                    self.connection.commit()
                    print(f"[DEBUG] {file_name} 데이터 저장 성공")
        except Error as e:
            print(f"[ERROR] {file_name} 데이터 저장 중 오류 발생: {e}")
            self.connection.rollback()
        except FileNotFoundError:
            print(f"[ERROR] 파일 {file_name}을 찾을 수 없습니다.")

    def ensure_database_connection(self):
        if not self.connection.is_connected():
            print("[INFO] 데이터베이스 재연결 시도 중...")
            self.connection.reconnect(attempts=3, delay=5)

    def load_existing_hashes(self):
        self.ensure_database_connection() 
        self.cursor = self.connection.cursor() 
        print("[DEBUG] load_existing_hashes 함수 시작")
        self.existing_hashes_map.clear()
        try:
            query = "SELECT unique_key_hash, sanction_subject, sanction_id FROM Table_3st_API"
            self.cursor.execute(query)
            results = self.cursor.fetchall()
            for hash_value, subject, id in results:
                if subject is not None and id is not None:
                    self.existing_hashes_map[hash_value] = f"{subject}-{id}"
    
            # 기술 통계량 추가 (여기서 출력을 줄임)
            total_hashes = len(self.existing_hashes_map)
            print(f"[INFO] 총 해시 값 건수: {total_hashes}")
        except Error as e:
            print(f"[ERROR] 데이터 불러오기 중 오류 발생: {e}")
        finally:
            self.cursor.close() 
        print("[DEBUG] load_existing_hashes 함수 종료")
    
    def close(self):
        self.driver.quit()
        self.cursor.close()
        self.connection.close()
        print("[DEBUG] 데이터베이스 연결 닫힘")

def check_data_in_database(connection):
    tables = ['Table_1st_API', 'Table_2st_API', 'Table_3st_API']
    data_objects = {}

    for table in tables:
        data_objects[table] = []
        try:
            with connection.cursor() as cursor:
                query = f"SELECT * FROM {table} LIMIT 5"  # 각 테이블에서 상위 5개 데이터 조회
                cursor.execute(query)
                results = cursor.fetchall()
                data_objects[table].extend(results)
        except mysql.connector.Error as e:
            print(f"[ERROR] 데이터 확인 중 오류 발생 ({table}): {e}")

    return data_objects

# 메인 실행 코드
if __name__ == "__main__":
    api_manager = APIManager()
    api_manager.login('goguma@krx.co.kr', 'wkrwjs12!@')
    api_manager.send_first_api_request()
    api_manager.send_second_api_request()
    for page_number in tqdm(range(1, 2), desc="Processing"):
        time.sleep(10)
        api_manager.send_third_api_request(page_number)
    api_manager.save_responses_to_database()

    # 저장된 데이터 확인 및 객체에 저장
    database_data = check_data_in_database(api_manager.connection)

    # 객체에 저장된 데이터 출력
    # for table, data in database_data.items():
    #     print(f"\n[INFO] 데이터 확인 - {table}:")
    #     for row in data:
    #         print(row)

    api_manager.close()
    print("All tasks completed.")

# %% `24.02.28. 위 코드는 1-2 api 결과는 SQL 에 저장하지 않아, 후에 Fast API 와 연계되지 않는 부분이 있음 
# 로컬 저장 뿐만 아니라, SQL 에도 저장하여 동적 연계가 가능하도록 수정 
import json
import requests
from hashlib import md5
from seleniumwire import webdriver
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException, WebDriverException
from bs4 import BeautifulSoup
from tqdm import tqdm
import time
from mysql.connector import connect, Error
import urllib3
import sys

class APIManager:
    def __init__(self):
        self.CHROMEDRIVER_PATH = 'C:\\Users\\KRX\\Desktop\\201021\\chromedriver-win32\\chromedriver.exe'
        self.CHROME_BINARY_PATH = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe'
        self.LOGIN_URL = 'https://dataservice.koscom.co.kr/login?returnUrl=/krx/approval-list'
        self.TARGET_URL = 'https://dataservice.koscom.co.kr/krx/approval-list'
        self.PROFILE_PATH = 'C:\\Users\\KRX\\Desktop\\201021'
        self.PROFILE_NAME = 'Profile 4'
        self.REFERENCE_ID = None # third API 결과에서 얻어와야함 
        self.driver = self.create_webdriver()
        self.all_responses = {}
        urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

        self.connection = connect(
            host='localhost',
            database='first_api_tables',
            user='root',
            password='wkrwjs12!@'
        )
        self.cursor = self.connection.cursor()
        self.create_tables_if_not_exists()
        self.existing_hashes_map = {}
        self.load_existing_hashes()

    def create_tables_if_not_exists(self):
        create_table_queries = {
            'Table_1st_API': """
                CREATE TABLE IF NOT EXISTS table_1st_api (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    response_data JSON
                );
            """,
            'Table_2st_API': """
                CREATE TABLE IF NOT EXISTS table_2st_api (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    response_data JSON
                );
            """,
            'Table_3st_API': """
                CREATE TABLE IF NOT EXISTS table_3st_api (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    page_number INT,
                    sanction_id INT,
                    sanction_subject VARCHAR(255),
                    response_data JSON,
                    unique_key_hash VARCHAR(64),
                    UNIQUE(unique_key_hash)
                );
            """
        }

        for table_name, query in create_table_queries.items():
            try:
                self.cursor.execute(query)
                self.connection.commit()
                print(f"[INFO] Table '{table_name}' checked/created.")
            except Error as e:
                print(f"[ERROR] Error while creating/checking table '{table_name}': {e}")
                self.connection.rollback()

    def create_webdriver(self):
        chrome_options = Options()
        chrome_options.binary_location = self.CHROME_BINARY_PATH
        chrome_options.add_argument("--disable-gpu")
        chrome_options.add_argument("--no-sandbox")
        chrome_options.add_argument("--start-maximized")
        chrome_options.add_argument(f'user-data-dir={self.PROFILE_PATH}')
        chrome_options.add_argument(f'profile-directory={self.PROFILE_NAME}')
        service = ChromeService(executable_path=self.CHROMEDRIVER_PATH)
        return webdriver.Chrome(service=service, options=chrome_options)

    def login(self, app_id, app_pw):
        try:
            self.driver.get(self.LOGIN_URL)
            WebDriverWait(self.driver, 10).until(EC.presence_of_element_located((By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[1]/div/div/input')))
            id_box = self.driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[1]/div/div/input')
            password_box = self.driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[2]/div/div/input')
            login_button = self.driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[3]/button')
            id_box.send_keys(app_id)
            password_box.send_keys(app_pw)
            login_button.click()
            WebDriverWait(self.driver, 15).until(EC.url_to_be(self.TARGET_URL))
            print("[INFO] 로그인에 성공했습니다.")
        except TimeoutException as e:
            print("[ERROR] 이미 로그인 되었는지, 로그인 창으로 이동할 수 없습니다.")
        except Exception as e:
            print("[ERROR] 로그인 중 다른 오류 발생:", e)

    def extract_data_from_html(self, html_content):
        soup = BeautifulSoup(html_content, 'html.parser')
        tables = soup.find_all('table')
        structured_data = []
        unstructured_data = []

        for table in tables:
            rows = table.find_all('tr')
            table_data = []

            for row in rows:
                cols = row.find_all(['td', 'th'])
                cols = [ele.text.strip() for ele in cols]
                table_data.append(cols)

            structured_data.append(table_data)

        [s.extract() for s in soup(['style', 'script', '[document]', 'head', 'title'])]
        unstructured_data = soup.get_text(separator=' ', strip=True)

        return structured_data, unstructured_data

    def extract_auth_header(self):
        for request in self.driver.requests:
            if request.url == "https://dataservice.koscom.co.kr/apis/v1/common/auth/my-information":
                return {'Authorization': request.headers.get('Authorization')}
        return {}

    def send_api_request(self, url, headers):
        response = requests.get(url, headers=headers, verify=False)
        if response.status_code == 200:
            html_content = response.content.decode('utf-8')
            structured_data, unstructured_data = self.extract_data_from_html(html_content)
            return response.json(), structured_data, unstructured_data
        else:
            print(f"[ERROR] API 요청 실패. Status Code: {response.status_code}")
            print(f"Response: {response.text}")
            return None, None, None

    def send_post_request(self, url, headers, body):
        response = requests.post(url, headers=headers, json=body, verify=False)
        if response.status_code == 200:
            html_content = response.content.decode('utf-8')
            structured_data, unstructured_data = self.extract_data_from_html(html_content)
            return response.json(), structured_data, unstructured_data
        else:
            print(f"[ERROR] POST 요청 실패. Status Code: {response.status_code}")
            print(f"Response: {response.text}")
            return None, None, None

    def save_response_as_json(self, response_data, file_path):
        with open(file_path, 'w', encoding='utf-8') as file:
            json.dump(response_data, file, ensure_ascii=False, indent=4)


    def send_first_api_request(self, reference_id):
        self.REFERENCE_ID = reference_id 
        first_api_url = f'https://dataservice.koscom.co.kr/apis/v1/user/approvals/{self.REFERENCE_ID}'
        response_json, structured_data, unstructured_data = self.send_api_request(first_api_url, self.extract_auth_header())
        if response_json:
            for content in response_json.get("contents", []):
                # 여기에서 적절한 필드명으로 수정해야 할 수 있습니다.
                subject = content.get("subjectField", "")
                id = content.get("idField", 0)
                unique_key = f"{subject}-{id}"
                unique_key_hash = md5(unique_key.encode('utf-8')).hexdigest()
                print(f"[DEBUG] Processing item: {unique_key}, Hash: {unique_key_hash}")
    
                if unique_key_hash in self.existing_hashes_map:
                    print(f"[INFO] 중복 데이터 발견, 저장하지 않음: {unique_key_hash}")
                    continue
    
                nested_response = {
                    "page_info": response_json.get("page", {}),
                    "contents": content,
                    "unique_key_hash": unique_key_hash,
                    "subject": subject,
                    "id": id
                }
                self.all_responses[unique_key_hash] = nested_response
                print(f"ID {id} ({subject}) saved. Hash: {unique_key_hash}")
    
        self.save_response_as_json({"response": response_json, "structured": structured_data, "unstructured": unstructured_data}, "first_api_response.json")

    """
    def send_second_api_request(self, reference_id):
        self.REFERENCE_ID = reference_id 
        second_api_url = "https://dataservice.koscom.co.kr/apis/v1/common/snapshots/history"
        body = {
            'snapshotsLargeClassificationCode': '04',
            'snapshotsSmallClassificationCode': '04_01',
            'referenceId': self.REFERENCE_ID
        }
        response_json, structured_data, unstructured_data = self.send_post_request(second_api_url, self.extract_auth_header(), body)
        if response_json:
            for content in response_json.get("contents", []):
                # 여기에서 적절한 필드명으로 수정해야 할 수 있습니다.
                subject = content.get("subjectField", "")
                id = content.get("idField", 0)
                unique_key = f"{subject}-{id}"
                unique_key_hash = md5(unique_key.encode('utf-8')).hexdigest()
                print(f"[DEBUG] Processing item: {unique_key}, Hash: {unique_key_hash}")
    
                if unique_key_hash in self.existing_hashes_map:
                    print(f"[INFO] 중복 데이터 발견, 저장하지 않음: {unique_key_hash}")
                    continue
    
                nested_response = {
                    "page_info": response_json.get("page", {}),
                    "contents": content,
                    "unique_key_hash": unique_key_hash,
                    "subject": subject,
                    "id": id
                }
                self.all_responses[unique_key_hash] = nested_response
                print(f"ID {id} ({subject}) saved. Hash: {unique_key_hash}")
    
        self.save_response_as_json({"response": response_json, "structured": structured_data, "unstructured": unstructured_data}, "second_api_response.json")
    """
    
    # total, totalpage 잘 가져올 수 있도록 수정 (`24.03.12.)
    def send_second_api_request(self, reference_id):
        self.REFERENCE_ID = reference_id 
        second_api_url = "https://dataservice.koscom.co.kr/apis/v1/common/snapshots/history"
        body = {
            'snapshotsLargeClassificationCode': '04',
            'snapshotsSmallClassificationCode': '04_01',
            'referenceId': self.REFERENCE_ID
        }
        response_json, structured_data, unstructured_data = self.send_post_request(second_api_url, self.extract_auth_header(), body)
        if response_json:
            # 페이지 정보 추출 및 클래스 변수에 저장
            self.total = response_json.get("page", {}).get("total", 0)
            self.totalPage = response_json.get("page", {}).get("totalPage", 0)
    
            for content in response_json.get("contents", []):
                # 적절한 필드명으로 수정. 예시에서는 subject와 id 필드명이 가정됨
                subject = content.get("subjectField", "")
                id = content.get("idField", 0)
                unique_key = f"{subject}-{id}"
                unique_key_hash = md5(unique_key.encode('utf-8')).hexdigest()
                print(f"[DEBUG] Processing item: {unique_key}, Hash: {unique_key_hash}")
    
                if unique_key_hash in self.existing_hashes_map:
                    print(f"[INFO] 중복 데이터 발견, 저장하지 않음: {unique_key_hash}")
                    continue
    
                nested_response = {
                    "page_info": response_json.get("page", {}),
                    "contents": content,
                    "unique_key_hash": unique_key_hash,
                    "subject": subject,
                    "id": id
                }
                self.all_responses[unique_key_hash] = nested_response
                print(f"ID {id} ({subject}) saved. Hash: {unique_key_hash}")
    
        # 응답 데이터 저장
        self.save_response_as_json({"response": response_json, "structured": structured_data, "unstructured": unstructured_data}, "second_api_response.json")

    def send_third_api_request(self, page_number):
        third_api_url = "https://dataservice.koscom.co.kr/apis/v1/user/approvals/search"
        body = {
            "startDate": "",
            "endDate": "",
            "sanctionTypeCode": "",
            "approvalStatusCode": "",
            "ordersSectionCode": "",
            "searchType": "SUBJECT",
            "searchText": "",
            "page": {
                "pageNumber": page_number,
                "pageSize": 10,
                "total": self.total,
                "totalPage": self.totalPage
            }
        }
        response_json, structured_data, unstructured_data = self.send_post_request(third_api_url, self.extract_auth_header(), body)
        if response_json:
            for content in response_json.get("contents", []):
                krx_sanction_subject = content.get("krxSanctionSubject", "")
                sanction_id = content.get("sanctionId", 0)
                unique_key = f"{krx_sanction_subject}-{sanction_id}"
                unique_key_hash = md5(unique_key.encode('utf-8')).hexdigest()
                print(f"[DEBUG] Processing item: {unique_key}, Hash: {unique_key_hash}")
    
                # 중복된 해시 값이 있는 경우, 데이터를 추가하지 않습니다.
                if unique_key_hash in self.existing_hashes_map:
                    print(f"[INFO] 중복 데이터 발견, 저장하지 않음: {unique_key_hash}")
                    continue
    
                # 중복되지 않은 경우, 데이터를 추가합니다.
                nested_response = {
                    "page_info": response_json.get("page", {}),
                    "contents": content,
                    "unique_key_hash": unique_key_hash,
                    "sanction_subject": krx_sanction_subject,
                    "sanction_id": sanction_id
                }
                self.all_responses[unique_key_hash] = nested_response
                print(f"Saction ID {sanction_id} ({krx_sanction_subject}) saved. Hash: {unique_key_hash}")

    def save_responses_to_database(self):
        print("[DEBUG] save_responses_to_database 함수 시작")
        self.connection.ping(reconnect=True)  # 데이터베이스 연결 확인 및 필요시 재연결
        for unique_key_hash, data in self.all_responses.items():
            with self.connection.cursor() as cursor:
                # 데이터베이스에서 unique_key_hash가 존재하는지 확인
                check_query = "SELECT COUNT(*) FROM Table_3st_API WHERE unique_key_hash = %s"
                cursor.execute(check_query, (unique_key_hash,))
                (count,) = cursor.fetchone()
        
                if count > 0:
                    print(f"[INFO] 중복 데이터 발견, 저장하지 않음: {unique_key_hash}")
                    continue  # 중복 데이터는 건너뜁니다.
                else:
                    print(f"[INFO] 새 데이터 발견, 저장 진행: {unique_key_hash}")
        
                # 중복이 아니면 새로운 데이터 저장
                page_info = data["page_info"]
                page_number = page_info.get("pageNumber", 0)
                response_data = json.dumps(data)
                sanction_id = data["sanction_id"]
                sanction_subject = data.get("sanction_subject", "") 
        
                insert_query = """
                INSERT INTO Table_3st_API (page_number, sanction_id, sanction_subject, response_data, unique_key_hash)
                VALUES (%s, %s, %s, %s, %s)
                """
                try:
                    cursor.execute(insert_query, (page_number, sanction_id, sanction_subject, response_data, unique_key_hash))
                    self.connection.commit() 
                    print(f"[DEBUG] 데이터 저장 성공: {unique_key_hash}")
                except Error as e:
                    print(f"[ERROR] 데이터 저장 중 오류 발생: {e}")
                    self.connection.rollback()
    
        print("[DEBUG] save_responses_to_database 함수 종료")

    # 현재는 용도가 별도로 없는 부분 (동시 파일 저장을 위해 구성했으나, 불용 예정)
    def save_first_second_api_responses_to_database(self, file_name, table_name):
        try:
            with open(file_name, 'r', encoding='utf-8') as file:
                data = json.load(file)
                response_data = json.dumps(data)

                with self.connection.cursor() as cursor:
                    query = f"""
                    INSERT INTO {table_name} (response_data)
                    VALUES (%s)
                    ON DUPLICATE KEY UPDATE
                    response_data = VALUES(response_data)
                    """
                    cursor.execute(query, (response_data,))
                    self.connection.commit()
                    print(f"[DEBUG] {file_name} 데이터 저장 성공")
        except Error as e:
            print(f"[ERROR] {file_name} 데이터 저장 중 오류 발생: {e}")
            self.connection.rollback()
        except FileNotFoundError:
            print(f"[ERROR] 파일 {file_name}을 찾을 수 없습니다.")

    def ensure_database_connection(self):
        if not self.connection.is_connected():
            print("[INFO] 데이터베이스 재연결 시도 중...")
            self.connection.reconnect(attempts=3, delay=5)

    def load_existing_hashes(self):
        self.ensure_database_connection() 
        self.cursor = self.connection.cursor() 
        print("[DEBUG] load_existing_hashes 함수 시작")
        self.existing_hashes_map.clear()
        try:
            query = "SELECT unique_key_hash, sanction_subject, sanction_id FROM Table_3st_API"
            self.cursor.execute(query)
            results = self.cursor.fetchall()
            for hash_value, subject, id in results:
                if subject is not None and id is not None:
                    self.existing_hashes_map[hash_value] = f"{subject}-{id}"
    
            # 기술 통계량 추가 (여기서 출력을 줄임)
            total_hashes = len(self.existing_hashes_map)
            print(f"[INFO] 총 해시 값 건수: {total_hashes}")
        except Error as e:
            print(f"[ERROR] 데이터 불러오기 중 오류 발생: {e}")
        finally:
            self.cursor.close() 
        print("[DEBUG] load_existing_hashes 함수 종료")
    
    def close(self):
        self.driver.quit()
        self.cursor.close()
        self.connection.close()
        print("[DEBUG] 데이터베이스 연결 닫힘")

    def check_data_in_database(self):
        tables = ['Table_1st_API', 'Table_2st_API', 'Table_3st_API']
        data_objects = {}
    
        for table in tables:
            data_objects[table] = []
            try:
                with self.connection.cursor() as cursor:  # self.connection 사용
                    query = f"SELECT * FROM {table} LIMIT 5"  # 각 테이블에서 상위 5개 데이터 조회
                    cursor.execute(query)
                    results = cursor.fetchall()
                    data_objects[table].extend(results)
            except mysql.connector.Error as e:
                print(f"[ERROR] 데이터 확인 중 오류 발생 ({table}): {e}")
    
        return data_objects

# 메인 실행 코드
if __name__ == "__main__":
    api_manager = APIManager()
    api_manager.login('goguma@krx.co.kr', 'wkrwjs12!@')

    request_input = input("실행할 API 요청을 선택하세요 (1: 첫 번째, 2: 두 번째, 3: 세 번째, 예: 1,2,3): ")
    selected_requests = request_input.split(',')

    # 첫 번째 API 요청의 성공 여부를 판단하기 위한 변수
    first_api_success = False

    if '1' in selected_requests:
        first_api_success = api_manager.send_first_api_request("100562")

    if '2' in selected_requests:
        api_manager.send_second_api_request("100562")

    if '3' in selected_requests:
        # 3번 요청 전에 total 및 totalPage가 설정되었는지 확인
        if not hasattr(api_manager, 'total') or not hasattr(api_manager, 'totalPage'):
            print("[INFO] 필요한 페이지 정보가 설정되지 않았습니다. 첫 번째 API 요청을 실행하여 페이지 정보를 설정합니다.")
            first_api_success = api_manager.send_first_api_request("100562")  # 'reference_id' 인자 제공

        if first_api_success:
#            for page_number in tqdm(range(1, api_manager.totalPage + 1), desc="Processing"):
            for page_number in tqdm(range(1, api_manager.totalPage + 1), desc="Processing"):
                api_manager.send_third_api_request(page_number)

        else:
            print("[ERROR] 페이지 정보를 불러오는 데 실패했습니다. 프로그램을 종료합니다.")
            sys.exit(1)

    api_manager.save_responses_to_database()

    # 저장된 데이터 확인 및 객체에 저장
    database_data = api_manager.check_data_in_database()

    # 객체에 저장된 데이터 출력
    for table, data in database_data.items():
        print(f"\n[INFO] 데이터 확인 - {table}:")
        for row in data:
            print(row)

    api_manager.close()
    print("All tasks completed.")
# %% - temp : Extract
import mysql.connector
from mysql.connector import Error

def get_all_nested_data_from_db():
    try:
        connection = mysql.connector.connect(
            host='localhost',
            database='first_api_tables',
            user='root',
            password='wkrwjs12!@'
        )

        cursor = connection.cursor()

        query = """
        SELECT
            JSON_EXTRACT(response_data, '$.contents.files.originalFileName'),
            JSON_EXTRACT(response_data, '$.contents.ordersSectionCode'),
            JSON_EXTRACT(response_data, '$.contents.files.fileMapping.fileSubject'),
            JSON_EXTRACT(response_data, '$.contents.krxFiles.fileMapping.fileId'),
            JSON_EXTRACT(response_data, '$.contents.createDateTime'),
            JSON_EXTRACT(response_data, '$.contents.files.fileUUID'),
            JSON_EXTRACT(response_data, '$.contents.sanctionId'),
            JSON_EXTRACT(response_data, '$.contents.createEnglishFullName'),
            JSON_EXTRACT(response_data, '$.contents.sanctionSubject'),
            JSON_EXTRACT(response_data, '$.contents.ordersApprovalMappings.companyName'),
            JSON_EXTRACT(response_data, '$.contents.cancelFiles.fileMapping.realmGroupCode'),
            JSON_EXTRACT(response_data, '$.contents.krxSanctionMemo'),
            JSON_EXTRACT(response_data, '$.contents.files.fileMapping.fileOrder'),
            JSON_EXTRACT(response_data, '$.contents.cancelFiles.fileMapping.referenceId'),
            JSON_EXTRACT(response_data, '$.contents.ordersSectionName'),
            JSON_EXTRACT(response_data, '$.contents.files.fileExtension'),
            JSON_EXTRACT(response_data, '$.contents.cancelFiles.fileSize'),
            JSON_EXTRACT(response_data, '$.contents.cancelFiles.fileMapping.fileDescription'),
            JSON_EXTRACT(response_data, '$.contents.cancelFiles.fileExtension'),
            JSON_EXTRACT(response_data, '$.contents.krxFiles'),
            JSON_EXTRACT(response_data, '$.contents.files.fileMapping.realmGroupCode'),
            JSON_EXTRACT(response_data, '$.contents.cancelFiles.fileMapping.fileOrder'),
            JSON_EXTRACT(response_data, '$.contents.files.fileMapping.fileMappingId'),
            JSON_EXTRACT(response_data, '$.contents.cancelFiles.fileId'),
            JSON_EXTRACT(response_data, '$.contents.createKoreanFullName'),
            JSON_EXTRACT(response_data, '$.contents.ordersApprovalMappings.companyId'),
            JSON_EXTRACT(response_data, '$.contents.approvalLines.sanctionerTypeCode'),
            JSON_EXTRACT(response_data, '$.contents.ordersApprovalMappings.ordersId'),
            JSON_EXTRACT(response_data, '$.contents.relateSanctionSubject'),
            JSON_EXTRACT(response_data, '$.contents.sanctionTypeCode'),
            JSON_EXTRACT(response_data, '$.contents.files'),
            JSON_EXTRACT(response_data, '$.contents.cancelFiles.fileMapping.fileTypeCode'),
            JSON_EXTRACT(response_data, '$.contents.cancelFiles.fileSecurityYn'),
            JSON_EXTRACT(response_data, '$.contents.files.fileSize'),
            JSON_EXTRACT(response_data, '$.contents.approvalLines.englishFullName'),
            JSON_EXTRACT(response_data, '$.contents.cancelFiles.fileUUID'),
            JSON_EXTRACT(response_data, '$.contents.ordersApprovalMappings.sanctionId'),
            JSON_EXTRACT(response_data, '$.contents.krxFiles.fileMapping.realmGroupCode'),
            JSON_EXTRACT(response_data, '$.contents.krxFiles.fileMapping.fileSubject'),
            JSON_EXTRACT(response_data, '$.contents.krxSanctionContents'),
            JSON_EXTRACT(response_data, '$.contents.files.fileMapping.referenceId'),
            JSON_EXTRACT(response_data, '$.contents.krxFiles.fileCloudPath'),
            JSON_EXTRACT(response_data, '$.contents.sanctionMemo'),
            JSON_EXTRACT(response_data, '$.contents.krxFiles.fileUUID'),
            JSON_EXTRACT(response_data, '$.contents.cancelFiles.fileCloudPath'),
            JSON_EXTRACT(response_data, '$.contents.cancelFiles'),
            JSON_EXTRACT(response_data, '$.contents.files.fileSecurityYn'),
            JSON_EXTRACT(response_data, '$.contents.approvalLines.sanctionOpinion'),
            JSON_EXTRACT(response_data, '$.page_info.total'),
            JSON_EXTRACT(response_data, '$.contents.approvalLines.managerId'),
            JSON_EXTRACT(response_data, '$.contents.approvalLines.sanctionStatusCode'),
            JSON_EXTRACT(response_data, '$.contents.approvalLines'),
            JSON_EXTRACT(response_data, '$.unique_key_hash'),
            JSON_EXTRACT(response_data, '$.contents.files.fileMapping'),
            JSON_EXTRACT(response_data, '$.contents.krxFiles.fileMapping.fileTypeCode'),
            JSON_EXTRACT(response_data, '$.contents.relateSanctionId'),
            JSON_EXTRACT(response_data, '$.contents.approvalLines.sanctionLineId'),
            JSON_EXTRACT(response_data, '$.page_info'),
            JSON_EXTRACT(response_data, '$.contents.sanctionStatusCode'),
            JSON_EXTRACT(response_data, '$.contents.cancelFiles.fileMapping.realmGroupName'),
            JSON_EXTRACT(response_data, '$.page_info.pageNumber'),
            JSON_EXTRACT(response_data, '$.contents.approvalLines.koreanFullName'),
            JSON_EXTRACT(response_data, '$.contents.approvalLines.officialPositionName'),
            JSON_EXTRACT(response_data, '$.contents.sanctionDocumentNumber'),
            JSON_EXTRACT(response_data, '$.contents.krxFiles.fileMapping.fileMappingId'),
            JSON_EXTRACT(response_data, '$.contents.sanctionReason'),
            JSON_EXTRACT(response_data, '$.contents.krxFiles.fileExtension'),
            JSON_EXTRACT(response_data, '$.contents.ordersApprovalMappings.ordersSanctionId'),
            JSON_EXTRACT(response_data, '$.contents.cancelFiles.fileMapping.fileMappingId'),
            JSON_EXTRACT(response_data, '$.contents.krxFiles.fileSize'),
            JSON_EXTRACT(response_data, '$.contents.sanctionContents'),
            JSON_EXTRACT(response_data, '$.contents.files.fileMapping.realmGroupName'),
            JSON_EXTRACT(response_data, '$.contents.cancelFiles.fileMapping.fileSubject'),
            JSON_EXTRACT(response_data, '$.contents.krxFiles.fileMapping'),
            JSON_EXTRACT(response_data, '$.contents.files.fileId'),
            JSON_EXTRACT(response_data, '$.contents.sanctionStatusName'),
            JSON_EXTRACT(response_data, '$.contents.approvalLines.sanctionStatusName'),
            JSON_EXTRACT(response_data, '$.contents.krxFiles.fileId'),
            JSON_EXTRACT(response_data, '$.contents.approvalLines.absenceReasonCode'),
            JSON_EXTRACT(response_data, '$.contents.ordersApprovalMappings.ordersTypeName'),
            JSON_EXTRACT(response_data, '$.contents.krxFiles.fileSecurityYn'),
            JSON_EXTRACT(response_data, '$.contents.sanctionTypeName'),
            JSON_EXTRACT(response_data, '$.contents.cancelFiles.originalFileName'),
            JSON_EXTRACT(response_data, '$.contents.files.fileMapping.fileTypeCode'),
            JSON_EXTRACT(response_data, '$.contents.krxSanctionSubject'),
            JSON_EXTRACT(response_data, '$.contents.krxFiles.originalFileName'),
            JSON_EXTRACT(response_data, '$.contents.cancelFiles.fileMapping.fileId'),
            JSON_EXTRACT(response_data, '$.contents.files.fileMapping.fileId'),
            JSON_EXTRACT(response_data, '$.contents.ordersApprovalMappings.ordersSectionCode'),
            JSON_EXTRACT(response_data, '$.contents.krxFiles.fileMapping.realmGroupName'),
            JSON_EXTRACT(response_data, '$.contents.approvalLines.absenceReasonDescription'),
            JSON_EXTRACT(response_data, '$.contents.approvalLines.userId'),
            JSON_EXTRACT(response_data, '$.contents.ordersPauseRequestApprovalMappings'),
            JSON_EXTRACT(response_data, '$.contents.files.fileCloudPath'),
            JSON_EXTRACT(response_data, '$.contents.files.fileMapping.fileDescription'),
            JSON_EXTRACT(response_data, '$.contents.krxFiles.fileMapping.fileDescription'),
            JSON_EXTRACT(response_data, '$.page_info.pageSize'),
            JSON_EXTRACT(response_data, '$.contents.approvalLines.sanctionOrder'),
            JSON_EXTRACT(response_data, '$.page_info.totalPage'),
            JSON_EXTRACT(response_data, '$.contents.ordersApprovalMappings'),
            JSON_EXTRACT(response_data, '$.sanction_subject'),
            JSON_EXTRACT(response_data, '$.contents.approvalLines.absenceYn'),
            JSON_EXTRACT(response_data, '$.contents.krxFiles.fileMapping.referenceId'),
            JSON_EXTRACT(response_data, '$.contents.cancelFiles.fileMapping'),
            JSON_EXTRACT(response_data, '$.contents.updateDateTime')
        FROM api_responses
        """
        cursor.execute(query)
        rows = cursor.fetchall()
        for row in rows:
            print(row)

        return rows  # rows 반환

    except Error as e:
        print(f"Error: {e}")
        return None  # 오류 발생 시 None 반환
    finally:
        if connection.is_connected():
            cursor.close()
            connection.close()

# 함수 호출 및 결과 저장
rows = get_all_nested_data_from_db()
