# -*- coding: utf-8 -*-
"""
Created on Fri Jan 19 08:03:34 2024

@author: 221016
"""

# background_tasks.py
from Koscom_dataservice import APIManager
import asyncio

async def background_data_collection():
    try:
        api_manager = APIManager()
        api_manager.login('goguma@krx.co.kr', 'wkrwjs12!@')
        api_manager.send_first_api_request()
        api_manager.send_second_api_request()
        for page_number in range(1, 3):
            api_manager.send_third_api_request(page_number)
        api_manager.save_responses_to_database()
    except Exception as e:
        print(f"[ERROR] 데이터 수집 중 오류 발생: {e}")
        api_manager.close()

if __name__ == "__main__":
    asyncio.run(background_data_collection())


