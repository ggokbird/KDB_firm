# %% 240116 Koscom_dataservice With FastAPI
"""
# http://127.0.0.1:8000/redoc
# http://127.0.0.1:8000/docs 
"""
    
# %% 동적 생성
# (1) Koscom_dataservice 를 통해 KMDS 사이트의 내용을 전문화하여 SQL 에 저장
# (2) SQL 기반으로 API 구축하여, 원하는 정보만 호출할 수 있게 변경 
# 유의미한 정보 리스트업
# ○ 1st API 
# ○ 2st API 
# ○ 3st API
# - Saction Status, Saction Opinion, File UUID, ReferenceID(★) 등 
# %% 240116 Koscom_dataservice With FastAPI
"""
# http://127.0.0.1:8000/redoc
# http://127.0.0.1:8000/docs 
# SET RUN_DATA_COLLECTION=true
# uvicorn main:app --reload
"""    
# %% Unit test + SQL + Fast API + contents involved + Example added
# collect_and_save_endpoint_data 결과를 보기 위해 코드 수정 (`24.02.06.)
# `24.02.07 Example Logic 추가 
# `24.02.28. 아래 코드에서 로컬에서 example 결과를 가져오는 부분은 아예 필요 없지 않나? - No (FastAPI 는 자동 예제 생성이 안됨)  
import json
import requests
from fastapi import FastAPI, HTTPException
import mysql.connector
from mysql.connector import Error
import uvicorn
import asyncio
import nest_asyncio

app = FastAPI()

# 데이터베이스 설정
DATABASE_CONFIG = {
    'host': 'localhost',
    'database': 'first_api_tables',
    'user': 'root',
    'password': 'wkrwjs12!@'
}

# 엔드포인트 목록을 저장할 변수
created_endpoints = []

# 데이터베이스 연결 함수
def get_db_connection():
    try:
        return mysql.connector.connect(**DATABASE_CONFIG)
    except Error as e:
        print(f"Error connecting to the database: {e}")
        return None

# JSON 경로 추출 함수
def get_paths_from_json(json_obj: dict, parent_key: str = '') -> list:
    paths = []
    for k, v in json_obj.items():
        full_key = f"{parent_key}.{k}" if parent_key else k
        if isinstance(v, dict):
            paths.extend(get_paths_from_json(v, full_key))
        elif isinstance(v, list):
            for i, item in enumerate(v):
                if isinstance(item, dict):
                    paths.extend(get_paths_from_json(item, f"{full_key}[{i}]"))
                else:
                    paths.append(f"{full_key}[{i}]")
        else:
            paths.append(full_key)
    return paths

# 특정 JSON 경로의 데이터를 조회하는 함수
def fetch_data_for_path(json_path: str):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        query = f"SELECT JSON_UNQUOTE(JSON_EXTRACT(response_data, '$.{json_path}')) FROM table_3st_api WHERE JSON_EXTRACT(response_data, '$.{json_path}') IS NOT NULL LIMIT 1"
        cursor.execute(query)
        result = cursor.fetchone()
        return result[0] if result else None
    except Error as e:
        print(f"Database error for path '{json_path}': {e}")
        return None
    finally:
        if conn and conn.is_connected():
            cursor.close()
            conn.close()

# 엔드포인트 생성 함수
def create_endpoints_from_json_data(json_data: dict, examples: dict):
    paths = get_paths_from_json(json_data)
    for path in paths:
        endpoint_name = path.replace('.', '_').replace('[', '_').replace(']', '')
        if endpoint_name not in created_endpoints:
            created_endpoints.append(endpoint_name)  # 엔드포인트 목록에 추가

            @app.get(f"/{endpoint_name}", summary=f"Get data for {path}", description=f"Retrieves data from the path {path} in the database.", responses={200: {"content": {"application/json": {"example": examples.get(endpoint_name, {})}}}})
            def generic_endpoint(_path=path): # 클로저를 사용하여 각 엔드포인트에 대한 올바른 경로를 유지
                data = fetch_data_for_path(_path)
                if data is None:
                    raise HTTPException(status_code=404, detail="Data not found")
                return {_path: data}  # 여기에서 _path를 key로 사용

# 데이터를 수집하고 저장하는 비동기 함수
async def collect_and_save_endpoint_data(base_url):
    data_examples = {}
    for endpoint in created_endpoints:
        response = await asyncio.get_event_loop().run_in_executor(None, requests.get, f"{base_url}/{endpoint}")
        if response.status_code == 200:
            data_examples[endpoint] = response.json()
    with open('api_data_examples.json', 'w') as file:
        json.dump(data_examples, file, indent=4)

# 예제 데이터 파일 로딩
# 예제 파일을 로딩하는 이유는 로컬에 저장된 api response 결과를 참고하여, endpoint 경로를 만들기 위함
def load_example_data():
    try:
        with open('api_data_examples.json', 'r') as file:
            return json.load(file)
    except FileNotFoundError:
        print("Example data file not found. Generating without examples.")
        return {}

# 서버 실행과 데이터 수집을 함께 처리하는 비동기 함수
async def run_server_and_collect_data():
    config = uvicorn.Config(app=app, host="0.0.0.0", port=8000, loop="asyncio")
    server = uvicorn.Server(config)
    server_task = asyncio.create_task(server.serve())
    
    await asyncio.sleep(1)  # 서버가 시작될 때까지 기다림

    await collect_and_save_endpoint_data("http://localhost:8000")
    
    await server_task

# 메인 함수
def main():
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT response_data FROM table_3st_api LIMIT 1")
        row = cursor.fetchone()
        if row:
            json_data = json.loads(row[0])
            examples = load_example_data()  # 예제 데이터 로딩
            create_endpoints_from_json_data(json_data, examples)
            print("Endpoints created.")
        else:
            print("No data found.")
    except Error as e:
        print(f"Database error: {e}")
    finally:
        if conn and conn.is_connected():
            cursor.close()
            conn.close()
            print("Database connection closed.")

if __name__ == "__main__":
    main()
    nest_asyncio.apply()
    asyncio.run(run_server_and_collect_data())

# %% EndPoint 에 Limit Parameter 추가 
import json
import requests
from fastapi import FastAPI, HTTPException, Query
import mysql.connector
from mysql.connector import Error
import uvicorn
import asyncio
import nest_asyncio

app = FastAPI()

# 데이터베이스 설정
DATABASE_CONFIG = {
    'host': 'localhost',
    'database': 'first_api_tables',
    'user': 'root',
    'password': 'wkrwjs12!@'
}

# 엔드포인트 목록을 저장할 변수
created_endpoints = []

# 데이터베이스 연결 함수
def get_db_connection():
    try:
        return mysql.connector.connect(**DATABASE_CONFIG)
    except Error as e:
        print(f"Error connecting to the database: {e}")
        return None

# JSON 경로 추출 함수
def get_paths_from_json(json_obj: dict, parent_key: str = '') -> list:
    paths = []
    for k, v in json_obj.items():
        full_key = f"{parent_key}.{k}" if parent_key else k
        if isinstance(v, dict):
            paths.extend(get_paths_from_json(v, full_key))
        elif isinstance(v, list):
            for i, item in enumerate(v):
                if isinstance(item, dict):
                    paths.extend(get_paths_from_json(item, f"{full_key}[{i}]"))
                else:
                    paths.append(f"{full_key}[{i}]")
        else:
            paths.append(full_key)
    return paths

# 특정 JSON 경로의 데이터를 조회하는 함수, limit 매개변수 추가
def fetch_data_for_path(json_path: str, limit: int = 1):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        query = f"SELECT JSON_UNQUOTE(JSON_EXTRACT(response_data, '$.{json_path}')) FROM table_3st_api WHERE JSON_EXTRACT(response_data, '$.{json_path}') IS NOT NULL LIMIT {limit}"
        cursor.execute(query)
        results = cursor.fetchall()
        return [result[0] for result in results]
    except Error as e:
        print(f"Database error for path '{json_path}': {e}")
        return None
    finally:
        if conn:
            conn.close()

# 엔드포인트 생성 함수, 엔드포인트에 limit 쿼리 매개변수 추가
def create_endpoints_from_json_data(json_data: dict, examples: dict):
    paths = get_paths_from_json(json_data)
    for path in paths:
        endpoint_name = path.replace('.', '_').replace('[', '_').replace(']', '')
        if endpoint_name not in created_endpoints:
            created_endpoints.append(endpoint_name)

            @app.get(f"/{endpoint_name}", summary=f"Get data for {path}",
                     description=f"Retrieves data from the path {path} in the database.",
                     responses={200: {"content": {"application/json": {"example": examples.get(endpoint_name, {})}}}})
            def generic_endpoint(_path: str = path, limit: int = Query(default=1, ge=1)):
                data = fetch_data_for_path(_path, limit)
                if not data:
                    raise HTTPException(status_code=404, detail="Data not found")
                return {path: data}

# 예제 데이터를 수집하고 저장하는 함수
async def collect_and_save_endpoint_data(base_url):
    data_examples = {}
    for endpoint in created_endpoints:
        response = await asyncio.get_event_loop().run_in_executor(None, requests.get, f"{base_url}/{endpoint}")
        if response.status_code == 200:
            data_examples[endpoint] = response.json()
    with open('api_data_examples.json', 'w') as file:
        json.dump(data_examples, file, indent=4)

# 모든 엔드포인트 결과를 수집하여 저장하는 함수
async def collect_and_save_full_endpoint_data(base_url, limit=10):
    data_full = {}
    for endpoint in created_endpoints:
        response = await asyncio.get_event_loop().run_in_executor(None, requests.get, f"{base_url}/{endpoint}?limit={limit}")
        if response.status_code == 200:
            data_full[endpoint] = response.json()
    with open('api_data_full.json', 'w') as file:
        json.dump(data_full, file, indent=4)

# 서버 실행과 데이터 수집을 함께 처리하는 비동기 함수
async def run_server_and_collect_data():
    config = uvicorn.Config(app=app, host="0.0.0.0", port=8000, loop="asyncio")
    server = uvicorn.Server(config)
    server_task = asyncio.create_task(server.serve())
    
    await asyncio.sleep(1)  # 서버가 시작될 때까지 기다림

    await collect_and_save_endpoint_data("http://localhost:8000")  # 예제 데이터 수집
    await collect_and_save_full_endpoint_data("http://localhost:8000", limit=10)  # 전체 데이터 수집
    
    await server_task

# 메인 함수
def main():
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT response_data FROM table_3st_api LIMIT 1")
        row = cursor.fetchone()
        if row:
            json_data = json.loads(row[0])
            examples = load_example_data()  # 예제 데이터 로딩
            create_endpoints_from_json_data(json_data, examples)
            print("Endpoints created.")
        else:
            print("No data found.")
    except Error as e:
        print(f"Database error: {e}")
    finally:
        if conn and conn.is_connected():
            cursor.close()
            conn.close()

if __name__ == "__main__":
    main()
    nest_asyncio.apply()
    asyncio.run(run_server_and_collect_data())

# %% + Shp File 
from fastapi import FastAPI
from fastapi.responses import HTMLResponse
import geopandas as gpd
from bokeh.embed import file_html
from bokeh.resources import CDN
from bokeh.models import GeoJSONDataSource, LinearColorMapper, ColorBar
from bokeh.plotting import figure
import random

app = FastAPI()

@app.get("/visualize_map", response_class=HTMLResponse)
async def visualize_map():
    # 지정된 .shp 파일 경로
    shapefile_path = r'D:\KRX\Interactive-Choropleth-Map-Using-Python-master\Interactive-Choropleth-Map-Using-Python-master\bokeh-app\data\countries_110m\ne_110m_admin_0_countries.shp'
    gdf = gpd.read_file(shapefile_path)
    
    # 임의의 데이터 생성
    gdf['random_value'] = [random.randint(1, 100) for _ in range(len(gdf))]
    
    geosource = GeoJSONDataSource(geojson=gdf.to_json())
    color_mapper = LinearColorMapper(palette="Viridis256", low=min(gdf['random_value']), high=max(gdf['random_value']))
    
    # 가로로 더 크게 그려지도록 width 값을 조정
    p = figure(title="World Map with Random Values", width=1200, height=600)
    p.patches('xs', 'ys', source=geosource,
              fill_color={'field': 'random_value', 'transform': color_mapper},
              line_color='black', line_width=0.25)
    color_bar = ColorBar(color_mapper=color_mapper, label_standoff=12, location=(0,0))
    p.add_layout(color_bar, 'right')

    # HTML 페이지로 변환
    html = file_html(p, CDN, "World Map with Random Values")

    return html

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)


# %% MVP code
# 추후 해야할 코드 업무 : 발급된 Geo API Key 로 상기 endpoint 를 통해 호출한 주소 정보 Mapping
import geopandas as gpd
from bokeh.plotting import figure, output_file, show
from bokeh.models import GeoJSONDataSource, LinearColorMapper, ColorBar
import random

# 지정된 .shp 파일 경로
shapefile_path = r'D:\KRX\Interactive-Choropleth-Map-Using-Python-master\Interactive-Choropleth-Map-Using-Python-master\bokeh-app\data\countries_110m\ne_110m_admin_0_countries.shp'
gdf = gpd.read_file(shapefile_path)

# 임의의 데이터 생성 및 추가
gdf['random_value'] = [random.randint(1, 100) for _ in range(len(gdf))]

# GeoJSONDataSource 생성
geosource = GeoJSONDataSource(geojson=gdf.to_json())

# Color mapper 설정
color_mapper = LinearColorMapper(palette="Viridis256", low=min(gdf['random_value']), high=max(gdf['random_value']))

# Bokeh Figure 설정
p = figure(title="World Map with Random Values")
p.patches('xs', 'ys', source=geosource,
          fill_color={'field': 'random_value', 'transform': color_mapper},
          line_color='black', line_width=0.25)

# Color Bar 추가
color_bar = ColorBar(color_mapper=color_mapper, label_standoff=12, location=(0,0))
p.add_layout(color_bar, 'right')

# 결과를 HTML 파일로 저장 및 보여주기
output_file("world_map_random_values.html")
show(p)
