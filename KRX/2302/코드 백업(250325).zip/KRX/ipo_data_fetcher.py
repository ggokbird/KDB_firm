# -*- coding: utf-8 -*-
"""
Created on Fri Feb  2 10:22:57 2024

@author: 221016
"""

# ipo_data_fetcher.py
import requests
from bs4 import BeautifulSoup
import pandas as pd
import numpy as np
"""
def get_company_list(pages=1):
    base_url = "http://www.38.co.kr/html/fund/index.htm?o=nw&page={}"
    company_names = []

    for page in range(1, pages + 1):
        full_url = base_url.format(page)
        response = requests.get(full_url, headers={'User-Agent': 'Mozilla/5.0'})
        soup = BeautifulSoup(response.text, 'html.parser')
        
        table = soup.find('table', {'summary': '신규상장종목'})
        if not table:
            print(f"No IPO data found on page {page}")
            continue
        
        rows = table.find_all('tr')[2:]
        for row in rows:
            cols = row.find_all('td')
            if not cols:
                continue
            company_name = cols[0].get_text(strip=True)
            if company_name:
                company_names.append(company_name)

    return company_names
"""

def fetch_ipo_data_from_38(pages=1):
    """Fetch IPO listing data from a specified source."""
    total_data = []
    for p in range(1, pages + 1):
        fullUrl = f'http://www.38.co.kr/html/fund/index.htm?o=nw&page={p}'
        response = requests.get(fullUrl, headers={'User-Agent': 'Mozilla/5.0'})
        if response.status_code != 200:
            print(f"Failed to fetch data for page {p}")
            continue

        html = response.text
        soup = BeautifulSoup(html, 'html.parser')  # lxml을 html.parser로 변경
        data_table = soup.find('table', {'summary': '신규상장종목'})
        if not data_table:
            print("No data found on page", p)
            continue
        data_rows = data_table.find_all('tr')[2:]
        total_data += data_rows
    
    return process_ipo_data(total_data)

def process_ipo_data(data_rows):
    """Process the raw HTML rows into a structured pandas DataFrame."""
    processed_data = []

    for row in data_rows:
        cols = row.find_all('td')
        if not cols or len(cols) < 9:
            continue

        company = cols[0].text.strip().replace('(유가)', '').strip()  # 이전 방식에 맞춰 텍스트 추출 및 정리
        list_date = cols[1].text.strip()
        price = cols[4].text.strip().replace(',', '')
        open_price = cols[6].text.strip().replace(',', '')
        close_price = cols[8].text.strip().replace(',', '')

        processed_data.append({
            'company': company,
            'list_date': list_date,
            'price': price if price else np.nan,
            'open_price': open_price if open_price else np.nan,
            'close_price': close_price if close_price else np.nan
        })

    df = pd.DataFrame(processed_data)
    df[['price', 'open_price', 'close_price']] = df[['price', 'open_price', 'close_price']].apply(pd.to_numeric, errors='coerce')
    df['return_open'] = (df['open_price'] / df['price']) - 1
    df['return_close'] = (df['close_price'] / df['price']) - 1
    df.replace([np.inf, -np.inf], np.nan, inplace=True)  # Replace inf values if any

    return df

def get_company_list(pages=1):
    """Return a list of companies from the IPO data."""
    ipo_data = fetch_ipo_data_from_38(pages)
    company_list = ipo_data['company'].tolist()
    return company_list

# Example usage
if __name__ == '__main__':
    companies = get_company_list(pages=1)
    print("Companies from IPO data:")
    for company in companies:
        print(company)

# %% 
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
import time
import requests
from bs4 import BeautifulSoup
import os

# SSL 경고 무시
requests.packages.urllib3.disable_warnings()

# 기본 URL 설정
base_url = "https://www.38.co.kr/html/fund/index.htm?o=nw&page=10"

# 상대 경로 URL을 추출하는 함수
def fetch_relative_urls(url):
    # 요청 보내기
    response = requests.get(url, verify=False) # SSL 경고를 무시하기 위해 verify=False 추가
    # BeautifulSoup 객체 생성
    soup = BeautifulSoup(response.text, 'html.parser')
    # 모든 상대 경로 URL 찾기
    relative_urls = [a['href'] for a in soup.find_all('a', href=True) if a['href'].startswith('./?o=v&no=')]
    return relative_urls

# 상대 경로 URL 리스트 동적 추출
relative_urls = fetch_relative_urls(base_url)

# ChromeDriver 경로 설정 (이전에 주어진 경로 사용)
chrome_driver_path = os.path.join('D:\\KRX', 'chromedriver.exe')

service = Service(executable_path=chrome_driver_path)

# WebDriver 설정 및 웹페이지 열기
driver = webdriver.Chrome(service=service)

# 모든 상대 경로 URL에 대해 순회
for relative_url in relative_urls:
    full_url = "https://www.38.co.kr" + relative_url[2:]  # 상대 경로를 전체 URL로 변환
    driver.get(full_url)  # 전체 URL로 이동
    time.sleep(2)  # 페이지 로드를 위해 잠시 대기

    # 여기에서 페이지 내에서 수행하고자 하는 특정 작업을 수행할 수 있습니다.
    print("현재 페이지 URL:", driver.current_url)

# 작업 완료 후 드라이버 종료
driver.quit()
