# -*- coding: utf-8 -*-
"""
Created on Tue Jan 30 22:43:14 2024

@author: 221016
"""

# %% Dir + corp code 
import os
import zipfile
import requests
import pandas as pd
import xml.etree.ElementTree as ET
import time
import chardet

# OpenDART API 설정 및 경로 설정
API_KEY = "6ad4c3e10d41586b038dbddf496aa1d4af319152"
target_list = ["삼성전자", "회사명2", "회사명3"]
filePath = 'C:\\Users\\221016\\Desktop\\KRX'  # Windows 경로 형식에 맞게 수정
chrome_version = "121.0.6167.85"
log_file_path = os.path.join(filePath, "download_log.txt")  # 로그 파일 경로

def createAndSetWorkingDir(directory):
    """
    작업 디렉토리를 설정합니다.
    지정된 디렉토리가 없으면 새로 생성합니다.
    """
    if not os.path.exists(directory):
        os.makedirs(directory)
    os.chdir(directory)
    print(f"Current working directory is now set to: {os.getcwd()}")

createAndSetWorkingDir(filePath)

def download_chromedriver(chrome_version):
    """
    지정된 버전의 ChromeDriver를 다운로드하고 압축을 해제합니다.
    이 ChromeDriver는 Selenium 자동화에 사용됩니다.
    """
    zip_path = os.path.join(filePath, "chromedriver.zip")
    url = f"https://edgedl.me.gvt1.com/edgedl/chrome/chrome-for-testing/{chrome_version}/win32/chromedriver-win32.zip"
    response = requests.get(url, stream=True)
    response.raise_for_status()
    with open(zip_path, "wb") as f:
        for chunk in response.iter_content(chunk_size=8192):
            f.write(chunk)
    with zipfile.ZipFile(zip_path, 'r') as zip_ref:
        zip_ref.extractall(filePath)

download_chromedriver(chrome_version)

def download_corp_code(api_key):
    """
    OpenDART API를 통해 corpCode.xml 파일(회사 코드와 정보 포함)을 다운로드합니다.
    파일은 zip 형식으로 제공되며, 압축을 해제하여 사용합니다.
    """
    url = f"https://opendart.fss.or.kr/api/corpCode.xml?crtfc_key={api_key}"
    response = requests.get(url)
    zip_file_path = os.path.join(filePath, "corpCode.zip")
    xml_file_path = os.path.join(filePath, "corpCode.xml")

    with open(log_file_path, 'a', encoding='utf-8') as log_file:
        log_file.write(f"Requesting URL: {url}\n")
        log_file.write(f"Response status code: {response.status_code}\n")

        if response.status_code == 200:
            with open(zip_file_path, 'wb') as f:
                f.write(response.content)
            log_file.write(f"corpCode.zip downloaded to {zip_file_path}.\n")

            with zipfile.ZipFile(zip_file_path, 'r') as zip_ref:
                zip_ref.extractall(filePath)
            log_file.write(f"corpCode.xml extracted to {xml_file_path}.\n")
        else:
            log_file.write(f"Unexpected response: {response.status_code}, {response.text}\n")

def filter_specific_data():
    """
    다운로드한 corpCode.xml 파일에서 특정 회사 목록에 해당하는 데이터를 필터링합니다.
    XML 파일을 파싱하여 필요한 정보를 추출합니다.
    """
    file_path = os.path.join(filePath, "corpCode.xml")
    try:
        with open(file_path, 'rb') as f:
            raw_data = f.read()
            result = chardet.detect(raw_data)
            file_encoding = result['encoding']
        with open(file_path, 'r', encoding=file_encoding) as f:
            content = f.read()
        tree = ET.ElementTree(ET.fromstring(content))
        root = tree.getroot()
    except Exception as e:
        with open(log_file_path, 'a') as log_file:
            log_file.write(f"Failed to parse XML: {e}\n")
        return []

    filtered_data = []
    for child in root:
        corp_name = child.find('corp_name').text
        if corp_name in target_list:
            filtered_data.append({
                'corp_name': corp_name,
                'corp_code': child.find('corp_code').text,
                'stock_code': child.find('stock_code').text if child.find('stock_code') is not None else None
            })
    return filtered_data

def get_data_from_dart(api_key, corp_code, bsns_year, reprt_code):
    """
    OpenDART API를 사용하여 특정 회사의 특정 연도 및 보고서 코드에 해당하는 데이터를 추출합니다.
    JSON 형식의 응답을 받아 필요한 데이터를 추출합니다.
    """
    base_url = "https://opendart.fss.or.kr/api"
    url = f"{base_url}/alotMatter.json?crtfc_key={api_key}&corp_code={corp_code}&bsns_year={bsns_year}&reprt_code={reprt_code}"
    response = requests.get(url)
    if response.status_code == 200:
        return response.json().get('list')
    return None

download_corp_code(API_KEY)
specific_list = filter_specific_data()

all_specific_data = []
for item in specific_list:
    data = get_data_from_dart(API_KEY, item['corp_code'], '2021', '11011')
    if data:
        all_specific_data.extend(data)
    time.sleep(1)

df = pd.DataFrame(all_specific_data)
print(df)

# %% Using SQL
import requests
import zipfile
import io
import os
import pandas as pd
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta
import pymysql
from tqdm import tqdm
import time
from requests.exceptions import SSLError
import mysql.connector

# API 키와 날짜 범위 설정
api_key = '6ad4c3e10d41586b038dbddf496aa1d4af319152'
start_date = datetime.strptime('20230901', '%Y%m%d')
end_date = datetime.strptime('20231016', '%Y%m%d')

# 데이터베이스 연결 및 테이블 생성
def create_database_and_table():
    try:
        connection = mysql.connector.connect(
            host='localhost',
            user='root',
            password='wkrwjs12!@'
        )
        cursor = connection.cursor()
        cursor.execute("CREATE DATABASE IF NOT EXISTS Quant")
        connection.close()

        connection = pymysql.connect(host='localhost', user='root', password='wkrwjs12!@', charset='utf8mb4', db='Quant')
        cursor = connection.cursor()

        # 기존 테이블 삭제 및 새 테이블 생성
        cursor.execute("DROP TABLE IF EXISTS RecentDisclosureList")
        cursor.execute("""
            CREATE TABLE RecentDisclosureList (
                corp_code VARCHAR(255),
                corp_name VARCHAR(255),
                stock_code VARCHAR(255),
                corp_cls VARCHAR(255),
                report_nm VARCHAR(255),
                rcept_no VARCHAR(255),
                flr_nm VARCHAR(255),
                rcept_dt VARCHAR(255),
                rm VARCHAR(255)
            )
        """)

        print("Database 'Quant' and table 'RecentDisclosureList' created or already exists.")
    except Exception as e:
        print("Error while connecting to MySQL", e)

create_database_and_table()

# API 요청 함수
def list_(start_date, end_date):
    url = 'https://opendart.fss.or.kr/api/list.json'
    params = {
        'crtfc_key': api_key,
        'bgn_de': start_date,
        'end_de': end_date,
        'page_no': 1,
        'page_count': 100
    }
    response = requests.get(url, params=params)
    data = response.json()
    if data['status'] != '000':
        raise Exception(data['message'])
    return pd.DataFrame(data['list'])

# 3개월 단위로 API 요청 범위 설정
def date_range(start_date, end_date, delta=timedelta(days=90)):
    current_date = start_date
    while current_date < end_date:
        next_end_date = min(current_date + delta, end_date)
        yield (current_date, next_end_date)
        current_date = next_end_date + timedelta(days=1)

# 데이터베이스에 데이터 삽입
def insert_data_into_db(start_date, end_date):
    conn = pymysql.connect(host='localhost', user='root', password='wkrwjs12!@', charset='utf8mb4', db='Quant')
    cursor = conn.cursor()

    for s_date, e_date in tqdm(date_range(start_date, end_date), desc="Fetching Data"):
        print(f"Fetching data from {s_date.strftime('%Y%m%d')} to {e_date.strftime('%Y%m%d')}")
        data = list_(s_date.strftime('%Y%m%d'), e_date.strftime('%Y%m%d'))

        # 컬럼 이름 및 값을 확인하고 쿼리 준비
        column_names = ', '.join(data.columns)
        values_placeholder = ', '.join(['%s'] * len(data.columns))
        query = f"INSERT INTO RecentDisclosureList ({column_names}) VALUES ({values_placeholder})"

        for _, row in data.iterrows():
            try:
                cursor.execute(query, tuple(row))
            except pymysql.err.InternalError as e:
                print("Internal MySQL Error:", e)
                print("Row causing error:", row)
            except Exception as e:
                print("General Error:", e)
                print("Row causing error:", row)

        conn.commit()
    conn.close()

insert_data_into_db(start_date, end_date)

# 데이터베이스에서 데이터 조회
def retrieve_data_from_db():
    conn = pymysql.connect(host='localhost', user='root', password='wkrwjs12!@', charset='utf8mb4', db='Quant')
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM RecentDisclosureList LIMIT 10")
    rows = cursor.fetchall()
    for row in rows:
        print(row)
    conn.close()

retrieve_data_from_db()

def get_data_summary_from_db():
    conn = pymysql.connect(host='localhost', user='root', password='wkrwjs12!@', charset='utf8mb4', db='Quant')
    cursor = conn.cursor()

    # 전체 데이터 수 확인
    cursor.execute("SELECT COUNT(*) FROM RecentDisclosureList")
    total_rows = cursor.fetchone()[0]
    print(f"Total number of rows in RecentDisclosureList: {total_rows}")

    conn.close()

get_data_summary_from_db()

# %% Using SQL + 필터링 
import requests
import pandas as pd
import pymysql
import xml.etree.ElementTree as ET
import zipfile
from tqdm import tqdm
from datetime import datetime

# OpenDART API 설정 및 경로 설정
API_KEY = "6ad4c3e10d41586b038dbddf496aa1d4af319152"
target_list = ["삼성전자", "LG전자", "SK하이닉스"]  # 예시 기업 리스트
start_date = datetime.strptime('20230101', '%Y%m%d')
end_date = datetime.strptime('20231231', '%Y%m%d')

def create_database_and_table():
    try:
        connection = pymysql.connect(
            host='localhost',
            user='root',
            password='wkrwjs12!@',
            charset='utf8mb4'
        )
        cursor = connection.cursor()
        cursor.execute("CREATE DATABASE IF NOT EXISTS Quant")
        cursor.execute("USE Quant")
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS RecentDisclosureList (
                corp_code VARCHAR(8),
                corp_name VARCHAR(255),
                stock_code VARCHAR(6),
                corp_cls VARCHAR(1),
                report_nm VARCHAR(255),
                rcept_no VARCHAR(14),
                flr_nm VARCHAR(255),
                rcept_dt VARCHAR(8),
                rm VARCHAR(255)
            )
        """)
        connection.close()
        print("Database 'Quant' and table 'RecentDisclosureList' created.")
    except Exception as e:
        print("Error in creating database and table:", e)

def download_corp_code():
    url = f"https://opendart.fss.or.kr/api/corpCode.xml?crtfc_key={API_KEY}"
    response = requests.get(url)
    if response.status_code == 200:
        with open("corpCode.zip", 'wb') as f:
            f.write(response.content)
        with zipfile.ZipFile("corpCode.zip", 'r') as zip_ref:
            zip_ref.extractall()
        return "corpCode.xml"
    return None

def parse_corp_code(target_list):
    tree = ET.ElementTree(file="corpCode.xml")
    root = tree.getroot()
    target_codes = {}
    for corp in root.findall("list"):
        corp_name = corp.find('corp_name').text
        if corp_name in target_list:
            target_codes[corp_name] = corp.find('corp_code').text
    return target_codes

def fetch_data(corp_code, start_date, end_date):
    url = 'https://opendart.fss.or.kr/api/list.json'
    params = {
        'crtfc_key': API_KEY,
        'corp_code': corp_code,
        'bgn_de': start_date,
        'end_de': end_date,
        'page_no': 1,
        'page_count': 100
    }
    response = requests.get(url, params=params)
    if response.status_code == 200:
        return pd.DataFrame(response.json()['list'])
    return pd.DataFrame()

def insert_data_into_db(data):
    conn = pymysql.connect(
        host='localhost',
        user='root',
        password='wkrwjs12!@',
        db='Quant',
        charset='utf8mb4'
    )
    cursor = conn.cursor()
    for _, row in tqdm(data.iterrows(), total=data.shape[0]):
        cursor.execute("""
            INSERT INTO RecentDisclosureList
            (corp_code, corp_name, stock_code, corp_cls, report_nm, rcept_no, flr_nm, rcept_dt, rm)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
        """, tuple(row))
    conn.commit()
    conn.close()

def main():
    create_database_and_table()
    if download_corp_code():
        corp_codes = parse_corp_code(target_list)
        summary_results = []
        for corp_name, corp_code in corp_codes.items():
            print(f"Fetching data for {corp_name}...")
            data = fetch_data(corp_code, start_date.strftime('%Y%m%d'), end_date.strftime('%Y%m%d'))
            if not data.empty:
                insert_data_into_db(data)
                print(f"Inserted data for {corp_name}")
                summary_results.append(f"Data fetched and inserted for {corp_name}: {len(data)} records")
            else:
                print(f"No data fetched for {corp_name}")
                summary_results.append(f"No data fetched for {corp_name}")
        
        # Print summary results
        print("\nSummary of actions taken:")
        for result in summary_results:
            print(result)

if __name__ == "__main__":
    main()

# %% Using SQL + 필터링 + 페이지네이션 
import requests
import pandas as pd
import pymysql
import xml.etree.ElementTree as ET
import zipfile
from tqdm import tqdm
from datetime import datetime

# Define your API keys for rotating access
API_KEYS = [
    '6ad4c3e10d41586b038dbddf496aa1d4af319152',
    '775537425d61a8ef4217b424c2884e28234a7f12',
    'dbd07aaf3b70263b57868e6dc45e1ed5e21872fb'
]

# Generator function for API key rotation
def api_key_generator(api_keys):
    while True:
        for key in api_keys:
            yield key

key_gen = api_key_generator(API_KEYS)  # Initialize generator
api_key = next(key_gen)  # Fetch the first API key

# Target company list and date range for data fetching
target_list = ["삼성전자", "LG전자", "SK하이닉스"]
start_date = datetime.strptime('20230101', '%Y%m%d')
end_date = datetime.strptime('20231231', '%Y%m%d')

# Ensure the database and table exist
def create_database_and_table():
    connection = pymysql.connect(
        host='localhost',
        user='root',
        password='wkrwjs12!@',
        charset='utf8mb4'
    )
    with connection.cursor() as cursor:
        cursor.execute("CREATE DATABASE IF NOT EXISTS Quant")
        cursor.execute("USE Quant")
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS RecentDisclosureList (
                corp_code VARCHAR(8),
                corp_name VARCHAR(255),
                stock_code VARCHAR(6),
                corp_cls VARCHAR(1),
                report_nm VARCHAR(255),
                rcept_no VARCHAR(14),
                flr_nm VARCHAR(255),
                rcept_dt VARCHAR(8),
                rm VARCHAR(255)
            )
        """)
        print("Database 'Quant' and table 'RecentDisclosureList' created.")
    connection.close()

# Download and parse the corpCode.xml for target companies
def download_and_parse_corp_code(api_key, target_list):
    url = f"https://opendart.fss.or.kr/api/corpCode.xml?crtfc_key={api_key}"
    response = requests.get(url)
    if response.status_code == 200:
        with open("corpCode.zip", 'wb') as f:
            f.write(response.content)
        with zipfile.ZipFile("corpCode.zip", 'r') as zip_ref:
            zip_ref.extractall("corp_code")
        return parse_corp_code("corp_code/corpCode.xml", target_list)
    else:
        print("Failed to download corpCode.xml")
        return None

def parse_corp_code(file_name, target_list):
    tree = ET.parse(file_name)
    root = tree.getroot()
    corp_codes = {}
    for corp in root.findall("list"):
        if corp.find("corp_name").text in target_list:
            corp_codes[corp.find("corp_name").text] = corp.find("corp_code").text
    return corp_codes

# Fetch data for each company within the date range
def fetch_data(api_key, corp_code, start_date, end_date):
    all_data = pd.DataFrame()
    for page_no in range(1, 11):  # Limit to first 10 pages for demonstration
        url = "https://opendart.fss.or.kr/api/list.json"
        params = {
            'crtfc_key': api_key,
            'corp_code': corp_code,
            'bgn_de': start_date.strftime('%Y%m%d'),
            'end_de': end_date.strftime('%Y%m%d'),
            'page_no': page_no,
            'page_count': 100
        }
        response = requests.get(url, params=params)
        if response.status_code == 200:
            data = pd.DataFrame(response.json().get('list', []))
            if not data.empty:
                all_data = pd.concat([all_data, data], ignore_index=True)
            else:
                break
        else:
            print(f"Failed to fetch data for {corp_code} on page {page_no}")
            break
    return all_data

# Insert fetched data into the database
def insert_data_into_db(data):
    conn = pymysql.connect(
        host='localhost',
        user='root',
        password='wkrwjs12!@',
        db='Quant',
        charset='utf8mb4'
    )
    with conn.cursor() as cursor:
        for _, row in tqdm(data.iterrows(), total=data.shape[0]):
            cursor.execute("""
                INSERT INTO RecentDisclosureList (
                    corp_code, corp_name, stock_code, corp_cls, report_nm, rcept_no, flr_nm, rcept_dt, rm
                ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
            """, tuple(row))
        conn.commit()
    conn.close()

def main():
    create_database_and_table()
    corp_codes = download_and_parse_corp_code(next(key_gen), target_list)
    if corp_codes:
        for corp_name, corp_code in corp_codes.items():
            print(f"Fetching data for {corp_name}...")
            data = fetch_data(next(key_gen), corp_code, start_date, end_date)
            if not data.empty:
                print(f"Inserting data for {corp_name}...")
                insert_data_into_db(data)
                print(f"Data inserted for {corp_name}.")
            else:
                print(f"No data found for {corp_name}.")

if __name__ == "__main__":
    main()

# %% + 38 커뮤니케이션
import requests
from bs4 import BeautifulSoup
import pandas as pd
import pymysql
import xml.etree.ElementTree as ET
import zipfile
from tqdm import tqdm
from datetime import datetime
from ipo_data_fetcher import get_company_list
"""
def get_company_list(pages=1):
    base_url = "http://www.38.co.kr/html/fund/index.htm?o=nw&page={}"
    company_names = []

    for page in range(1, pages + 1):
        full_url = base_url.format(page)
        response = requests.get(full_url, headers={'User-Agent': 'Mozilla/5.0'})
        soup = BeautifulSoup(response.text, 'html.parser')
        
        table = soup.find('table', {'summary': '신규상장종목'})
        if not table:
            print(f"No IPO data found on page {page}")
            continue
        
        rows = table.find_all('tr')[2:]
        for row in rows:
            cols = row.find_all('td')
            if not cols:
                continue
            company_name = cols[0].get_text(strip=True)
            if company_name:
                company_names.append(company_name)

    return company_names
"""
def api_key_generator(api_keys):
    while True:
        for key in api_keys:
            yield key

API_KEYS = [
    '6ad4c3e10d41586b038dbddf496aa1d4af319152',
    '775537425d61a8ef4217b424c2884e28234a7f12',
    'dbd07aaf3b70263b57868e6dc45e1ed5e21872fb'
]
key_gen = api_key_generator(API_KEYS)
api_key = next(key_gen)

def create_database_and_table():
    connection = pymysql.connect(
        host='localhost', 
        user='root', 
        password='wkrwjs12!@', 
        charset='utf8mb4'
    )
    cursor = connection.cursor()
    cursor.execute("CREATE DATABASE IF NOT EXISTS Quant")
    cursor.execute("USE Quant")
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS RecentDisclosureList (
            corp_code VARCHAR(8),
            corp_name VARCHAR(255),
            stock_code VARCHAR(6),
            corp_cls VARCHAR(1),
            report_nm VARCHAR(255),
            rcept_no VARCHAR(14),
            flr_nm VARCHAR(255),
            rcept_dt VARCHAR(8),
            rm VARCHAR(255)
        )
    """)
    connection.close()
    print("데이터베이스 'Quant'와 테이블 'RecentDisclosureList'가 준비되었습니다.")

def download_and_parse_corp_code(api_key):
    url = f"https://opendart.fss.or.kr/api/corpCode.xml?crtfc_key={api_key}"
    response = requests.get(url)
    if response.status_code == 200:
        with open("corpCode.zip", 'wb') as f:
            f.write(response.content)
        with zipfile.ZipFile("corpCode.zip", 'r') as zip_ref:
            zip_ref.extractall("corp_code")
        tree = ET.parse("corp_code/CORPCODE.xml")
        root = tree.getroot()
        corp_codes = {corp.find("corp_name").text: corp.find("corp_code").text for corp in root.findall("list")}
        # 주석 처리하여 법인 코드 전체 출력을 하지 않음
        # print(f"얻어진 법인 코드: {list(corp_codes.keys())}")
        return corp_codes
    else:
        print("corpCode.xml 파일 다운로드에 실패했습니다.")
        return {}

def fetch_data(api_key, corp_code, start_date, end_date):
    all_data = pd.DataFrame()
    for page_no in range(1, 11):
        url = "https://opendart.fss.or.kr/api/list.json"
        params = {
            'crtfc_key': api_key,
            'corp_code': corp_code,
            'bgn_de': start_date.strftime('%Y%m%d'),
            'end_de': end_date.strftime('%Y%m%d'),
            'page_no': page_no,
            'page_count': 100
        }
        response = requests.get(url, params=params)
        if response.status_code == 200:
            data = pd.DataFrame(response.json().get('list', []))
            if not data.empty:
                all_data = pd.concat([all_data, data], ignore_index=True)
            else:
                break
        else:
            print(f"{corp_code}에 대한 데이터 가져오기 실패: 페이지 {page_no}")
            break
    return all_data

def insert_data_into_db(data):
    conn = pymysql.connect(
        host='localhost', 
        user='root', 
        password='wkrwjs12!@', 
        db='Quant', 
        charset='utf8mb4'
    )
    cursor = conn.cursor()
    for _, row in tqdm(data.iterrows(), total=data.shape[0]):
        cursor.execute("""
            INSERT INTO RecentDisclosureList (
                corp_code, corp_name, stock_code, corp_cls, report_nm, rcept_no, flr_nm, rcept_dt, rm
            ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
        """, tuple(row))
    conn.commit()
    conn.close()
    print("데이터 삽입 완료.")

def main(pages_to_crawl=1):
    # 여기서 get_company_list 함수를 호출하고, 반환된 회사 목록을 사용합니다.
    # 이 부분은 ipo_data_fetcher 모듈에 정의된 get_company_list 함수가 정상적으로 작동한다고 가정하며,
    # 실제로는 해당 함수의 구현에 따라 다를 수 있습니다.

    print("크롤링할 페이지 수를 입력하세요: ")
    # 사용자 입력 처리는 생략되었습니다. pages_to_crawl 변수를 직접 수정하거나,
    # 필요에 따라 입력받는 로직을 추가해주세요.
    target_list = get_company_list(pages=pages_to_crawl)  # IPO 데이터 크롤러로부터 회사 목록을 가져옵니다.
    print(f"타겟 회사 목록: {target_list}")

    create_database_and_table()
    corp_codes = download_and_parse_corp_code(api_key)

    start_date = datetime.strptime('20230101', '%Y%m%d')
    end_date = datetime.strptime('20231231', '%Y%m%d')

    skipped_companies = []  # 건너뛴 회사들을 기록합니다.
    processed_companies = []  # 처리된 회사들을 기록합니다.

    for corp_name in target_list:
        if corp_name in corp_codes:
            corp_code = corp_codes[corp_name]
            data = fetch_data(api_key, corp_code, start_date, end_date)
            if not data.empty:
                insert_data_into_db(data)
                print(f"{corp_name}의 데이터가 삽입되었습니다.")
                processed_companies.append(corp_name)  # 처리된 회사 추가
            else:
                print(f"{corp_name}에 대한 데이터를 찾을 수 없습니다.")
                skipped_companies.append(corp_name)  # 건너뛴 회사 추가
        else:
            print(f"경고: '{corp_name}'의 법인 코드를 찾을 수 없습니다. 이 회사는 건너뜁니다.")
            skipped_companies.append(corp_name)  # 건너뛴 회사 추가

    # 건너뛴 회사와 처리된 회사 목록 출력
    print("처리된 회사들:", processed_companies)
    print("건너뛴 회사들:", skipped_companies)

if __name__ == "__main__":
    main(pages_to_crawl=1)
