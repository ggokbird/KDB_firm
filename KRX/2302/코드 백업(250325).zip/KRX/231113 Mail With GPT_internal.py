# -*- coding: utf-8 -*-
"""
Created on Mon Nov 13 11:32:01 2023

@author: 221016
"""
# %% 내부망에서 실행하는 Mail With GPT 
import smtplib
import imaplib
import time
from email.mime.text import MIMEText
from email import message_from_string

# SMTP 설정 (내부망에서 외부망으로 이메일 송신용)
SMTP_SERVER = 'smtp.kmail.krx.co.kr'
SMTP_PORT = 465
SMTP_USERNAME = 'internal_user@krx.co.kr'
SMTP_PASSWORD = 'internal_password'

# IMAP 설정 (내부망의 외부메일함 확인용)
IMAP_SERVER = 'imap.kmail.krx.co.kr'
IMAP_PORT = 993
IMAP_USERNAME = SMTP_USERNAME
IMAP_PASSWORD = SMTP_PASSWORD
your_query = ""

def send_email(subject, body, smtp_server, smtp_port, username, password, to_addr):
    with smtplib.SMTP_SSL(smtp_server, smtp_port) as smtp:
        smtp.login(username, password)
        msg = MIMEText(body, 'plain')
        msg['Subject'] = subject
        msg['From'] = username
        msg['To'] = to_addr
        smtp.sendmail(username, to_addr, msg.as_string())

def wait_for_email(imap_server, imap_port, username, password, subject_keyword):
    mail = imaplib.IMAP4_SSL(imap_server, imap_port)
    mail.login(username, password)
    mail.select('inbox')

    while True:
        result, data = mail.search(None, 'ALL')
        mail_ids = data[0]
        id_list = mail_ids.split()

        for i in id_list:
            result, email_data = mail.fetch(i, '(RFC822)')
            raw_email = email_data[0][1].decode('utf-8')
            msg = message_from_string(raw_email)
            subject = msg['Subject']
            
            if subject_keyword in subject:
                print(f"Received response: {msg.get_payload(decode=True).decode('utf-8')}")
                return

        time.sleep(15)  # 폴링 간격 15초

# GPT_Query 송신
send_email("GPT_Query", your_query, SMTP_SERVER, SMTP_PORT, SMTP_USERNAME, SMTP_PASSWORD, "external_user@naver.com")

# GPT_response 대기
wait_for_email(IMAP_SERVER, IMAP_PORT, IMAP_USERNAME, IMAP_PASSWORD, "GPT_response")
