# -*- coding: utf-8 -*-
"""
Created on Mon Nov 13 12:39:42 2023

@author: 221016
"""
# api_key = "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"

import imaplib
import smtplib
from email.mime.text import MIMEText
from email import message_from_string
import openai
import time

# SMTP 및 IMAP 설정 (외부망)
SMTP_SERVER = 'smtp.gmail.com'
SMTP_PORT = 465
IMAP_SERVER = 'imap.gmail.com'
IMAP_PORT = 993
USERNAME = 'goguma.djmin@gmail.com'
PASSWORD = 'jiaw ywrq dzph oixz'  # Gmail 계정의 비밀번호를 여기에 입력하세요.
# Outlook : ekek qlvc zkpm jiif

# 내부망 이메일 주소 설정
INTERNAL_EMAIL_ADDRESS = 'goguma@krx.co.kr'

# OpenAI API 설정
api_key = "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"
openai.api_key = api_key

def wait_for_email_and_fetch(imap_server, imap_port, username, password):
    mail = imaplib.IMAP4_SSL(imap_server, imap_port)
    mail.login(username, password)
    mail.select('inbox')

    while True:
        result, data = mail.search(None, 'ALL')
        mail_ids = data[0].split()
        for i in mail_ids:
            result, email_data = mail.fetch(i, '(RFC822)')
            raw_email = email_data[0][1].decode('utf-8')
            msg = message_from_string(raw_email)
            subject = msg['Subject']
            if "GPT_Query" in subject:
                return "GPT_Query", msg.get_payload(decode=True).decode('utf-8')
            elif "Simple_Text" in subject:
                return "Simple Text", msg.get_payload(decode=True).decode('utf-8')
        time.sleep(15)  # 폴링 간격 15초

def send_response_email(subject, body, smtp_server, smtp_port, username, password, to_addr):
    with smtplib.SMTP_SSL(smtp_server, smtp_port) as smtp:
        smtp.login(username, password)
        msg = MIMEText(body, 'plain')
        msg['Subject'] = subject
        msg['From'] = username
        msg['To'] = to_addr
        smtp.sendmail(username, to_addr, msg.as_string())

# 이메일 대기 및 가져오기
email_type, email_content = wait_for_email_and_fetch(IMAP_SERVER, IMAP_PORT, USERNAME, PASSWORD)

# 이메일 유형에 따른 처리
if email_type == "GPT_Query":
    # GPT-4에 질의 후 응답 이메일 보내기
    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=[
            {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user", "content": email_content}
        ]
    )
    gpt_response = response['choices'][0]['message']['content'].strip()
    # 내부망 주소로 GPT-4 응답 보내기
    send_response_email("GPT_response", gpt_response, SMTP_SERVER, SMTP_PORT, USERNAME, PASSWORD, INTERNAL_EMAIL_ADDRESS)
elif email_type == "Simple Text":
    # 단순 텍스트 처리
    print("Received simple text: ", email_content)
    # 필요한 추가 작업 수행
else:
    print("Unknown email type.")

# %% Simpe Text Error Fixed 
import smtplib
from email.mime.text import MIMEText
from email import message_from_string
import openai
import time

# SMTP 및 IMAP 설정 (외부망)
SMTP_SERVER = 'smtp.gmail.com'
SMTP_PORT = 465
IMAP_SERVER = 'imap.gmail.com'
IMAP_PORT = 993
USERNAME = 'goguma.djmin@gmail.com'
PASSWORD = 'jiaw ywrq dzph oixz'  # Gmail 계정의 비밀번호를 여기에 입력하세요.
# Outlook : ekek qlvc zkpm jiif

# 내부망 이메일 주소 설정
INTERNAL_EMAIL_ADDRESS = 'goguma@krx.co.kr'

# OpenAI API 설정
api_key = "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"
openai.api_key = api_key

def wait_for_email_and_fetch(imap_server, imap_port, username, password):
    mail = imaplib.IMAP4_SSL(imap_server, imap_port)
    mail.login(username, password)
    mail.select('inbox')

    last_checked_email_id = 0  # 마지막으로 확인한 이메일 ID 초기화

    while True:
        result, data = mail.search(None, 'ALL')
        mail_ids = data[0].split()
        mail_ids.sort(reverse=True)  # 최신 이메일부터 처리하기 위해 내림차순 정렬

        for i in mail_ids:
            email_id = int(i)
            if email_id <= last_checked_email_id:
                continue  # 이미 확인한 이메일은 건너뛰기

            result, email_data = mail.fetch(i, '(RFC822)')
            raw_email = email_data[0][1].decode('utf-8')
            msg = message_from_string(raw_email)
            subject = msg['Subject']

            last_checked_email_id = email_id  # 확인한 이메일 ID 업데이트

            if "GPT_Query" in subject:
                return "GPT_Query", msg.get_payload(decode=True).decode('utf-8')
            elif "Simple_Text" in subject:
                return "Simple Text", msg.get_payload(decode=True).decode('utf-8')

        time.sleep(15)  # 폴링 간격 15초

def send_response_email(subject, body, smtp_server, smtp_port, username, password, to_addr):
    with smtplib.SMTP_SSL(smtp_server, smtp_port) as smtp:
        smtp.login(username, password)
        msg = MIMEText(body, 'plain')
        msg['Subject'] = subject
        msg['From'] = username
        msg['To'] = to_addr
        smtp.sendmail(username, to_addr, msg.as_string())

# 이메일 대기 및 가져오기
email_type, email_content = wait_for_email_and_fetch(IMAP_SERVER, IMAP_PORT, USERNAME, PASSWORD)

# 이메일 유형에 따른 처리
if email_type == "GPT_Query":
    # GPT-4에 질의 후 응답 이메일 보내기
    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=[
            {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user", "content": email_content}
        ]
    )
    gpt_response = response['choices'][0]['message']['content'].strip()
    # 내부망 주소로 GPT-4 응답 보내기
    send_response_email("GPT_response", gpt_response, SMTP_SERVER, SMTP_PORT, USERNAME, PASSWORD, INTERNAL_EMAIL_ADDRESS)
elif email_type == "Simple Text":
    # 단순 텍스트 처리
    print("Received simple text: ", email_content)
    # 필요한 추가 작업 수행
else:
    print("Unknown email type.")
    
# %% File Type Added 
import imaplib
import smtplib
from email.mime.text import MIMEText
from email import message_from_string
import openai
import time
import os

# SMTP 및 IMAP 설정 (외부망)
SMTP_SERVER = 'smtp.gmail.com'
SMTP_PORT = 465
IMAP_SERVER = 'imap.gmail.com'
IMAP_PORT = 993
USERNAME = 'goguma.djmin@gmail.com'
PASSWORD = 'jiaw ywrq dzph oixz'  # Gmail 계정의 비밀번호를 여기에 입력하세요.

# 내부망 이메일 주소 설정
INTERNAL_EMAIL_ADDRESS = 'goguma@krx.co.kr'

# OpenAI API 설정
api_key = "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"
openai.api_key = api_key

def save_email_as_msg(subject, raw_email, directory="path_to_save"):
    """ 주어진 이메일을 .msg 형식으로 저장합니다. """
    filepath = os.path.join(directory, f"{subject}.msg")
    with open(filepath, "wb") as f:
        f.write(raw_email)

def wait_for_email_and_fetch(imap_server, imap_port, username, password):
    mail = imaplib.IMAP4_SSL(imap_server, imap_port)
    mail.login(username, password)
    mail.select('inbox')

    last_checked_email_id = 0  # 마지막으로 확인한 이메일 ID 초기화

    while True:
        result, data = mail.search(None, 'ALL')
        mail_ids = data[0].split()
        mail_ids.sort(reverse=True)  # 최신 이메일부터 처리하기 위해 내림차순 정렬

        for i in mail_ids:
            email_id = int(i)
            if email_id <= last_checked_email_id:
                continue  # 이미 확인한 이메일은 건너뛰기

            result, email_data = mail.fetch(i, '(RFC822)')
            raw_email = email_data[0][1]
            msg = message_from_string(raw_email.decode('utf-8'))
            subject = msg['Subject']

            last_checked_email_id = email_id  # 확인한 이메일 ID 업데이트

            if "File Type" in subject:
                save_email_as_msg(subject, raw_email)
                print(f"File Type email saved as .msg file: {subject}")
            elif "GPT_Query" in subject:
                return "GPT_Query", msg.get_payload(decode=True).decode('utf-8')
            elif "Simple_Text" in subject:
                return "Simple Text", msg.get_payload(decode=True).decode('utf-8')

        time.sleep(15)  # 폴링 간격 15초

def send_response_email(subject, body, smtp_server, smtp_port, username, password, to_addr):
    with smtplib.SMTP_SSL(smtp_server, smtp_port) as smtp:
        smtp.login(username, password)
        msg = MIMEText(body, 'plain')
        msg['Subject'] = subject
        msg['From'] = username
        msg['To'] = to_addr
        smtp.sendmail(username, to_addr, msg.as_string())

# 이메일 대기 및 가져오기
email_type, email_content = wait_for_email_and_fetch(IMAP_SERVER, IMAP_PORT, USERNAME, PASSWORD)

# 이메일 유형에 따른 처리
if email_type == "GPT_Query":
    # GPT-4에 질의 후 응답 이메일 보내기
    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=[
            {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user", "content": email_content}
        ]
    )
    gpt_response = response['choices'][0]['message']['content'].strip()
    # 내부망 주소로 GPT-4 응답 보내기
    send_response_email("GPT_response", gpt_response, SMTP_SERVER, SMTP_PORT, USERNAME, PASSWORD, INTERNAL_EMAIL_ADDRESS)
elif email_type == "Simple Text":
    # 단순 텍스트 처리
    print("Received simple text: ", email_content)
else:
    print("Unknown email type or File Type email saved.")
