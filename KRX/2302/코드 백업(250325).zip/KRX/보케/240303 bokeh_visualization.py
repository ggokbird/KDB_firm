# -*- coding: utf-8 -*-
"""
Created on Sun Mar  3 13:57:08 2024

@author: 221016
"""

import pandas as pd
import geopandas as gpd
import osmnx as ox
from bokeh.plotting import figure, output_notebook, show
from bokeh.models import GeoJSONDataSource, HoverTool, LinearColorMapper
from bokeh.palettes import Viridis256 as palette
from bokeh.tile_providers import CARTODBPOSITRON_RETINA
import json
from shapely.ops import transform
from pyproj import Transformer

# OSMnx 설정: 경계 데이터 다운로드에 필요
ox.config(use_cache=True, log_console=True)

# 사용자 리포트 엑셀 파일과 지오코딩된 주소 정보가 담긴 엑셀 파일 불러오기
df_user = pd.read_excel('User_report.xlsx')
df_geocoded = pd.read_excel('geocoded_addresses.xlsx')

# 국가명 수정을 위한 매핑 딕셔너리
country_name_corrections = {
    '0': None,  # 유효하지 않은 값으로 간주하고 제외
    'ABROAD': None,  # 구체적인 국가명이 아니므로 제외
    'Arab Emirates': 'United Arab Emirates',
    'Bahrain': 'Bahrain',  # Bahrain은 이미 world 데이터셋에 포함되어 있지 않습니다. 추가 검토 필요
    'Bermuda': 'Bermuda',
    'British Virgin Islands': 'United Kingdom', # Virgin Islands, 영국명으로 가정
    'Cayman Islands': 'Cayman Islands',
    'England': 'United Kingdom',
    'British': 'United Kingdom',
    'Virgin Islands': 'United Kingdom',
    'Gibraltar': 'Gibraltar',
    'Great Britain': 'United Kingdom',
    'Grenada': 'Grenada',
    'Guernsey, Channel Islands': 'Guernsey',
    'Hong Kong': 'Hong Kong Island',  # Hong Kong은 China에 포함될 수 있으나, "Hong Kong S.A.R"로 별도 표시를 고려할 수 있습니다.
    'Irish Republic': 'Ireland',
    'Jersey, Channel Islands': 'Jersey',
    'Korea': 'South Korea',
    'Liechtenstein': 'Liechtenstein',
    'Mauritius': 'Mauritius',
    'Monaco': 'Monaco',
    'Scotland': 'United Kingdom',
    'Seychelles': 'Seychelles',
    'Singapore': 'Singapore',
    'Sydney': None,  # 도시명으로 국가명으로의 매핑이 필요합니다. 'Australia'로 매핑 고려
    'United States': 'United States of America'
}

# 국가명 수정 적용
df_user['변경 국가명'] = df_user['변경 국가명'].replace(country_name_corrections)

# '변경 국가명'을 기반으로 그룹화 및 매출액 합계 계산
df_country_sales = df_user.groupby('변경 국가명')['금액 계산'].sum().reset_index()
df_country_sales.rename(columns={'금액 계산': 'Sales'}, inplace=True)

# 매출액 대비 비율 계산
total_sales = df_country_sales['Sales'].sum()
df_country_sales['Percentage'] = (df_country_sales['Sales'] / total_sales) * 100

# world 데이터셋 로드 및 병합 전 국가 개수 출력
world = gpd.read_file(gpd.datasets.get_path('naturalearth_lowres'))

# 매칭되지 않는 국가명 처리 및 추가적인 국가 경계 데이터 다운로드
unmatched_countries = [
    'Bahrain', 'Bermuda', 'Cayman Islands', 'Gibraltar', 'Grenada', 'Guernsey',
    'Jersey', 'Liechtenstein', 'Mauritius', 'Monaco', 'Seychelles', 'Singapore',
    "Hong Kong"
]

additional_gdf = gpd.GeoDataFrame()

for country in unmatched_countries:
    try:
        gdf = ox.geocode_to_gdf(country)
        additional_gdf = pd.concat([additional_gdf, gdf], ignore_index=True)
        print(f"{country} 경계 데이터 다운로드 성공")
    except Exception as e:
        print(f"{country} 경계 데이터 다운로드 실패: {e}")

# additional_gdf에 데이터가 있으면 world 데이터셋과 병합
if not additional_gdf.empty:
    additional_gdf['name'] = additional_gdf['display_name'].apply(lambda x: x.split(',')[0])
    world = pd.concat([world, additional_gdf], ignore_index=True)
    world.drop_duplicates(subset='name', inplace=True)

# world 데이터셋과 매출 데이터 병합
world = world.merge(df_country_sales, left_on='name', right_on='변경 국가명', how='left')

# 매출 데이터가 양수인데 경계 데이터가 누락된 국가 식별
matched_sales_countries = df_country_sales[df_country_sales['Sales'] > 0]['변경 국가명'].unique()
matched_world_countries = world.dropna(subset=['Sales'])['name'].unique()
unmatched_countries_with_sales = [country for country in matched_sales_countries if country not in matched_world_countries]
print("매출은 있으나, 국가 경계 데이터가 매칭되지 않은 국가들:", unmatched_countries_with_sales)

# Bokeh 시각화 설정
output_notebook()
tile_provider = CARTODBPOSITRON_RETINA
p = figure(title="국가별 매출액 시각화", x_axis_type="mercator", y_axis_type="mercator", sizing_mode="scale_width", height=400)
p.add_tile(tile_provider)

# GeoJSONDataSource 객체 생성 및 시각화
geo_source = GeoJSONDataSource(geojson=world.to_json())
mapper = LinearColorMapper(palette=palette, low=df_country_sales['Sales'].min(), high=df_country_sales['Sales'].max())

# 매출액 시각화 및 툴팁 설정
p.add_tools(HoverTool(tooltips=[("Country", "@name"), ("Sales", "@Sales{0,0}"), ("Percentage", "@Percentage{0.2f}%")]))
p.patches('xs', 'ys', source=geo_source, fill_color={'field': 'Sales', 'transform': mapper}, line_color='white', line_width=0.5)

# 결과 표시
show(p)
