# -*- coding: utf-8 -*-
"""
Created on Sun Sep  3 22:52:40 2023

@author: Dongjae
"""

# -*- coding: utf-8 -*-
"""
Created on Fri Aug  4 11:08:11 2023

@author: Dongjae
"""

# %%

####### 0. 변수 지정 및 패키지 불러오기 #######

from datetime import datetime
from selenium import webdriver
from time import sleep
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By

from bs4 import BeautifulSoup
import pandas as pd
import re
import os
import requests

# %% (0) chrome driver Installer 
# https://sites.google.com/chromium.org/driver/
# https://googlechromelabs.github.io/chrome-for-testing/ 

start_date = '20230101'  # 공시 검색 시작일자
end_date = '20230331' # 공시 검색 종료일자
filePath = '/Users/KRX/Desktop/201021' # 바탕화면에 저장할 때 사용
chrome_version = "116.0.5845.96"
 
def createAndSetWorkingDir(directory):
    try:
        if not os.path.exists(directory):
            os.makedirs(directory)
        os.chdir(directory)  # 작업 디렉토리를 변경합니다.
        print(f"Current working directory is now set to: {os.getcwd()}")
    except OSError as e:
        print(f'Error: {e}')

createAndSetWorkingDir(filePath)

import os
import zipfile
import requests
import re
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.common.exceptions import SessionNotCreatedException

def download_chromedriver(chrome_version):
    # ZIP 파일을 Working DIR에 다운로드합니다.
    zip_path = os.path.join(os.getcwd(), "chromedriver.zip")
    
    url = f"https://edgedl.me.gvt1.com/edgedl/chrome/chrome-for-testing/{chrome_version}/win32/chromedriver-win32.zip"
    response = requests.get(url, stream=True)
    response.raise_for_status()

    with open(zip_path, "wb") as f:
        for chunk in response.iter_content(chunk_size=8192):
            f.write(chunk)

    # ZIP 파일을 압축 해제합니다.
    with zipfile.ZipFile(zip_path, 'r') as zip_ref:
        zip_ref.extractall(os.getcwd())

    # chromedriver.exe의 실제 경로를 찾습니다.
    for root, dirs, files in os.walk(os.getcwd()):
        for file in files:
            if file == "chromedriver.exe":
                original_path = os.path.join(root, file)
                new_path = os.path.join(os.getcwd(), "chromedriver.exe")
                os.rename(original_path, new_path)
                return new_path

    raise FileNotFoundError(f"'chromedriver.exe' was not found in the extracted directory.")

# %% # %% Crawler 
"""
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from bs4 import BeautifulSoup
import re
import pandas as pd
import time

# 변수 초기화
start_date = '20230101'
end_date = '20230331'

# 웹 드라이버 초기화
driver = webdriver.Chrome()

# KIND 공시화면 불러오기
url = 'http://kind.krx.co.kr/disclosure/details.do?method=searchDetailsMain'
driver.get(url)
time.sleep(2)

# 자주 쓰는 태그
tag_a = driver.find_element(By.CSS_SELECTOR, "input#fromDate")
tag_b = driver.find_element(By.CSS_SELECTOR, 'input#toDate')
tag_c = driver.find_element(By.CSS_SELECTOR, 'input#reportNmTemp')
tag_e = driver.find_element(By.XPATH, '//*[@id="currentPageSize"]/option[4]')
tag_f = driver.find_element(By.XPATH, '//*[@id="searchForm"]/section[1]/div/div[3]/a[1]')

time.sleep(2)

# 검색기간 입력
for i in range(10):
    tag_b.send_keys(Keys.BACKSPACE)
tag_b.send_keys(end_date)

for i in range(10):
    tag_a.send_keys(Keys.BACKSPACE)
tag_a.send_keys(start_date)

time.sleep(1)

# 공시개수 페이지당 100건
tag_e.click()
time.sleep(1)

# 최종보고서만 클릭
driver.find_element(By.XPATH, '/html/body/section[2]/section/form/section[1]/div/div[1]/table/tbody/tr[7]/td/label/input').click()
time.sleep(1)

# 원하는 공시 검색
tag_c.send_keys('자기주식처분결과보고서')
tag_f.click()

time.sleep(5)

# 공시개수 확인
number = driver.find_element(By.XPATH, '/html/body/section[2]/section/article/section[2]/div[2]/em')
numText = number.text

if int(numText) >= 100:
    print("한 페이지에 공시의 갯수가 100개 초과")
else:
    print("한 페이지에 공시의 갯수가 100개 미만")

time.sleep(2)

# 현재 페이지의 HTML 소스를 가져옵니다.
page_source = driver.page_source

# BeautifulSoup로 HTML을 파싱합니다.
soup = BeautifulSoup(page_source, 'html.parser')

# "자기주식처분결과보고서"에 해당하는 모든 링크를 찾습니다.
links = soup.find_all('a', title="자기주식처분결과보고서") # [0:2] Just for Example

# 시간과 회사명 크롤링
time_elements = driver.find_elements(By.CSS_SELECTOR, "td.txc:nth-child(2)")  # CSS 선택자 수정
company_elements = driver.find_elements(By.CSS_SELECTOR, "td > a#companysum")
times = [element.text for element in time_elements]
companies = [element.text for element in company_elements]

# 각 링크를 순회하며 클릭합니다.
data_list = []

for idx, link in enumerate(links):
    try:
        doc_id = re.search(r"openDisclsViewer\('(\d+)',", link['onclick']).group(1)
        driver.execute_script(f"openDisclsViewer('{doc_id}','')")
        time.sleep(3)

        # 새 창이나 탭이 열렸는지 확인하고, 필요한 경우 웹 드라이버를 해당 창이나 탭으로 전환합니다.
        windows = driver.window_handles
        if len(windows) > 1:
            driver.switch_to.window(windows[1])

        # 첫 번째 iframe (name="toc")으로 전환
        driver.switch_to.frame("toc")

        # 원하는 링크를 클릭
        driver.find_element(By.LINK_TEXT, "2. 처분보고에 관한 내용").click()

        # 메인 창으로 전환
        driver.switch_to.default_content()

        # 두 번째 iframe (name="docViewFrm")으로 전환
        driver.switch_to.frame("docViewFrm")

        # 네 번째 테이블의 데이터를 추출
        table = driver.find_element(By.XPATH, "/html/body/table[4]")
        rows = table.find_elements(By.TAG_NAME, "tr")

        for row in rows:
            columns = row.find_elements(By.TAG_NAME, "td")
            row_data = [column.text for column in columns]
            
            # "시간"과 "회사명"을 데이터 앞에 추가
            row_data.insert(0, companies[idx])
            row_data.insert(0, times[idx])
            data_list.append(row_data)

        # 원래의 페이지로 돌아옵니다.
        driver.close()
        driver.switch_to.window(windows[0])
        time.sleep(2)
    except Exception as e:
        print(f"Error occurred: {e}")
        break

# 데이터를 DataFrame으로 변환하고 출력
column_names = ["시간", "회사명", "일자", "종류", "주문수량", "처분수량", "1주당 처분가액", "처분가액 총액", "처분대상", "매도위탁 증권회사_금융투자업자", "매도위탁 증권회사_고유번호"]

df = pd.DataFrame(data_list, columns=column_names)
df.dropna(axis = 0, inplace = True)
print(df)

# 웹 드라이버 종료
driver.quit()
"""
# %% All pages Crawler 
"""
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from bs4 import BeautifulSoup
import re
import pandas as pd
import time

# 변수 초기화
start_date = '20220101'
end_date = '20230331'

# 웹 드라이버 초기화
driver = webdriver.Chrome()

# KIND 공시화면 불러오기
url = 'http://kind.krx.co.kr/disclosure/details.do?method=searchDetailsMain'
driver.get(url)
time.sleep(2)

# 자주 쓰는 태그
tag_a = driver.find_element(By.CSS_SELECTOR, "input#fromDate")
tag_b = driver.find_element(By.CSS_SELECTOR, 'input#toDate')
tag_c = driver.find_element(By.CSS_SELECTOR, 'input#reportNmTemp')
tag_e = driver.find_element(By.XPATH, '//*[@id="currentPageSize"]/option[4]')
tag_f = driver.find_element(By.XPATH, '//*[@id="searchForm"]/section[1]/div/div[3]/a[1]')

time.sleep(2)

# 검색기간 입력
for i in range(10):
    tag_b.send_keys(Keys.BACKSPACE)
tag_b.send_keys(end_date)

for i in range(10):
    tag_a.send_keys(Keys.BACKSPACE)
tag_a.send_keys(start_date)

time.sleep(1)

# 공시개수 페이지당 100건
tag_e.click()
time.sleep(1)

# 최종보고서만 클릭
driver.find_element(By.XPATH, '/html/body/section[2]/section/form/section[1]/div/div[1]/table/tbody/tr[7]/td/label/input').click()
time.sleep(1)

# 원하는 공시 검색
tag_c.send_keys('자기주식처분결과보고서')
tag_f.click()

time.sleep(5)

# 페이지 숫자 파악
page_elements = driver.find_elements(By.CSS_SELECTOR, "div.paging.type-00 > a")
max_page = 1
for page_element in page_elements:
    try:
        page_num = int(page_element.text)
        if page_num > max_page:
            max_page = page_num
    except ValueError:
        continue

print(f"Total pages: {max_page}")

# 모든 페이지를 순회하며 크롤링
for current_page in range(1, max_page + 1):
    # 현재 페이지의 HTML 소스를 가져옵니다.
    page_source = driver.page_source

    # BeautifulSoup로 HTML을 파싱합니다.
    soup = BeautifulSoup(page_source, 'html.parser')

    # "자기주식처분결과보고서"에 해당하는 모든 링크를 찾습니다.
    links = soup.find_all('a', title="자기주식처분결과보고서")

    # 시간과 회사명 크롤링
    time_elements = driver.find_elements(By.CSS_SELECTOR, "td.txc:nth-child(2)")
    company_elements = driver.find_elements(By.CSS_SELECTOR, "td > a#companysum")
    times = [element.text for element in time_elements]
    companies = [element.text for element in company_elements]

    # 각 링크를 순회하며 클릭합니다.
    data_list = []

    for idx, link in enumerate(links):
        try:
            doc_id = re.search(r"openDisclsViewer\('(\d+)',", link['onclick']).group(1)
            driver.execute_script(f"openDisclsViewer('{doc_id}','')")
            time.sleep(3)

            # 새 창이나 탭이 열렸는지 확인하고, 필요한 경우 웹 드라이버를 해당 창이나 탭으로 전환합니다.
            windows = driver.window_handles
            if len(windows) > 1:
                driver.switch_to.window(windows[1])

            # 첫 번째 iframe (name="toc")으로 전환
            driver.switch_to.frame("toc")

            # 원하는 링크를 클릭
            driver.find_element(By.LINK_TEXT, "2. 처분보고에 관한 내용").click()

            # 메인 창으로 전환
            driver.switch_to.default_content()

            # 두 번째 iframe (name="docViewFrm")으로 전환
            driver.switch_to.frame("docViewFrm")

            # 네 번째 테이블의 데이터를 추출
            table = driver.find_element(By.XPATH, "/html/body/table[4]")
            rows = table.find_elements(By.TAG_NAME, "tr")

            for row in rows:
                columns = row.find_elements(By.TAG_NAME, "td")
                row_data = [column.text for column in columns]
                
                # "시간"과 "회사명"을 데이터 앞에 추가
                row_data.insert(0, companies[idx])
                row_data.insert(0, times[idx])
                data_list.append(row_data)

            # 원래의 페이지로 돌아옵니다.
            driver.close()
            driver.switch_to.window(windows[0])
            time.sleep(2)
        except Exception as e:
            print(f"Error occurred: {e}")
            break

    # 데이터를 DataFrame으로 변환하고 출력
    column_names = ["시간", "회사명", "일자", "종류", "주문수량", "처분수량", "1주당 처분가액", "처분가액 총액", "처분대상", "매도위탁 증권회사_금융투자업자", "매도위탁 증권회사_고유번호"]

    df = pd.DataFrame(data_list, columns=column_names)
    df.dropna(axis = 0, inplace = True)
    print(df)

    # 다음 페이지로 이동
    if current_page < max_page:
        next_page = driver.find_element(By.CSS_SELECTOR, f"a[href='#page_link_{current_page + 1}']")
        next_page.click()
        time.sleep(5)

# 웹 드라이버 종료
driver.quit()
"""
# %% Debugging : Apply implicit Wait 
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from bs4 import BeautifulSoup
import re
import pandas as pd
import time

# 변수 초기화
start_date = '20220101'
end_date = '20230331'

# 웹 드라이버 초기화
driver = webdriver.Chrome()
wait = WebDriverWait(driver, 10)

# KIND 공시화면 불러오기
url = 'http://kind.krx.co.kr/disclosure/details.do?method=searchDetailsMain'
driver.get(url)
time.sleep(2)

# 자주 쓰는 태그
tag_a = driver.find_element(By.CSS_SELECTOR, "input#fromDate")
tag_b = driver.find_element(By.CSS_SELECTOR, 'input#toDate')
tag_c = driver.find_element(By.CSS_SELECTOR, 'input#reportNmTemp')
tag_e = driver.find_element(By.XPATH, '//*[@id="currentPageSize"]/option[4]')
tag_f = driver.find_element(By.XPATH, '//*[@id="searchForm"]/section[1]/div/div[3]/a[1]')

time.sleep(2)

# 검색기간 입력
for i in range(10):
    tag_b.send_keys(Keys.BACKSPACE)
tag_b.send_keys(end_date)

for i in range(10):
    tag_a.send_keys(Keys.BACKSPACE)
tag_a.send_keys(start_date)

time.sleep(1)

# 공시개수 페이지당 100건
tag_e.click()
time.sleep(1)

# 최종보고서만 클릭
driver.find_element(By.XPATH, '/html/body/section[2]/section/form/section[1]/div/div[1]/table/tbody/tr[7]/td/label/input').click()
time.sleep(1)

# 원하는 공시 검색
tag_c.send_keys('자기주식처분결과보고서')
tag_f.click()

time.sleep(5)

# 페이지 숫자 파악
page_elements = driver.find_elements(By.CSS_SELECTOR, "div.paging.type-00 > a")
max_page = 1
for page_element in page_elements:
    try:
        page_num = int(page_element.text)
        if page_num > max_page:
            max_page = page_num
    except ValueError:
        continue

print(f"Total pages: {max_page}")

all_data = []  # 모든 페이지의 데이터를 저장할 리스트

# 모든 페이지를 순회하며 크롤링
for current_page in range(1, max_page + 1):
    # 현재 페이지의 HTML 소스를 가져옵니다.
    page_source = driver.page_source

    # BeautifulSoup로 HTML을 파싱합니다.
    soup = BeautifulSoup(page_source, 'html.parser')

    # "자기주식처분결과보고서"에 해당하는 모든 링크를 찾습니다.
    links = soup.find_all('a', title="자기주식처분결과보고서")

    # 시간과 회사명 크롤링
    time_elements = driver.find_elements(By.CSS_SELECTOR, "td.txc:nth-child(2)")
    company_elements = driver.find_elements(By.CSS_SELECTOR, "td > a#companysum")
    times = [element.text for element in time_elements]
    companies = [element.text for element in company_elements]

    # 각 링크를 순회하며 클릭합니다.
    data_list = []

    for idx, link in enumerate(links):
        try:
            doc_id = re.search(r"openDisclsViewer\('(\d+)',", link['onclick']).group(1)
            driver.execute_script(f"openDisclsViewer('{doc_id}','')")
            time.sleep(3)

            # 새 창이나 탭이 열렸는지 확인하고, 필요한 경우 웹 드라이버를 해당 창이나 탭으로 전환합니다.
            windows = driver.window_handles
            if len(windows) > 1:
                driver.switch_to.window(windows[1])

            # 첫 번째 iframe (name="toc")으로 전환
            wait.until(EC.frame_to_be_available_and_switch_to_it((By.NAME, "toc")))

            # 원하는 링크를 클릭
            wait.until(EC.element_to_be_clickable((By.LINK_TEXT, "2. 처분보고에 관한 내용"))).click()

            # 메인 창으로 전환
            driver.switch_to.default_content()

            # 두 번째 iframe (name="docViewFrm")으로 전환
            wait.until(EC.frame_to_be_available_and_switch_to_it((By.NAME, "docViewFrm")))

            # 네 번째 테이블의 데이터를 추출
            table = wait.until(EC.presence_of_element_located((By.XPATH, "/html/body/table[4]")))
            rows = table.find_elements(By.TAG_NAME, "tr")

            for row in rows:
                columns = row.find_elements(By.TAG_NAME, "td")
                row_data = [column.text for column in columns]
                
                # "시간"과 "회사명"을 데이터 앞에 추가
                row_data.insert(0, companies[idx])
                row_data.insert(0, times[idx])
                data_list.append(row_data)  # 데이터 출력용
                all_data.append(row_data)  # 데이터를 all_data 리스트에 추가

            # 원래의 페이지로 돌아옵니다.
            driver.close()
            driver.switch_to.window(windows[0])
            time.sleep(2)
        except Exception as e:
            print(f"Error occurred: {e}")
            break

    # 데이터를 DataFrame으로 변환하고 출력
    column_names = ["시간", "회사명", "일자", "종류", "주문수량", "처분수량", "1주당 처분가액", "처분가액 총액", "처분대상", "매도위탁 증권회사_금융투자업자", "매도위탁 증권회사_고유번호"]

    df = pd.DataFrame(data_list, columns=column_names)
    df.dropna(axis = 0, inplace = True)
    print(df)

    # 다음 페이지로 이동
    if current_page < max_page:
        next_page = driver.find_element(By.CSS_SELECTOR, f"a[href='#page_link_{current_page + 1}']")
        next_page.click()
        time.sleep(5)

# 웹 드라이버 종료
driver.quit()

column_names = ["시간", "회사명", "일자", "종류", "주문수량", "처분수량", "1주당 처분가액", "처분가액 총액", "처분대상", "매도위탁 증권회사_금융투자업자", "매도위탁 증권회사_고유번호"]
df_all = pd.DataFrame(all_data, columns=column_names)
df_all.dropna(axis = 0, inplace = True)
print(df_all)

