# -*- coding: utf-8 -*-
"""
Created on Tue Oct 10 17:40:40 2023

@author: 221016
"""

import imaplib
import smtplib
from email.mime.text import MIMEText
import openai

# SMTP 및 IMAP 설정
SMTP_SERVER = 'kmail.krx.co.kr'
SMTP_PORT = 2525
IMAP_SERVER = 'kmail.krx.co.kr'
IMAP_PORT = 143

SMTP_USERNAME = 'goguma@krx.co.kr'
SMTP_PASSWORD = 'rnstn12!@'

# OpenAI API 설정
api_key = "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"
openai.api_key = api_key

# 네이버 메일에서 메시지 수신 및 내용 인식
mail = imaplib.IMAP4_SSL(IMAP_SERVER, IMAP_PORT)
mail.login(SMTP_USERNAME, SMTP_PASSWORD)
mail.select('inbox')

result, data = mail.search(None, 'ALL')
mail_ids = data[0]
id_list = mail_ids.split()
latest_email_id = int(id_list[-1])  # get the latest email
result, email_data = mail.fetch(str(latest_email_id), '(RFC822)')
raw_email = email_data[0][1].decode('utf-8')
# TODO: Extract the email body from raw_email

# GPT API 호출
user_content = "Extracted question from the email"
response = openai.ChatCompletion.create(
    model="gpt-3.5-turbo",
    messages=[
        {"role": "system", "content": "You are a helpful assistant."},
        {"role": "user", "content": user_content}
    ]
)
gpt4_response = response.choices[0].message['content']

# 응답을 내부망 메일로 전송
msg = MIMEText(gpt4_response, 'plain')
msg['From'] = SMTP_USERNAME
msg['To'] = 'YOUR_INTERNAL_EMAIL'
msg['Subject'] = 'GPT-4 Response'
smtp = smtplib.SMTP(SMTP_SERVER, SMTP_PORT)

smtp.starttls()
smtp.login(SMTP_USERNAME, SMTP_PASSWORD)
smtp.sendmail(SMTP_USERNAME, 'YOUR_INTERNAL_EMAIL', msg.as_string())
smtp.quit()

# %%
import imaplib
import ssl

SMTP_USERNAME = 'goguma@krx.co.kr'
SMTP_PASSWORD = 'rnstn12!@'

IMAP_SERVER = 'kmail.krx.co.kr'
IMAP_PORT = 993  # 일반적인 IMAP SSL 포트

# SSL 인증 우회 설정
# context = ssl.create_default_context()
# context.check_hostname = False
# context.verify_mode = ssl.CERT_NONE

mail = imaplib.IMAP4(IMAP_SERVER, IMAP_PORT)
mail.login(SMTP_USERNAME, SMTP_PASSWORD)

# %% MVP
import imaplib
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import openai

# OpenAI API 설정
api_key = "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"
openai.api_key = api_key

# SMTP 및 IMAP 설정
SMTP_SERVER = 'kmail.krx.co.kr'
SMTP_PORT = 2525
IMAP_SERVER = 'kmail.krx.co.kr'
IMAP_PORT = 143

SMTP_USERNAME = 'goguma@krx.co.kr'
SMTP_PASSWORD = 'rnstn12!@'

# 네이버 메일에서 메시지 수신 및 내용 인식
mail = imaplib.IMAP4_SSL(IMAP_SERVER, IMAP_PORT)
mail.login(SMTP_USERNAME, SMTP_PASSWORD)
mail.select('inbox')

result, data = mail.search(None, 'ALL')
mail_ids = data[0]
id_list = mail_ids.split()
latest_email_id = int(id_list[-1])  # get the latest email
result, email_data = mail.fetch(str(latest_email_id), '(RFC822)')
raw_email = email_data[0][1].decode('utf-8')
# TODO: Extract the email body from raw_email

# GPT API 호출
user_content = "Extracted question from the email"
response = openai.ChatCompletion.create(
    model="gpt-3.5-turbo",
    messages=[
        {"role": "system", "content": "You are a helpful assistant."},
        {"role": "user", "content": user_content}
    ]
)
gpt4_response = response.choices[0].message['content']

msg = MIMEText(gpt4_response, 'plain')
msg['From'] = SMTP_USERNAME
msg['To'] = 'YOUR_INTERNAL_EMAIL'
msg['Subject'] = 'GPT-4 Response'

smtp = smtplib.SMTP(SMTP_SERVER, SMTP_PORT)
smtp.starttls()
smtp.login(SMTP_USERNAME, SMTP_PASSWORD)
smtp.sendmail(SMTP_USERNAME, 'YOUR_INTERNAL_EMAIL', msg.as_string())
smtp.quit()

# %%
# 정기변경 결과 및 보고서를 전송하려면 외부메일 ID/PW 입력이 필요합니다.
id = 'goguma'
pw = 'rnstn12!@'

# 자동 심사결과를 받을 수신자를 지정해주세요. (여러 명에게 보내려면 리스트로 전달)
send_to = [id + '@krx.co.kr']  

import os
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.application import MIMEApplication
from email.utils import COMMASPACE
from datetime import datetime

# 이메일 보내기에 필요한 정보 입력
smtp_server = 'kmail.krx.co.kr'  # SMTP 서버 주소
smtp_port = 2525  # SMTP 서버 포트
smtp_username =  id + '@krx.co.kr'  # SMTP 계정 이메일 주소
smtp_password = pw  # SMTP 계정 비밀번호
send_from = id + '@krx.co.kr'  # 발신자 이메일 주소

subject = target_index + '_파이썬 정기변경 결과 및 보고서입니다'  # 이메일 제목
body = '[자동 메세지]\n' + target_index + '의 정기변경 결과(xlsx), 보고서(hwp)를 확인해보세요\n' \
    + '심사일 및 시각 : ' + datetime.now().strftime('%Y-%m-%d %H:%M:%S')

# 이메일 구성
msg = MIMEMultipart()
msg['From'] = send_from
msg['To'] = COMMASPACE.join(send_to)
msg['Subject'] = subject

# 이메일 본문 추가
msg.attach(MIMEText(body, 'plain'))

# 첨부 파일 추가 (정기변경 결과 xlsx)
with open(filepath + excel_name+'.xlsx', 'rb') as f:
    attachment = MIMEApplication(f.read(), _subtype='vnd.openxmlformats-officedocument.spreadsheetml.sheet')
    attachment.add_header('Content-Disposition', 'attachment', filename=excel_name+'.xlsx')
    msg.attach(attachment)

# 첨부 파일 추가 (보고서 hwp)
with open(filepath +"(" + reb_YYMM + ")_" + target_index + "_정기변경(안)_파이썬.hwp", 'rb') as f:
    attachment = MIMEApplication(f.read(), _subtype='x-hwp')
    attachment.add_header('Content-Disposition', 'attachment', filename="(" + reb_YYMM + ")_" + target_index + "_정기변경(안)_파이썬.hwp")
    msg.attach(attachment)

# SMTP 서버 연결 및 이메일 전송
smtp = smtplib.SMTP(smtp_server, smtp_port)
smtp.starttls()
smtp.login(smtp_username, smtp_password)
smtp.sendmail(send_from, send_to, msg.as_string())
smtp.quit()

# %% 
import smtplib
from email.mime.text import MIMEText

# SMTP 설정
SMTP_SERVER = 'kmail.krx.co.kr'
SMTP_PORT = 2525
SMTP_USERNAME = 'goguma@krx.co.kr'
SMTP_PASSWORD = 'rnstn12!@'

# GPT4 응답 (이 부분은 실제 GPT4 API 호출을 통해 얻은 응답을 가정합니다. 필요에 따라 수정할 수 있습니다.)
gpt4_response = "This is the response from GPT-4."

msg = MIMEText(gpt4_response, 'plain')
msg['From'] = SMTP_USERNAME
msg['To'] = 'YOUR_INTERNAL_EMAIL'
msg['Subject'] = 'GPT-4 Response'

smtp = smtplib.SMTP(SMTP_SERVER, SMTP_PORT)
smtp.starttls()
smtp.login(SMTP_USERNAME, SMTP_PASSWORD)
smtp.sendmail(SMTP_USERNAME, 'goguma@krx.co.kr', msg.as_string())
smtp.quit()

# %%
import imaplib
import smtplib
from email.mime.text import MIMEText

# SMTP 및 IMAP 설정
SMTP_SERVER = 'kmail.krx.co.kr'
SMTP_PORT = 2525
IMAP_SERVER = 'kmail.krx.co.kr'
IMAP_PORT = 143  # 일반적인 IMAP 포트

SMTP_USERNAME = 'goguma@krx.co.kr'
SMTP_PASSWORD = 'rnstn12!@'

# 메일에서 메시지 수신 및 내용 인식
mail = imaplib.IMAP4(IMAP_SERVER, IMAP_PORT)
mail.login(SMTP_USERNAME, SMTP_PASSWORD)
mail.select('inbox')

result, data = mail.search(None, 'ALL')
mail_ids = data[0]
id_list = mail_ids.split()
latest_email_id = int(id_list[-1])  # get the latest email
result, email_data = mail.fetch(str(latest_email_id), '(RFC822)')
print(email_data)
raw_email = email_data[0][1].decode('utf-8')
# TODO: Extract the email body from raw_email


# GPT4 응답 (이 부분은 실제 GPT4 API 호출을 통해 얻은 응답을 가정합니다. 필요에 따라 수정할 수 있습니다.)
gpt4_response = "Extracted question from the email"

# 메일 전송을 위한 SMTP 설정 및 메일 전송
msg = MIMEText(gpt4_response, 'plain')
msg['From'] = SMTP_USERNAME
msg['To'] = 'goguma@krx.co.kr'
msg['Subject'] = 'GPT-4 Response'

smtp = smtplib.SMTP(SMTP_SERVER, SMTP_PORT)
smtp.starttls()
smtp.login(SMTP_USERNAME, SMTP_PASSWORD)
smtp.sendmail(SMTP_USERNAME, 'goguma@krx.co.kr', msg.as_string())
smtp.quit()

# %%
import imaplib
import smtplib
from email.mime.text import MIMEText

# SMTP 및 IMAP 설정
SMTP_SERVER = 'kmail.krx.co.kr'
SMTP_PORT = 2525
IMAP_SERVER = 'kmail.krx.co.kr'
IMAP_PORT = 143  # 일반적인 IMAP 포트

SMTP_USERNAME = 'goguma@krx.co.kr'
SMTP_PASSWORD = 'rnstn12!@'

# 메일에서 메시지 수신 및 내용 인식
mail = imaplib.IMAP4(IMAP_SERVER, IMAP_PORT)
mail.login(SMTP_USERNAME, SMTP_PASSWORD)
mail.select('돈납부')  # "돈납부"라는 폴더 선택

result, data = mail.search(None, 'ALL')
mail_ids = data[0]
id_list = mail_ids.split()
all_emails = []

for email_id in id_list:
    result, email_data = mail.fetch(str(email_id), '(RFC822)')
    raw_email = email_data[0][1].decode('utf-8')
    all_emails.append(raw_email)  # 각 이메일 내용을 리스트에 추가

# TODO: Extract the desired content from all_emails

# GPT4 응답 (이 부분은 실제 GPT4 API 호출을 통해 얻은 응답을 가정합니다. 필요에 따라 수정할 수 있습니다.)
gpt4_response = "Extracted information from the emails"

# 메일 전송을 위한 SMTP 설정 및 메일 전송
msg = MIMEText(gpt4_response, 'plain')
msg['From'] = SMTP_USERNAME
msg['To'] = 'goguma@krx.co.kr'
msg['Subject'] = 'GPT-4 Response'

smtp = smtplib.SMTP(SMTP_SERVER, SMTP_PORT)
smtp.starttls()
smtp.login(SMTP_USERNAME, SMTP_PASSWORD)
smtp.sendmail(SMTP_USERNAME, 'goguma@krx.co.kr', msg.as_string())
smtp.quit()

# %% 
import imaplib
import smtplib
from email.mime.text import MIMEText

# SMTP 및 IMAP 설정
SMTP_SERVER = 'kmail.krx.co.kr'
SMTP_PORT = 2525
IMAP_SERVER = 'kmail.krx.co.kr'
IMAP_PORT = 143

SMTP_USERNAME = 'goguma@krx.co.kr'
SMTP_PASSWORD = 'rnstn12!@'

# 메일 연결 함수
def connect_to_mail():
    mail = imaplib.IMAP4(IMAP_SERVER, IMAP_PORT)
    mail.login(SMTP_USERNAME, SMTP_PASSWORD)
    mail.select('inbox')
    return mail

mail = connect_to_mail()

# 메일에서 메시지 수신 및 내용 인식
result, data = mail.search(None, '(NOT DELETED)')
mail_ids = data[0]
id_list = mail_ids.split()
all_emails = []

for email_id in id_list:
    try:
        result, email_data = mail.fetch(str(email_id), '(BODY[])')
        
        # email_data의 데이터 구조를 출력
        print(f"Data structure for email ID {email_id}: {email_data}")
        
        if email_data and isinstance(email_data, list):
            for part in email_data:
                if isinstance(part, tuple):
                    raw_email = part[1].decode('utf-8')
                    all_emails.append(raw_email)
                    break
        else:
            print(f"Unexpected data structure returned for email ID: {email_id}")
    except Exception as e:
        print(f"Error processing email ID: {email_id}. Error: {str(e)}")

# GPT4 응답
gpt4_response = "Extracted information from the emails"

# 메일 전송을 위한 SMTP 설정 및 메일 전송
msg = MIMEText(gpt4_response, 'plain')
msg['From'] = SMTP_USERNAME
msg['To'] = 'goguma@krx.co.kr'
msg['Subject'] = 'GPT-4 Response'

smtp = smtplib.SMTP(SMTP_SERVER, SMTP_PORT)
smtp.starttls()
smtp.login(SMTP_USERNAME, SMTP_PASSWORD)
smtp.sendmail(SMTP_USERNAME, 'goguma@krx.co.kr', msg.as_string())
smtp.quit()


# %%
import imaplib
import smtplib
from email.mime.text import MIMEText
from email import message_from_string

# SMTP 및 IMAP 설정

SMTP_SERVER = 'kmail.krx.co.kr'
SMTP_PORT = 2525
IMAP_SERVER = 'kmail.krx.co.kr'
IMAP_PORT = 143  # 일반적인 IMAP 포트

SMTP_USERNAME = 'goguma@krx.co.kr'
SMTP_PASSWORD = 'rnstn12!@'



# 메일에서 메시지 수신 및 내용 인식

mail = imaplib.IMAP4(IMAP_SERVER, IMAP_PORT)
mail.login(SMTP_USERNAME, SMTP_PASSWORD)
mail.select('inbox')

result, data = mail.search(None, 'ALL')
mail_ids = data[0]
id_list = mail_ids.split()
latest_email_id = int(id_list[-1])  # get the latest email

result, email_data = mail.fetch(str(latest_email_id), '(BODY.PEEK[])') 
raw_email = email_data[0][1]

# Ensure raw_email is decoded to string
if isinstance(raw_email, bytes):
    raw_email = raw_email.decode('utf-8')
elif isinstance(raw_email, int):
    print("Error: raw_email is of type int. Expected string or bytes.")
    exit()



# Extract email body
msg_obj = message_from_string(raw_email)
email_body = ""
if msg_obj.is_multipart():
    for payload in msg_obj.get_payload():
        email_body += payload.get_payload(decode=True).decode('utf-8', errors='ignore') if payload.get_content_type() == 'text/plain' else ""
else:
    email_body = msg_obj.get_payload(decode=True).decode('utf-8', errors='ignore')

# Send only the email body
gpt4_response = email_body

msg = MIMEText(gpt4_response, 'plain')
msg['From'] = SMTP_USERNAME
msg['To'] = 'goguma@krx.co.kr'
msg['Subject'] = 'GPT-4 Response'

smtp = smtplib.SMTP(SMTP_SERVER, SMTP_PORT)
smtp.starttls()
smtp.login(SMTP_USERNAME, SMTP_PASSWORD)
smtp.sendmail(SMTP_USERNAME, 'goguma@krx.co.kr', msg.as_string())
smtp.quit()