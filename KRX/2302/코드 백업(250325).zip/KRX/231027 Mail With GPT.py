# -*- coding: utf-8 -*-
"""
Created on Fri Oct 27 09:02:26 2023

@author: 221016
"""

import imaplib
import smtplib
from email.mime.text import MIMEText
from email import message_from_string
import openai

# SMTP 및 IMAP 설정
SMTP_SERVER_INTERNAL = 'kmail.krx.co.kr'
SMTP_PORT_INTERNAL = 2525
IMAP_SERVER_INTERNAL = 'kmail.krx.co.kr'
IMAP_PORT_INTERNAL = 143  

SMTP_SERVER_EXTERNAL = 'smtp.naver.com'
SMTP_PORT_EXTERNAL = 465
IMAP_SERVER_EXTERNAL = 'imap.naver.com'
IMAP_PORT_EXTERNAL = 993

SMTP_USERNAME_INTERNAL = 'goguma@krx.co.kr'
SMTP_PASSWORD_INTERNAL = 'rnstn12!@'

SMTP_USERNAME_EXTERNAL = 'your_naver_email@naver.com'
SMTP_PASSWORD_EXTERNAL = 'your_naver_email_password'

# OpenAI API 설정
api_key = "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"
openai.api_key = api_key

def extract_email_body(raw_email):
    if isinstance(raw_email, bytes):
        raw_email = raw_email.decode('utf-8')
    msg_obj = message_from_string(raw_email)
    email_body = ""
    if msg_obj.is_multipart():
        for payload in msg_obj.get_payload():
            email_body += payload.get_payload(decode=True).decode('utf-8', errors='ignore') if payload.get_content_type() == 'text/plain' else ""
    else:
        email_body = msg_obj.get_payload(decode=True).decode('utf-8', errors='ignore')
    return email_body

# %% 1. 내부망에서 이메일 수신
#    - 내부망의 IMAP 서버에 접속
#    - 가장 최근에 수신된 이메일을 가져옴
#    - 이메일의 본문을 추출
mail_internal = imaplib.IMAP4(IMAP_SERVER_INTERNAL, IMAP_PORT_INTERNAL)
mail_internal.login(SMTP_USERNAME_INTERNAL, SMTP_PASSWORD_INTERNAL)
mail_internal.select('inbox')
result, data = mail_internal.search(None, 'ALL')
mail_ids = data[0]
id_list = mail_ids.split()
latest_email_id = int(id_list[-1])  
result, email_data = mail_internal.fetch(str(latest_email_id), '(BODY.PEEK[])') 
raw_email = email_data[0][1]
email_body = extract_email_body(raw_email)

# %% 2. 외부망으로 이메일 전송
#    - 외부망의 SMTP 서버를 사용
#    - 추출한 이메일 본문을 외부망의 주소로 전송
smtp_external = smtplib.SMTP_SSL(SMTP_SERVER_EXTERNAL, SMTP_PORT_EXTERNAL)
smtp_external.login(SMTP_USERNAME_EXTERNAL, SMTP_PASSWORD_EXTERNAL)
msg = MIMEText(email_body, 'plain')
msg['From'] = SMTP_USERNAME_EXTERNAL
msg['To'] = SMTP_USERNAME_INTERNAL
msg['Subject'] = 'GPT-4 Query from Internal Network'
smtp_external.sendmail(SMTP_USERNAME_EXTERNAL, SMTP_USERNAME_INTERNAL, msg.as_string())
smtp_external.quit()

# %% 3. 외부망에서 이메일 수신 및 GPT-4 질의
#    - 외부망의 IMAP 서버에 접속
#    - 2단계에서 보낸 이메일을 수신
#    - 이메일의 본문을 추출
#    - 추출된 본문을 OpenAI GPT-4 모델에 질의
#    - GPT-4 모델의 응답을 저장
mail_external = imaplib.IMAP4_SSL(IMAP_SERVER_EXTERNAL, IMAP_PORT_EXTERNAL)
mail_external.login(SMTP_USERNAME_EXTERNAL, SMTP_PASSWORD_EXTERNAL)
mail_external.select('inbox')
result, data = mail_external.search(None, 'ALL')
mail_ids = data[0]
id_list = mail_ids.split()
latest_email_id = int(id_list[-1])  
result, email_data = mail_external.fetch(str(latest_email_id), '(BODY.PEEK[])') 
raw_email = email_data[0][1]
email_body = extract_email_body(raw_email)
response = openai.ChatCompletion.create(
    model="gpt-3.5-turbo",
    messages=[
        {"role": "system", "content": "You are a helpful assistant."},
        {"role": "user", "content": email_body}
    ]
)
gpt4_response = response['choices'][0]['message']['content'].strip()

# %% 4. 내부망으로 응답 이메일 전송
#    - 외부망의 SMTP 서버를 사용
#    - GPT-4 모델의 응답을 내부망의 주소로 전송
smtp_external = smtplib.SMTP_SSL(SMTP_SERVER_EXTERNAL, SMTP_PORT_EXTERNAL)
smtp_external.login(SMTP_USERNAME_EXTERNAL, SMTP_PASSWORD_EXTERNAL)
msg = MIMEText(gpt4_response, 'plain')
msg['From'] = SMTP_USERNAME_EXTERNAL
msg['To'] = SMTP_USERNAME_INTERNAL
msg['Subject'] = 'GPT-4 Response to Internal Network'
smtp_external.sendmail(SMTP_USERNAME_EXTERNAL, SMTP_USERNAME_INTERNAL, msg.as_string())
smtp_external.quit()

# %% ○ Refactored
import imaplib
import smtplib
from email.mime.text import MIMEText
from email import message_from_string
import openai
import logging

# 로깅 설정
logging.basicConfig(level=logging.INFO)

# SMTP 및 IMAP 설정
SMTP_SETTINGS = {
    "internal": {"server": 'kmail.krx.co.kr', "port": 2525, "username": 'goguma@krx.co.kr', "password": 'rnstn12!@'},
    "external": {"server": 'smtp.naver.com', "port": 465, "username": 'your_naver_email@naver.com', "password": 'your_naver_email_password'}
}
IMAP_SETTINGS = {
    "internal": {"server": 'kmail.krx.co.kr', "port": 143},
    "external": {"server": 'imap.naver.com', "port": 993}
}

# OpenAI API 설정
api_key = "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"
openai.api_key = api_key

def connect_to_email_server(server, port, username, password, server_type="IMAP"):
    try:
        if server_type == "IMAP":
            mail = imaplib.IMAP4(server, port)
        else:  # SMTP
            mail = smtplib.SMTP_SSL(server, port)
        mail.login(username, password)
        return mail
    except Exception as e:
        logging.error(f"Error connecting to {server_type} server: {e}")
        raise

def extract_email_body(raw_email):
    try:
        if isinstance(raw_email, bytes):
            raw_email = raw_email.decode('utf-8')
        msg_obj = message_from_string(raw_email)
        email_body = ""
        if msg_obj.is_multipart():
            for payload in msg_obj.get_payload():
                if payload.get_content_type() == 'text/plain':
                    email_body += payload.get_payload(decode=True).decode('utf-8', errors='ignore')
        else:
            email_body = msg_obj.get_payload(decode=True).decode('utf-8', errors='ignore')
        return email_body
    except Exception as e:
        logging.error(f"Error extracting email body: {e}")
        raise

def send_email(smtp_server, from_addr, to_addr, subject, body):
    try:
        msg = MIMEText(body, 'plain')
        msg['From'] = from_addr
        msg['To'] = to_addr
        msg['Subject'] = subject
        smtp_server.sendmail(from_addr, to_addr, msg.as_string())
    except Exception as e:
        logging.error(f"Error sending email: {e}")
        raise

def fetch_latest_email_body(mail, search_criteria='ALL'):
    try:
        mail.select('inbox')
        result, data = mail.search(None, search_criteria)
        mail_ids = data[0].split()
        latest_email_id = int(mail_ids[-1])
        result, email_data = mail.fetch(str(latest_email_id), '(BODY.PEEK[])')
        raw_email = email_data[0][1]
        return extract_email_body(raw_email)
    except Exception as e:
        logging.error(f"Error fetching latest email: {e}")
        raise

def process_gpt4_query(query):
    try:
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "You are a helpful assistant."},
                {"role": "user", "content": query}
            ]
        )
        return response['choices'][0]['message']['content'].strip()
    except Exception as e:
        logging.error(f"Error processing GPT-4 query: {e}")
        raise

# %% 1. 내부망에서 이메일 수신
#    - 내부망의 IMAP 서버에 접속
#    - 가장 최근에 수신된 이메일을 가져옴
#    - 이메일의 본문을 추출
mail_internal = connect_to_email_server(**IMAP_SETTINGS['internal'])
email_body = fetch_latest_email_body(mail_internal)

# %% 2. 외부망으로 이메일 전송
#    - 외부망의 SMTP 서버를 사용
#    - 추출한 이메일 본문을 외부망의 주소로 전송
smtp_external = connect_to_email_server(**SMTP_SETTINGS['external'], server_type="SMTP")
send_email(smtp_external, SMTP_SETTINGS['external']['username'], SMTP_SETTINGS['internal']['username'], 'GPT-4 Query from Internal Network', email_body)

# %% 3. 외부망에서 이메일 수신 및 GPT-4 질의
#    - 외부망의 IMAP 서버에 접속
#    - 2단계에서 보낸 이메일을 수신
#    - 이메일의 본문을 추출
#    - 추출된 본문을 OpenAI GPT-4 모델에 질의
#    - GPT-4 모델의 응답을 저장
mail_external = connect_to_email_server(**IMAP_SETTINGS['external'])
email_body = fetch_latest_email_body(mail_external)
gpt4_response = process_gpt4_query(email_body)

# %% 4. 내부망으로 응답 이메일 전송
#    - 외부망의 SMTP 서버를 사용
#    - GPT-4 모델의 응답을 내부망의 주소로 전송
send_email(smtp_external, SMTP_SETTINGS['external']['username'], SMTP_SETTINGS['internal']['username'], 'GPT-4 Response to Internal Network', gpt4_response)

smtp_external.quit()
