
# %% (0) Working Directory
import os
import zipfile
import requests
import re
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import SessionNotCreatedException
from bs4 import BeautifulSoup
import pandas as pd
import time
from time import sleep

start_date = '20230101'
end_date = '20230331'
filePath = 'C:\\Users\\KRX\\Desktop\\201021'

def createAndSetWorkingDir(directory):
    # chrome_version = "118.0.5993.70"
    chrome_version = "119.0.6045.105"
    if not os.path.exists(directory):
        os.makedirs(directory)
    os.chdir(directory)
    print(f"Current working directory is now set to: {os.getcwd()}")

createAndSetWorkingDir(filePath)

def download_chromedriver(chrome_version):
    zip_path = os.path.join(filePath, "chromedriver.zip")
    extract_folder = os.path.join(filePath, "chromedriver-win32")

    url = f"https://edgedl.me.gvt1.com/edgedl/chrome/chrome-for-testing/{chrome_version}/win32/chromedriver-win32.zip"
    response = requests.get(url, stream=True)
    if response.status_code != 200:
        raise Exception(f"Failed to download ChromeDriver for version {chrome_version}. Status code: {response.status_code}")

    with open(zip_path, "wb") as f:
        for chunk in response.iter_content(chunk_size=8192):
            f.write(chunk)

    print("Starting to unzip the chromedriver...")
    with zipfile.ZipFile(zip_path, 'r') as zip_ref:
        zip_ref.extractall(extract_folder)
    print("Unzipping completed.")

    chromedriver_exe_path = os.path.join(extract_folder, "chromedriver.exe")

    # Change the working directory to the extracted folder
    os.chdir(extract_folder)
    print(f"Working directory changed to: {os.getcwd()}")

    if os.path.exists(chromedriver_exe_path):
        return chromedriver_exe_path
    else:
        raise FileNotFoundError(f"'chromedriver.exe' was not found in the extracted directory: {extract_folder}")

try:
    # chrome_v = "118.0.5993.70"
    chrome_v = "119.0.6045.105"
    print(f"Expected Chrome version: {chrome_v}")
    chromedriver_path = download_chromedriver(chrome_v)
    print(f"Downloaded ChromeDriver path: {chromedriver_path}")
    
    options = webdriver.ChromeOptions()
    options.binary_location = r"C:\Program Files\Google\Chrome\Application\chrome.exe"
    service = Service(executable_path=chromedriver_path)
    driver = webdriver.Chrome(service=service, options=options)
    driver.get("https://www.google.com")
    driver.quit()

except SessionNotCreatedException as e:
    print(f"Error encountered: {str(e)}")
    match = re.search(r"Chrome version (\d+\.\d+\.\d+)", str(e))
    if match:
        chrome_version_detected = match.group(1)
        print(f"Detected Chrome version from error: {chrome_version_detected}")
        try:
            chromedriver_path = download_chromedriver(chrome_version_detected)
            print(f"Downloaded ChromeDriver path for detected version: {chromedriver_path}")
            
            options = webdriver.ChromeOptions()
            options.binary_location = r"C:\Program Files\Google\Chrome\Application\chrome.exe"
            service = Service(executable_path=chromedriver_path)
            driver = webdriver.Chrome(service=service, options=options)
            driver.get("https://www.google.com")
            driver.quit()
        except Exception as ex:
            print(f"Error while trying to download ChromeDriver for detected version: {ex}")

# %% (1)-(1) Session : Not working → login input 用
"""
○ Validating XPath Selectors in the browser (chrome Dev Tools)
$x("//html");
 ex) $x("//#contents > div.login-wrap > div > form > div:nth-child(1) > div > div > input")
document.querySelectorAll("<YOUR_CSS_SELECTOR>")
 ex) document.querySelectorAll("//#contents > div.login-wrap > div > form > div:nth-child(1) > div > div > input")
"""
from selenium.webdriver.common.action_chains import ActionChains
from selenium.common.exceptions import NoSuchElementException

app_id = 'goguma@krx.co.kr'
app_pw = "wkrwjs12!@"

dr = webdriver.Chrome()
dr.set_window_size(1200, 2400)  # 웹창 크기 지정
dr.get('https://dataservice.koscom.co.kr/login?returnUrl=/krx/approval-list')  
dr.maximize_window()
dr.implicitly_wait(10)  # 창이 뜰때까지 기다림

def ilogin():
    # 요소 지정
    try : 
        id_box = dr.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[1]/div/div/input')   # ID입력창
        password_box = dr.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[2]/div/div/input') # password 입력창
        login_button = dr.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[3]/button')  # 로그인 버튼
    
        # 동작 실행하기
        act = ActionChains(dr) # 동작 실행 코드 지정
    
        id = app_id    # 아이디 입력받기
        password = app_pw    # 비밀번호 입력받기
        act.send_keys_to_element(id_box, '{}'.format(id)).send_keys_to_element(password_box, '{}'.format(password)).click(login_button).perform()    
        time.sleep(3)
        
    except NoSuchElementException as e : 
        """
         - if already login-ed
        """
        dr.get('https://dataservice.koscom.co.kr/krx/approval-list')  
        dr.maximize_window()
        dr.implicitly_wait(10)  # 창이 뜰때까지 기다림
        
    
# 테스트 코드
ilogin()

# %% (1)-(2) Check iframes 
# What iframes exist : Not working 
# iframes = dr.find_element(By.CSS_SELECTOR, 'iframe')
# for iframe in iframes:
#     print(iframe.get_attribute('name'))

# %% (2) Table iter 
# %% (2)-(1) For iter
# ○ [파이썬] 웹에서 자료실 파일 다운로드하는 크롤러 만들기 : https://calmlife.tistory.com/5
"""
 - Case 1 : One Table
     <사전확인>
    - ver1. ex)
   ☞ 
   
   - ver2.-표1 ex) https://dataservice.koscom.co.kr/krx/100562/approval-detail (알파프라임)
   ☞ //*[@id="contents"]/div[5]/div[2]/div[1]/table/tbody/tr[1]/td[1] (OK)
    - ver2.-표2 ex) https://dataservice.koscom.co.kr/krx/100562/approval-detail (알파프라임)
    ☞ //*[@id="contents"]/div[5]/div[2]/div[1]/div[3]/table/tbody/tr[1]/td[1] (error)
   
     <해지> 
     - ver1. ex) 
    ☞ 
    
     - ver2. ex) https://dataservice.koscom.co.kr/krx/100574/approval-detail  
    ☞ //*[@id="contents"]/div[5]/div[2]/div[1]/div[1]/table/tbody/tr[1]/td[1] (Error) ▶ (a)
    
 - Case 2 : Two Table 
 - Case 3 : No Table ex) https://dataservice.koscom.co.kr/krx/100568/approval-detail
 - Case 4 : Error such like (a)
     
 -주석 有 (Case 1+2) ex) https://dataservice.koscom.co.kr/krx/100562/approval-detail
    <1번째>
    ☞ (하나만 있는 경우) //*[@id="contents"]/div[5]/div[2]/div[1]/div
    ☞ //*[@id="contents"]/div[5]/div[2]/div[1]/div[1]
    ☞ //*[@id="contents"]/div[5]/div[2]/div[1]/div[2]
    ☞ (새끼) //*[@id="contents"]/div[5]/div[2]/p[2]/span
    #contents > div.post-view.basic > div.cnts > p:nth-child(3) > span
    
    <2번째>
    ☞ //*[@id="contents"]/div[5]/div[2]/div[1]/div[4]
    //*[@id="contents"]/div[5]/div[2]/div[1]/div[2]
    
    
"""
from itertools import product

num = 100579


def Table_iter(num) :
    case_4 = []
    url = "https://dataservice.koscom.co.kr/krx/" + str(num) + "/approval-detail" # 100579 will be converted to parameter
    dr.get(url)
    dr.maximize_window()
    
    ######################### subject ######################### 
    time.sleep(5) # For Loading 
    wts_sub = dr.find_element(By.XPATH, '//*[@id="contents"]/div[5]/div[1]/span') # title
    wts_sub = wts_sub.text[15:][:len(wts_sub.text)-8] 
    
    #=========================================================================
    ######################### content ↓ ######################### 
    
    ######################### Case 1 ######################### 
    #=========================================================================
    Max_rows = 20
    Rg = range(1, Max_rows)  
    Rg_col = range(1, 7) # fixed
    
    full_list = [] # will be used to make DF 
    for i, j in product(Rg, Rg_col) :
        try : 
            wts = dr.find_element(By.XPATH, '//*[@id="contents"]/div[5]/div[2]/div[1]/table/tbody/tr[' + str(i) + ']/td[' + str(j) +']') 
            if wts.text[0:2] == "구분" :
                print("Shit!!! Case4")
                case_4.append(wts_sub)
                break
                            
            full_list.append(wts.text)
        except NoSuchElementException as e:
            print("Not Enough Time Or End of the table")
            break
    
    # 주석 前 합계 줄에 " " 1개 추가 
    try : 
        full_list.append(" ")
    except : 
        pass
    
    #=========================================================================
    # ---------------------- 주석(Case 1) ---------------------- 
    #=========================================================================
    Max_rows_note = 8
    Rg_note = range(1, Max_rows_note)
    
    """
    # 주석 하나만 있을 경우에도 필요치 X (`23.2.7 17:46)
    try : 
        wts = dr.find_element(By.XPATH, '//*[@id="contents"]/div[5]/div[2]/div[1]/div') 
        print(wts.text)
        full_list.append("주석")
        full_list.append(wts.text)
        full_list.extend(["-" for i in range(1, 5)])
    except NoSuchElementException as e:
        print("Multiple notes")
    """
    
    for i in Rg_note :
        try : 
            wts = dr.find_element(By.XPATH, '//*[@id="contents"]/div[5]/div[2]/div[1]/div[' + str(i) + ']')                                    
            if wts.text[0:2] == "구분" :
                print("Shit!!! Case4")
                case_4.append(wts_sub)
                break
                                
            full_list.append("주석")
            full_list.append(wts.text)
            full_list.extend(["-" for i in range(1, 5)]) # # of No data ← 4

        except NoSuchElementException as e:
            print("Only one note OR No more notes")
            break    
    
    for i in Rg_note :
        try : 
            wts = dr.find_element(By.XPATH, '//*[@id="contents"]/div[5]/div[2]/p[' + str(i) + ']/span')           
            if wts.text[0:2] == "구분" :
                print("Shit!!! Case4")
                case_4.append(wts_sub)
                break
            
            full_list.append("주석")                    
            full_list.append(wts.text)
            full_list.extend([" " for i in range(1, 5)]) # # of No data ← 4

        except NoSuchElementException as e:
            print("Only one note OR No more notes")
            break    
    
    #=========================================================================
    #=========================================================================
    ######################### Case 2 ######################### 
    #=========================================================================
    #=========================================================================
    for i, j in product(Rg, Rg_col) :
        try : 
            wts = dr.find_element(By.XPATH, '//*[@id="contents"]/div[5]/div[2]/div[1]/div[3]/table/tbody/tr[' + str(i) + ']/td[' + str(j) + ']') 
            if wts.text[0:2] == "구분" :
                print("Shit!!! Case4")
                case_4.append(wts_sub)
                break
                                
            full_list.append(wts.text)
        except NoSuchElementException as e:
            print("Not Enough Time \ Or End of the table")
            break

    # 주석 前 합계 줄에 " " 1개 추가 
    try : 
        full_list.append(" ")
    except : 
        pass
        
    # ---------------------- 주석(Case 2) ---------------------- 
    # should be edited (multiple notes) - wts link 
    for i in Rg_note :
        try : 
            wts = dr.find_element(By.XPATH, '//*[@id="contents"]/div[5]/div[2]/div[' + str(i) + ']/div[4]')                            
            if wts.text[0:2] == "구분" :
                print("Shit!!! Case4")
                case_4.append(wts_sub)
                break
                                
            full_list.append("주석")
            full_list.append(wts.text)
            full_list.extend(["-" for i in range(1, 5)]) # # of No data ← 4

        except NoSuchElementException as e:
            print("Only one note OR No more notes")
            break    
            
    #=========================================================================
    #=========================================================================
    ######################### DataFrame 作 ######################### 
    #=========================================================================
    #=========================================================================
    """
     - list → 6개 단위로 df 作
    """
    try :
        # at the last of the df → # of firms
        full_list_temp = ["-" for i in range(1, 6)]
        full_list_temp.extend(full_list)
        full_list = full_list_temp.copy()
        full_list.insert(0, wts_sub)
        
        # full_list.append(wts_sub) 
        # full_list.extend(["-" for i in range(1, 6)])
        
        n = 6 # # of columns 
        full_list_c = [full_list[i * n:(i+1) * n] for i in range(len(full_list) + n-1 // n)]
        
        full_list_c_last = [i for i in full_list_c if i != []] # error (공란 있을 시)
        # full_list_c_last_except = full_list_c_last[0:len(full_list_c_last) - 1] # omited(`23.2.8 01:56)
        full_list_c_last_except = full_list_c_last
        
        # print(full_list_c_last_except)
        
        # Making DF 
        columns = ["구분", "상품명", "화폐단위", "이용료(월)", "제공방식",
                    "계약 효력일"]
        # columns = ["col_1", "col_2", "col_3", "col_4", "col_5",
        #             "col_6"]
        
        df = pd.DataFrame(full_list_c_last_except)
        
        # change columns index 
        col = df.columns.to_numpy()
        # col = col[[5, 0, 1, 2, 3, 4]]
        df = df[col]
        
        df.columns = columns
        # print(full_list_c_last_except)
        print(wts_sub)
        df.to_csv(wts_sub + "_" + str(num) + ".csv", encoding = "euc-kr")
    
        

    ######################### Case 3 ######################### 
    except ValueError as e:
        Case_3_list = []
        Rg = range(1, Max_rows) 
        for i in Rg :    
            try : 
                wts = dr.find_element(By.XPATH, '//*[@id="contents"]/div[5]/div[2]/div[' + str(i) + ']/span') 
                Case_3_list.append(wts.text)
                df = pd.DataFrame(Case_3_list)
                df.to_csv(wts_sub + "_" + str(num) + ".csv", encoding = "euc-kr")
            except : 
                pass

    print(num)
    return(case_4)
        
# %% Edit
start = 100562 # 100562, 100574
end = 100562
case_4_result = [] # Case 4 → 예외 처리
for i in range(start, end+1) :
    TI = Table_iter(i)   
    case_4_result.append(TI)

# %% Iter_result
start = 100171 # 100562, 100574 
# end = 100596
end = 100172
case_4_result = [] # Case 4 → 예외 처리
case_4_result_i = []
result_error = []

for i in range(start, end+1) :
    try : 
        TI = Table_iter(i)           
        case_4_result.append(TI)
        if TI != [] :
            case_4_result_i.append(i)
    except NoSuchElementException as e :
        result_error.append(i)
        
    
    
# %% (3) download attachment 
from selenium import webdriver
import time
import pyautogui as pag
import pyperclip as py
import keyboard
from selenium import webdriver
from selenium.webdriver.common.keys import Keys

"""
 - It can be useful :
     chrome_options.add_experimental_option("prefs",{'download.prompt_for_download': True})

 - Case 1 : ∃ 계약서류, 추가 첨부파일
    - ver1. ex) https://dataservice.koscom.co.kr/krx/100617/approval-detail
   * 주문서 : //*[@id="contents"]/div[3]/dl[3]/dd[1]/a/span[2] 
    ☞ print_dialog_first
    
   * 요약본 : //*[@id="contents"]/div[3]/dl[3]/dd[2]/a/span[2]
    ☞ print_dialog_first
    
   * 이용조건 : //*[@id="contents"]/div[3]/dl[4]/dd[1]/a/span[2]
   ☞ just click
   
   * 계약조건 : //*[@id="contents"]/div[3]/dl[4]/dd[2]/a/span[2]
   ☞ just click
   
   * 추가첨부_1 : //*[@id="contents"]/div[5]/dl[1]/dd/ul/li[1]/a/span[2]
   ☞ just click
   
   * 추가첨부_2 : //*[@id="contents"]/div[5]/dl[1]/dd/ul/li[2]/a/span[2]
   ☞ just click
   
"""
######################### Setting : should be excecuted #########################
def print_dialog_first(title, sub_title, driver):
    time.sleep(2)
    pag.press('enter') # "Print" Button     
    time.sleep(2)
    
    # Type subject 
    py.copy(title + "_" + sub_title) # copy to clipboard (Korean not supported in pag.typewrite)
    pag.hotkey('ctrl', 'v') 
    pag.press('enter') # "Print" Button     
    
    time.sleep(2) # For Loading 
    # ==========# It is "NO" for duplicated files(For safety, twice)==========
    keyboard.send("esc") 
    time.sleep(2) # For Loading 
    keyboard.send("Enter")
    time.sleep(1) # For Loading 
    
    keyboard.send("esc") 
    time.sleep(2) # For Loading 
    keyboard.send("Enter")
    time.sleep(1) # For Loading 
    
    # ====================# It is for click the "X"====================
    # dr.switch_to.window(dr.currnet_window_handle)
    webdriver.ActionChains(dr).send_keys(Keys.ESCAPE).perform()
    keyboard.send("esc") 
    time.sleep(2) # For Loading 
    keyboard.send("Enter")
    time.sleep(1) # For Loading 
    
    dr.switch_to.window(dr.currnet_window_handle)
    keyboard.send("esc") 
    time.sleep(2) # For Loading 
    keyboard.send("Enter")
    time.sleep(1) # For Loading 

def just_save_dialog_first(title, sub_title, driver):
    """
     - IF ∃ 2 or more files → More "enter" is needed (up to 4 files)
    """
    time.sleep(2)
    pag.press('enter') # "Print" Button     
    time.sleep(2)
    pag.press('enter') # "Print" Button     
    time.sleep(2)
    pag.press('enter') # "Print" Button     
    time.sleep(2)
    pag.press('enter') # "Print" Button     
    time.sleep(2)
    
    # # Type subject 
    # py.copy(title + "_" + sub_title) # copy to clipboard (Korean not supported in pag.typewrite)
    # pag.hotkey('ctrl', 'v') 
    # pag.press('enter') # "Print" Button     
    
    time.sleep(2) # For Loading 
    
    # ==========# It is "NO" for duplicated files(For safety, twice)==========
    # keyboard.send("esc") 
    # time.sleep(2) # For Loading 
    # keyboard.send("Enter")
    # time.sleep(2) # For Loading 
        
    # keyboard.send("esc") 
    # time.sleep(2) # For Loading 
    # keyboard.send("Enter")
    # time.sleep(2) # For Loading 


url = "https://dataservice.koscom.co.kr/krx/100617/approval-detail"
dr.get(url)
dr.maximize_window()
time.sleep(5)

######################### title & date #########################
"""
# title ← Same as wts_sub
"""

title = dr.find_element(By.XPATH, '//*[@id="contents"]/div[5]/div[1]/span') # title
title = title.text[15:][:len(title.text)-8] 

date = dr.find_element(By.XPATH, '//*[@id="contents"]/div[3]/dl[2]/dd[2]') # date
date = date.text

######################### attachment & def #########################
""" Example code
attach_1 = dr.find_element(By.XPATH, '//*[@id="contents"]/div[3]/dl[3]/dd[1]/a/span[2]') # 주문서
attach_1.click()

time.sleep(5) # For Loading 
print_dialog_first(title = title, sub_title = "주문서" + "(" + date + ")")
"""

######################### Iteration #########################
sub_name_dict = {
    "주문서" : '//*[@id="contents"]/div[3]/dl[3]/dd[1]/a/span[2]', 
    "요약본" : '//*[@id="contents"]/div[3]/dl[3]/dd[2]/a/span[2]',
    "이용조건" : '//*[@id="contents"]/div[3]/dl[4]/dd[1]/a/span[2]', 
    "계약조건" : '//*[@id="contents"]/div[3]/dl[4]/dd[2]/a/span[2]', 
    "추가첨부_1" : '//*[@id="contents"]/div[5]/dl[1]/dd/ul/li[1]/a/span[2]', 
    "추가첨부_2" : '//*[@id="contents"]/div[5]/dl[1]/dd/ul/li[2]/a/span[2]'
    }
"""
 - `23.3.2 : 문제 發 - esc 문제는 해결되었으나, 현재 중복 다운로드 등 문제 상존 
"""
for i, (sub_title, xpath) in enumerate(sub_name_dict.items()) : 
    if i <= 1 : 
        try : 
            time.sleep(5) # For Loading 
            attach = dr.find_element(By.XPATH, xpath) # 주문서, 요약본 ... 
            
            time.sleep(2) # For Loading 
            keyboard.send("esc") # pag.press('Esc') is not working / and sometimes keyboard.send not work 
            
            # time.sleep(2) # For Loading 
            # keyboard.send("esc") # pag.press('Esc') is not working
            
            attach.click()
            
            time.sleep(5) # For Loading 
            print_dialog_first(title = title, sub_title = sub_title + "(" + date + ")", driver = dr)
            # pag.press(pag.KEYBOARD_KEYS["esc"])
            # pag.press(pag.KEYBOARD_KEYS["esc"])
            # pag.press('esc') 
        except : 
            pass
        
    else : 
        try : 
            time.sleep(5) # For Loading 
            attach = dr.find_element(By.XPATH, xpath) # 이용조건, 계약조건 ... 
            attach.click()
            just_save_dialog_first(title = title, sub_title = sub_title + "(" + date + ")", driver = dr)
        except : 
            pass
# =============================================================================
# =============================================================================
# # ↑ `23.4. 작업본 ↓ `23.11 작업본
# =============================================================================
# =============================================================================
# %% 231101 웹사이트로부터 상품 정보 및 주석 데이터 추출하기 (표 1개 / 2개 모두 Working)
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.action_chains import ActionChains
from selenium.common.exceptions import NoSuchElementException
import time
import pandas as pd

def login(driver, app_id, app_pw):
    try:
        id_box = driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[1]/div/div/input')
        password_box = driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[2]/div/div/input')
        login_button = driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[3]/button')
        
        act = ActionChains(driver)
        act.send_keys_to_element(id_box, app_id).send_keys_to_element(password_box, app_pw).click(login_button).perform()
        time.sleep(3)
    except NoSuchElementException:
        driver.get('https://dataservice.koscom.co.kr/krx/approval-list')
        driver.maximize_window()
        driver.implicitly_wait(10)

def table_iter(num, driver):
    base_url = f"https://dataservice.koscom.co.kr/krx/{num}/approval-detail"
    driver.get(base_url)

    # 페이지에서 모든 행을 기다림
    WebDriverWait(driver, 10).until(
        EC.presence_of_all_elements_located((By.CSS_SELECTOR, 'table > tbody > tr'))
    )
    
    # 테이블의 모든 행(row)를 가져옴
    rows = driver.find_elements(By.CSS_SELECTOR, 'table > tbody > tr')
    result = []
    for row in rows:
        cells = row.find_elements(By.CSS_SELECTOR, 'td')
        result.append([cell.text for cell in cells])
    
    # 페이지에서 주석이 포함된 모든 div를 기다림
    WebDriverWait(driver, 10).until(
        EC.presence_of_all_elements_located((By.XPATH, "//div[contains(@style, 'margin-top:') and contains(text(), '주')]"))
    )
    
    # 노트(주석)을 가져옴
    notes = driver.find_elements(By.XPATH, "//div[contains(@style, 'margin-top:') and contains(text(), '주')]")
    notes_text = [note.text for note in notes]

    return result, notes_text

def convert_to_dataframes(data_list, notes_list):
    headers = ["구분", "상품명", "화폐단위", "이용료(월)", "제공방식", "계약 효력일"]
    df = pd.DataFrame(data_list, columns=headers)
    notes_df = pd.DataFrame(notes_list, columns=["Notes"])
    return df, notes_df

app_id = 'goguma@krx.co.kr'
app_pw = "wkrwjs12!@"

driver = webdriver.Chrome()
driver.set_window_size(1200, 2400)
driver.get('https://dataservice.koscom.co.kr/login?returnUrl=/krx/approval-list')
driver.maximize_window()
driver.implicitly_wait(10)

# Login
login(driver, app_id, app_pw)

# Extract data
num = 100562 # Example number, it can be different
data_result, notes_result = table_iter(num, driver)

# Convert the data to DataFrame
data_df, notes_df = convert_to_dataframes(data_result, notes_result)

# Display the data
print(data_df)
print(notes_df)

# Make sure to quit the driver after your scraping job is done
# driver.quit()

# %% 231102 셀레니움을 이용한 웹사이트 로그인 및 다운로드 링크 클릭 로깅 (다운로드 링크(3) Error)
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import NoSuchElementException
import pandas as pd
import time
import pyautogui
import keyboard

def login(driver, app_id, app_pw):
    # 로그인 시도 전 로그 출력
    print("[INFO] 로그인을 시도합니다.")
    id_box = driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[1]/div/div/input')
    password_box = driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[2]/div/div/input')
    login_button = driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[3]/button')
    
    act = ActionChains(driver)
    act.send_keys_to_element(id_box, app_id).send_keys_to_element(password_box, app_pw).click(login_button).perform()
    time.sleep(3)

def table_iter(num, driver):
    # 상세 페이지 이동 전 로그 출력
    print(f"[INFO] 상세 페이지로 이동합니다: {num}")
    base_url = f"https://dataservice.koscom.co.kr/krx/{num}/approval-detail"
    driver.get(base_url)

    WebDriverWait(driver, 10).until(
        EC.presence_of_all_elements_located((By.CSS_SELECTOR, 'table > tbody > tr'))
    )
    
    rows = driver.find_elements(By.CSS_SELECTOR, 'table > tbody > tr')
    result = []
    for row in rows:
        cells = row.find_elements(By.CSS_SELECTOR, 'td')
        result.append([cell.text for cell in cells])
    
    WebDriverWait(driver, 10).until(
        EC.presence_of_all_elements_located((By.XPATH, "//div[contains(@style, 'margin-top:') and contains(text(), '주')]"))
    )
    
    notes = driver.find_elements(By.XPATH, "//div[contains(@style, 'margin-top:') and contains(text(), '주')]")
    notes_text = [note.text for note in notes]

    return result, notes_text

def convert_to_dataframes(data_list, notes_list):
    # 데이터프레임 변환 전 로그 출력
    print("[INFO] 데이터를 데이터프레임으로 변환합니다.")
    headers = ["구분", "상품명", "화폐단위", "이용료(월)", "제공방식", "계약 효력일"]
    df = pd.DataFrame(data_list, columns=headers)
    notes_df = pd.DataFrame(notes_list, columns=["Notes"])
    return df, notes_df

def handle_print_dialog():
    # 인쇄 대화 상자 처리 전 로그 출력
    print("[INFO] 인쇄 대화 상자를 처리합니다.")
    time.sleep(2)
    pyautogui.press('enter')  # "Print" Button
    time.sleep(2)
    pyautogui.hotkey('ctrl', 'v') 
    pyautogui.press('enter')  # "Print" Button
    time.sleep(2)
    keyboard.send("esc")
    time.sleep(2)
    keyboard.send("enter")
    time.sleep(1)
    keyboard.send("esc")

# capabilities = DesiredCapabilities.CHROME
# capabilities['goog:loggingPrefs'] = {'browser': 'ALL'}

# driver = webdriver.Chrome(desired_capabilities=capabilities)
# driver = webdriver.Chrome()
# ChromeOptions 인스턴스 생성
chrome_options = webdriver.ChromeOptions()

# 로거 설정 추가
chrome_options.set_capability('goog:loggingPrefs', {'browser': 'ALL'})

# Chrome 드라이버 인스턴스 생성
driver = webdriver.Chrome(options=chrome_options)

app_id = 'goguma@krx.co.kr'
app_pw = "wkrwjs12!@"

driver.set_window_size(1200, 2400)
driver.get('https://dataservice.koscom.co.kr/login?returnUrl=/krx/approval-list')
driver.maximize_window()
driver.implicitly_wait(10)

login(driver, app_id, app_pw)

num = 100562  # Example number, adjust for actual use
data_result, notes_result = table_iter(num, driver)

data_df, notes_df = convert_to_dataframes(data_result, notes_result)

print(data_df)
print(notes_df)

print("[INFO] 다운로드 링크를 클릭합니다.")
download_links = driver.find_elements(By.CSS_SELECTOR, 'a.file-link[download]')
for index, link in enumerate(download_links):
    link_text = link.find_element(By.XPATH, ".//span[contains(@class, 'name')]").text
    try:
        if "이용조건" not in link_text:
            print(f"[INFO] 다운로드 링크 ({index}) 클릭.")
            driver.execute_script("arguments[0].click();", link)
            handle_print_dialog()  # 이용조건이 아닌 링크에 대해 인쇄 대화 상자 처리
        else:
            print(f"[INFO] '이용조건' 다운로드 링크 클릭, 별도의 인쇄 대화 상자 처리를 생략합니다.")
            driver.execute_script("arguments[0].click();", link)
            # '이용조건' 링크의 경우 별도의 처리가 필요없으므로 대기만 합니다.
            time.sleep(5)  # 다운로드가 시작되기를 기다립니다.
    except Exception as e:
        print(f"[ERROR] 다운로드 링크 클릭 오류: {e}")

# 브라우저 로그 출력
# print("[INFO] 브라우저 로그를 수집합니다.")
# logs = driver.get_log('browser')
# for log in logs:
#     print(log)

# driver.quit()


# driver.quit()

# %% 231104 Saction_id 미반영
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException
import time
import warnings
from urllib3.exceptions import InsecureRequestWarning

# HTTPS 요청에 대한 경고를 비활성화
warnings.simplefilter('ignore', InsecureRequestWarning)


# 로그인 함수
def login(driver, app_id, app_pw):
    # 로그인 시도 전 로그 출력
    print("[INFO] 로그인을 시도합니다.")
    id_box = driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[1]/div/div/input')
    password_box = driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[2]/div/div/input')
    login_button = driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[3]/button')
    
    act = ActionChains(driver)
    act.send_keys_to_element(id_box, app_id).send_keys_to_element(password_box, app_pw).click(login_button).perform()
    time.sleep(3)

# 메인 실행 코드
if __name__ == "__main__":
    # 웹 드라이버 설정 (Selenium Wire를 사용하는 부분을 제거했습니다)
    driver = webdriver.Chrome()
    driver.maximize_window()

    try:
        login(driver, 'goguma@krx.co.kr', 'wkrwjs12!@')
        time.sleep(5)  # 로그인 후 리다이렉트 대기
        driver.get('https://dataservice.koscom.co.kr/krx/approval-list')

        # Waiting for the table rows to be visible
        WebDriverWait(driver, 20).until(
            EC.visibility_of_all_elements_located((By.CSS_SELECTOR, 'tbody .el-table__row'))
        )

        # Assuming the document number is located in the fifth column (el-table_1_column_5)
        document_cells = driver.find_elements(By.CSS_SELECTOR, 'tbody .el-table__row .el-table_1_column_5 .cell')

        detail_urls = [
            f"https://dataservice.koscom.co.kr/krx/{cell.text.strip()}/approval-detail"
            for cell in document_cells if cell.text.strip() != ''
        ]

        for url in detail_urls:
            # HEAD 요청을 보내어 실제 URL을 얻습니다.
            response = requests.head(url, allow_redirects=True, verify=False)
            actual_url = response.url  # 리디렉트 된 후의 최종 URL
            print(actual_url)

    except TimeoutException:
        print("[ERROR] 페이지 로딩 시간 초과")
    finally:
        driver.quit()


# %% 231103
from seleniumwire import webdriver  # Import from seleniumwire
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.action_chains import ActionChains
from selenium.common.exceptions import NoSuchElementException, TimeoutException
import time
import pandas as pd

def login(driver, app_id, app_pw):
    try:
        driver.get('https://dataservice.koscom.co.kr/login?returnUrl=/krx/approval-list')
        WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[1]/div/div/input')))
        
        id_box = driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[1]/div/div/input')
        password_box = driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[2]/div/div/input')
        login_button = driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[3]/button')
        
        actions = ActionChains(driver)
        actions.send_keys_to_element(id_box, app_id)
        actions.send_keys_to_element(password_box, app_pw)
        actions.click(login_button)
        actions.perform()
        
        WebDriverWait(driver, 10).until(EC.url_to_be('https://dataservice.koscom.co.kr/krx/approval-list'))
        
    except NoSuchElementException as e:
        print("[ERROR] One of the login elements could not be found.", e)
        driver.quit()
    except TimeoutException as e:
        print("[ERROR] Timeout occurred during login.", e)

def extract_data(driver, num):
    base_url = f"https://dataservice.koscom.co.kr/krx/{num}/approval-detail"
    driver.get(base_url)

    WebDriverWait(driver, 10).until(
        EC.presence_of_all_elements_located((By.CSS_SELECTOR, 'table > tbody > tr'))
    )

    rows = driver.find_elements(By.CSS_SELECTOR, 'table > tbody > tr')
    result = []
    for row in rows:
        cells = row.find_elements(By.CSS_SELECTOR, 'td')
        result.append([cell.text for cell in cells])

    WebDriverWait(driver, 10).until(
        EC.presence_of_all_elements_located((By.XPATH, "//div[contains(@style, 'margin-top:') and contains(text(), '주')]"))
    )

    notes = driver.find_elements(By.XPATH, "//div[contains(@style, 'margin-top:') and contains(text(), '주')]")
    notes_text = [note.text for note in notes]

    return result, notes_text

def convert_to_dataframes(data_list, notes_list):
    headers = ["구분", "상품명", "화폐단위", "이용료(월)", "제공방식", "계약 효력일"]
    df = pd.DataFrame(data_list, columns=headers)
    notes_df = pd.DataFrame(notes_list, columns=["Notes"])
    return df, notes_df

# 메인 실행 코드
if __name__ == "__main__":
    seleniumwire_options = {
        'connection_timeout': None,
        'verify_ssl': False,
    }

    driver = webdriver.Chrome(seleniumwire_options=seleniumwire_options)

    try:
        # Login
        login(driver, 'goguma@krx.co.kr', 'wkrwjs12!@')

        # Extract data
        num = 100562 # Example number, replace with actual value if necessary
        data_result, notes_result = extract_data(driver, num)

        # Convert the data to DataFrame
        data_df, notes_df = convert_to_dataframes(data_result, notes_result)

        # Display the data
        print(data_df)
        print(notes_df)

    except Exception as e:
        print("[ERROR] An error occurred:", e)
    finally:
        driver.quit()

# %% 231105 1220 웹사이트 로그인 및 동적 JSON 데이터 추출 자동화 스크립트
from seleniumwire import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import pandas as pd
import json
import time
import gzip
import os
import traceback

# 로그인 함수
def login(driver, app_id, app_pw):
    print("[INFO] 로그인을 시도합니다.")
    driver.get('https://dataservice.koscom.co.kr/login?returnUrl=/krx/approval-list')
    WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[1]/div/div/input')))
    id_box = driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[1]/div/div/input')
    password_box = driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[2]/div/div/input')
    login_button = driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[3]/button')
    id_box.send_keys(app_id)
    password_box.send_keys(app_pw)
    login_button.click()
    WebDriverWait(driver, 10).until(EC.url_to_be('https://dataservice.koscom.co.kr/krx/approval-list'))

# 데이터 추출 함수
def table_iter(num, driver):
    print(f"[INFO] 상세 페이지로 이동합니다: {num}")
    base_url = f"https://dataservice.koscom.co.kr/krx/{num}/approval-detail"
    driver.get(base_url)
    WebDriverWait(driver, 10).until(EC.presence_of_all_elements_located((By.CSS_SELECTOR, 'table > tbody > tr')))
    rows = driver.find_elements(By.CSS_SELECTOR, 'table > tbody > tr')
    result = [[cell.text for cell in row.find_elements(By.CSS_SELECTOR, 'td')] for row in rows]
    WebDriverWait(driver, 10).until(EC.presence_of_all_elements_located((By.XPATH, "//div[contains(@style, 'margin-top:') and contains(text(), '주')]")))
    notes = [note.text for note in driver.find_elements(By.XPATH, "//div[contains(@style, 'margin-top:') and contains(text(), '주')]")]
    return result, notes

# 데이터를 DataFrame으로 변환하는 함수
def convert_to_dataframes(data_list, notes_list):
    headers = ["구분", "상품명", "화폐단위", "이용료(월)", "제공방식", "계약 효력일"]
    df = pd.DataFrame(data_list, columns=headers)
    notes_df = pd.DataFrame(notes_list, columns=["Notes"])
    return df, notes_df

# JSON 데이터를 파일에 저장하는 함수
def save_json_to_file(data, filename):
    with open(filename, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=4)

# 메인 실행 코드입니다.
if __name__ == "__main__":
    seleniumwire_options = {
        'connection_timeout': None,
        'verify_ssl': False,
    }
    driver = webdriver.Chrome(seleniumwire_options=seleniumwire_options)

    try:
        login(driver, 'goguma@krx.co.kr', 'wkrwjs12!@')

        # 데이터 추출
        num = '100562'
        data_result, notes_result = table_iter(num, driver)
        data_df, notes_df = convert_to_dataframes(data_result, notes_result)

        # 클릭할 다운로드 버튼 요소를 찾습니다.
        download_link = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, '.iconset.icon-down-attach'))
        )
        download_link.click()  # 요소를 클릭합니다.

        # 클릭 후에 발생하는 요청을 필터링합니다.
        time.sleep(3)  # 네트워크 트래픽을 기다립니다.
        json_responses = []
        for request in driver.requests:
            if request.response and 'application/json' in request.response.headers.get('Content-Type', ''):
                print(f"요청 URL: {request.url}")
                print(f"응답 코드: {request.response.status_code}")
                content_encoding = request.response.headers.get('Content-Encoding', '')
                if 'gzip' in content_encoding:
                    json_data = gzip.decompress(request.response.body).decode('utf-8')
                else:
                    json_data = request.response.body.decode('utf-8')
                
                # JSON 데이터를 파이썬 객체로 변환하고 리스트에 추가합니다.
                json_obj = json.loads(json_data)
                # 요청 URL을 JSON 객체에 추가합니다.
                # 만약 json_obj가 리스트 형태라면 각 항목에 URL을 추가해야 합니다.
                if isinstance(json_obj, list):
                    for item in json_obj:
                        if isinstance(item, dict):
                            item['request_url'] = request.url
                    json_responses.extend(json_obj)
                else:
                    json_obj['request_url'] = request.url
                    json_responses.append(json_obj)

        # JSON 데이터를 파일에 저장합니다.
        save_json_to_file(json_responses, 'output.json')
        
        # 파일에서 DataFrame으로 변환합니다.
        # DataFrame 생성 전에 json_responses 내부의 모든 원소가 딕셔너리 형인지 확인합니다.
        if all(isinstance(item, dict) for item in json_responses):
            df_from_json = pd.json_normalize(json_responses, sep='_')
            print(df_from_json)  # DataFrame 출력
        else:
            print("Error: Not all items in json_responses are dictionaries.")

        # 원래 데이터 프레임 출력
        print(data_df)
        print(notes_df)

    except Exception as e:
        print("[ERROR] An error occurred:", traceback.format_exc())
    finally:
        driver.quit()
        if os.path.exists('output.json'):
            os.remove('output.json')

# %% 231106 자동화된 웹 브라우저를 통한 로그인 및 데이터 추출 시스템 (헤더 포함)
from seleniumwire import webdriver  # Selenium Wire를 임포트합니다.
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import pandas as pd
import json
import time
import gzip
import os
import traceback

# 로그인 함수
def login(driver, app_id, app_pw):
    print("[INFO] 로그인을 시도합니다.")
    driver.get('https://dataservice.koscom.co.kr/login?returnUrl=/krx/approval-list')
    WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[1]/div/div/input')))
    id_box = driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[1]/div/div/input')
    password_box = driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[2]/div/div/input')
    login_button = driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[3]/button')
    id_box.send_keys(app_id)
    password_box.send_keys(app_pw)
    login_button.click()
    WebDriverWait(driver, 10).until(EC.url_to_be('https://dataservice.koscom.co.kr/krx/approval-list'))

# 데이터 추출 함수
def table_iter(num, driver):
    print(f"[INFO] 상세 페이지로 이동합니다: {num}")
    base_url = f"https://dataservice.koscom.co.kr/krx/{num}/approval-detail"
    driver.get(base_url)
    WebDriverWait(driver, 10).until(EC.presence_of_all_elements_located((By.CSS_SELECTOR, 'table > tbody > tr')))
    rows = driver.find_elements(By.CSS_SELECTOR, 'table > tbody > tr')
    result = [[cell.text for cell in row.find_elements(By.CSS_SELECTOR, 'td')] for row in rows]
    WebDriverWait(driver, 10).until(EC.presence_of_all_elements_located((By.XPATH, "//div[contains(@style, 'margin-top:') and contains(text(), '주')]")))
    notes = [note.text for note in driver.find_elements(By.XPATH, "//div[contains(@style, 'margin-top:') and contains(text(), '주')]")]
    return result, notes

# 데이터를 DataFrame으로 변환하는 함수
def convert_to_dataframes(data_list, notes_list):
    headers = ["구분", "상품명", "화폐단위", "이용료(월)", "제공방식", "계약 효력일"]
    df = pd.DataFrame(data_list, columns=headers)
    notes_df = pd.DataFrame(notes_list, columns=["Notes"])
    return df, notes_df

# JSON 데이터를 파일에 저장하는 함수
def save_json_to_file(data, filename):
    with open(filename, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=4)

# 메인 실행 코드
if __name__ == "__main__":
    seleniumwire_options = {
        'connection_timeout': None,
        'verify_ssl': False,
    }
    driver = webdriver.Chrome(seleniumwire_options=seleniumwire_options)

    try:
        # 실제 사용자 정보로 변경해야 합니다.
        login(driver, 'goguma@krx.co.kr', 'wkrwjs12!@')

        # 데이터 추출
        num = '100562'
        data_result, notes_result = table_iter(num, driver)
        data_df, notes_df = convert_to_dataframes(data_result, notes_result)

        # 클릭할 다운로드 버튼 요소를 찾습니다.
        download_link = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, '.iconset.icon-down-attach'))
        )
        download_link.click()  # 요소를 클릭합니다.

        # 클릭 후에 발생하는 요청을 필터링합니다.
        time.sleep(3)  # 네트워크 트래픽을 기다립니다.
        for request in driver.requests:
            if request.response and 'application/json' in request.response.headers.get('Content-Type', ''):
                print(f"요청 URL: {request.url}")
                print(f"응답 코드: {request.response.status_code}")
                print(f"요청 헤더: {request.headers}")
                if request.body:
                    # 요청 본문이 있다면 출력합니다.
                    print(f"요청 바디: {request.body.decode('utf-8', 'ignore')}")
                else:
                    print("요청 바디: None")
                
                # 응답 본문을 출력할 수도 있습니다.
                # 만약 응답이 크다면 이를 출력하지 않거나 적절하게 처리해야 할 수 있습니다.
                # if request.response.body:
                #     print(f"응답 바디: {request.response.body.decode('utf-8', 'ignore')}")

        # 원래 데이터 프레임 출력
        print(data_df)
        print(notes_df)

    except Exception as e:
        print("[ERROR] An error occurred:", traceback.format_exc())
    finally:
        driver.quit()

# %% 231106 1130 Selenium Wire를 활용한 웹 자동 로그인 및 인증 헤더 추출을 통한 API 호출 자동화
from seleniumwire import webdriver  # Selenium Wire를 임포트합니다.
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import pandas as pd
import json
import time
import gzip
import os
import traceback

# 로그인 함수
def login(driver, app_id, app_pw):
    print("[INFO] 로그인을 시도합니다.")
    driver.get('https://dataservice.koscom.co.kr/login?returnUrl=/krx/approval-list')
    WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[1]/div/div/input')))
    id_box = driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[1]/div/div/input')
    password_box = driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[2]/div/div/input')
    login_button = driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[3]/button')
    id_box.send_keys(app_id)
    password_box.send_keys(app_pw)
    login_button.click()
    WebDriverWait(driver, 10).until(EC.url_to_be('https://dataservice.koscom.co.kr/krx/approval-list'))

# 데이터 추출 함수
def table_iter(num, driver):
    print(f"[INFO] 상세 페이지로 이동합니다: {num}")
    base_url = f"https://dataservice.koscom.co.kr/krx/{num}/approval-detail"
    driver.get(base_url)
    WebDriverWait(driver, 10).until(EC.presence_of_all_elements_located((By.CSS_SELECTOR, 'table > tbody > tr')))
    rows = driver.find_elements(By.CSS_SELECTOR, 'table > tbody > tr')
    result = [[cell.text for cell in row.find_elements(By.CSS_SELECTOR, 'td')] for row in rows]
    WebDriverWait(driver, 10).until(EC.presence_of_all_elements_located((By.XPATH, "//div[contains(@style, 'margin-top:') and contains(text(), '주')]")))
    notes = [note.text for note in driver.find_elements(By.XPATH, "//div[contains(@style, 'margin-top:') and contains(text(), '주')]")]
    return result, notes

# 데이터를 DataFrame으로 변환하는 함수
def convert_to_dataframes(data_list, notes_list):
    headers = ["구분", "상품명", "화폐단위", "이용료(월)", "제공방식", "계약 효력일"]
    df = pd.DataFrame(data_list, columns=headers)
    notes_df = pd.DataFrame(notes_list, columns=["Notes"])
    return df, notes_df

# JSON 데이터를 파일에 저장하는 함수
def save_json_to_file(data, filename):
    with open(filename, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=4)

# 메인 실행 코드
if __name__ == "__main__":
    seleniumwire_options = {
        'connection_timeout': None,
        'verify_ssl': False,
    }
    driver = webdriver.Chrome(seleniumwire_options=seleniumwire_options)

    try:
        login(driver, 'goguma@krx.co.kr', 'wkrwjs12!@')

        # 데이터 추출
        num = '100562'
        data_result, notes_result = table_iter(num, driver)
        data_df, notes_df = convert_to_dataframes(data_result, notes_result)

        # 클릭할 다운로드 버튼 요소를 찾습니다.
        download_link = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, '.iconset.icon-down-attach'))
        )
        download_link.click()  # 요소를 클릭합니다.

        # 클릭 후에 발생하는 요청을 필터링합니다.
        time.sleep(3)  # 네트워크 트래픽을 기다립니다.
        json_responses = []
        for request in driver.requests:
            if request.response and 'application/json' in request.response.headers.get('Content-Type', ''):
                print(f"요청 URL: {request.url}")
                print(f"응답 코드: {request.response.status_code}")
                print(f"요청 헤더: {request.headers}")
                if request.body:
                    # 요청 본문이 있다면 출력합니다.
                    print(f"요청 바디: {request.body.decode('utf-8', 'ignore')}")
                else:
                    print("요청 바디: None")

                # 응답이 gzip으로 압축되었다면 압축 해제합니다.
                content_encoding = request.response.headers.get('Content-Encoding', '')
                if 'gzip' in content_encoding:
                    response_body = gzip.decompress(request.response.body).decode('utf-8')
                else:
                    response_body = request.response.body.decode('utf-8')

                # JSON 응답을 파이썬 객체로 변환하여 리스트에 추가합니다.
                json_responses.append(json.loads(response_body))

        # JSON 응답을 파일에 저장합니다.
        save_json_to_file(json_responses, 'api_responses.json')
        print("[INFO] JSON 응답이 파일에 저장되었습니다.")

        # 원래 데이터 프레임 출력
        print(data_df)
        print(notes_df)

    except Exception as e:
        print("[ERROR] An error occurred:", traceback.format_exc())
    finally:
        driver.quit()

# %% 231106 2230 웹 자동화를 통한 크롤링 및 API 응답 데이터(All) 추출 및 저장 
# Json_responses 에서 원하는 정보 추출 가능 (요청 정보 / 받은 정보 추출)
from seleniumwire import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import pandas as pd
import json
import time
import gzip
import traceback

# 로그인 함수
def login(driver, app_id, app_pw):
    print("[INFO] 로그인을 시도합니다.")
    driver.get('https://dataservice.koscom.co.kr/login?returnUrl=/krx/approval-list')
    WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[1]/div/div/input')))
    id_box = driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[1]/div/div/input')
    password_box = driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[2]/div/div/input')
    login_button = driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[3]/button')
    id_box.send_keys(app_id)
    password_box.send_keys(app_pw)
    login_button.click()
    WebDriverWait(driver, 10).until(EC.url_to_be('https://dataservice.koscom.co.kr/krx/approval-list'))

# 데이터 추출 함수
def table_iter(num, driver):
    print(f"[INFO] 상세 페이지로 이동합니다: {num}")
    base_url = f"https://dataservice.koscom.co.kr/krx/{num}/approval-detail"
    driver.get(base_url)
    WebDriverWait(driver, 10).until(EC.presence_of_all_elements_located((By.CSS_SELECTOR, 'table > tbody > tr')))
    rows = driver.find_elements(By.CSS_SELECTOR, 'table > tbody > tr')
    result = [[cell.text for cell in row.find_elements(By.CSS_SELECTOR, 'td')] for row in rows]
    return result

# 데이터를 DataFrame으로 변환하는 함수
def convert_to_dataframes(data_list):
    headers = ["구분", "상품명", "화폐단위", "이용료(월)", "제공방식", "계약 효력일"]
    df = pd.DataFrame(data_list, columns=headers)
    return df

# 메인 실행 코드
if __name__ == "__main__":
    seleniumwire_options = {
        'connection_timeout': None,
        'verify_ssl': False,
    }
    driver = webdriver.Chrome(seleniumwire_options=seleniumwire_options)

    try:
        # 실제 사용자 정보로 변경해야 합니다.
        login(driver, 'goguma@krx.co.kr', 'wkrwjs12!@')

        # 데이터 추출
        num = '100562'
        data_result = table_iter(num, driver)
        data_df = convert_to_dataframes(data_result)

        # 클릭 후에 발생하는 요청을 필터링합니다.
        time.sleep(3)  # 네트워크 트래픽을 기다립니다.
        json_responses = []
        for request in driver.requests:
            if request.response and 'application/json' in request.response.headers.get('Content-Type', ''):
                response_body = request.response.body
                if 'gzip' in request.response.headers.get('Content-Encoding', ''):
                    response_body = gzip.decompress(response_body)
                response_body = response_body.decode('utf-8')
                json_data = json.loads(response_body)

                # Check if request is a POST and has a body
                request_body = None
                if request.method == 'POST' and request.body:
                    request_body = request.body.decode('utf-8')
                    try:
                        request_body = json.loads(request_body)
                    except json.JSONDecodeError:
                        pass  # request_body remains a string if it's not JSON

                response_info = {
                    'request_url': request.url,
                    'request_method': request.method,
                    'request_body': request_body,
                    'request_headers': dict(request.headers),
                    'response_code': request.response.status_code,
                    'response_headers': dict(request.response.headers),
                    'response_body': json_data
                }
                json_responses.append(response_info)

        # JSON 응답을 파일에 저장합니다.
        with open('api_responses.json', 'w', encoding='utf-8') as f:
            json.dump(json_responses, f, ensure_ascii=False, indent=4)

        print("[INFO] JSON 응답이 파일에 저장되었습니다.")

        # 데이터 프레임을 출력하거나 파일로 저장할 수 있습니다.
        print(data_df)

    except Exception as e:
        print("[ERROR] An error occurred:", traceback.format_exc())
    finally:
        driver.quit()

# %% 231106 2330 코스콤 데이터 서비스 로그인 및 API 호출 자동화 스크립트
# 프로필 로그인을 위해서는 프로필 (C:\Users\221016\AppData\Local\Google\Chrome\User Data) 
# 정보를 다른 DIR 에 복사하여 설정해주어야 충돌 문제가 없음
# %% 231112 2300 크롬 드라이버를 활용한 코스콤 데이터 서비스 로그인 및 API 응답 데이터 추출 (Session id 부분 제거)
import subprocess
import json
import time
import os
import datetime
from bs4 import BeautifulSoup  # 추가된 부분
from seleniumwire import webdriver
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import WebDriverException
import traceback
import requests

# 설정 및 경로 정의
CHROMEDRIVER_PATH = 'C:\\Users\\KRX\\Desktop\\201021\\chromedriver-win32\\chromedriver.exe'
CHROME_BINARY_PATH = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe'
LOGIN_URL = 'https://dataservice.koscom.co.kr/login?returnUrl=/krx/approval-list'
TARGET_URL = 'https://dataservice.koscom.co.kr/krx/approval-list'
PROFILE_PATH = 'C:\\Users\\KRX\\Desktop\\201021'
PROFILE_NAME = 'Profile 4'

# Chrome 옵션 설정
chrome_options = Options()
chrome_options.binary_location = CHROME_BINARY_PATH
chrome_options.add_argument("--disable-gpu")
chrome_options.add_argument("--no-sandbox")
chrome_options.add_argument("--start-maximized")
chrome_options.add_argument(f'user-data-dir={PROFILE_PATH}')
chrome_options.add_argument(f'profile-directory={PROFILE_NAME}')

# 기존 Chrome 작업 종료
def kill_chrome_tasks():
    try:
        subprocess.run(["taskkill", "/f", "/im", "chrome.exe"], check=True)
        print("Existing Chrome tasks terminated successfully.")
    except subprocess.CalledProcessError as e:
        print(f"Error terminating Chrome tasks: {e}")

# WebDriver 인스턴스 생성
def create_webdriver():
    service = ChromeService(executable_path=CHROMEDRIVER_PATH)
    driver = webdriver.Chrome(service=service, options=chrome_options)
    return driver

# 로그인 함수
def login(driver, app_id, app_pw):
    try:
        driver.get(LOGIN_URL)
        WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[1]/div/div/input')))
        id_box = driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[1]/div/div/input')
        password_box = driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[2]/div/div/input')
        login_button = driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[3]/button')
        id_box.send_keys(app_id)
        password_box.send_keys(app_pw)
        login_button.click()
        WebDriverWait(driver, 15).until(EC.url_to_be(TARGET_URL))
        print("[INFO] 로그인에 성공했습니다.")
    except Exception as e:
        print("[ERROR] 로그인 중 오류 발생:", traceback.format_exc())

# HTML에서 텍스트 추출 함수
def extract_text_from_html(html_content):
    soup = BeautifulSoup(html_content, 'html.parser')
    return soup.get_text()

# API 요청 함수
def send_api_request(url, headers):
    response = requests.get(url, headers=headers, verify=False)
    if response.status_code == 200:
        html_content = response.content.decode('utf-8')  # HTML 컨텐츠 추출
        text_content = extract_text_from_html(html_content)  # 텍스트만 추출
        return text_content
    else:
        print(f"[ERROR] API 요청 실패. Status Code: {response.status_code}")
        print(f"Response: {response.text}")
        return None

# 메인 실행 코드
if __name__ == "__main__":
    driver = create_webdriver()
    try:
        login(driver, 'goguma@krx.co.kr', 'wkrwjs12!@')
        time.sleep(10) # 인증 키 얻는 시간 고려
        headers = None
        for request in driver.requests:
            if 'Authorization' in request.headers:
                headers = {'Authorization': request.headers['Authorization']}
                break
        if not headers:
            print("[ERROR] Authorization 헤더를 찾을 수 없습니다.")
        else:
            YOUR_API_URL = 'https://dataservice.koscom.co.kr/apis/v1/user/approvals/100562'
            text_response = send_api_request(YOUR_API_URL, headers)
            if text_response:
                print("[INFO] API 응답 데이터:", text_response)
            else:
                print("[ERROR] API 요청 실패")
    except Exception as e:
        print("[ERROR] 메인 실행 중 오류 발생:", traceback.format_exc())
    finally:
        driver.quit()  # Uncomment if you want to close the browser at the end
        print("세션을 종료하고 프로세스가 완료되었습니다.")

# %% 231112 2330 크롬 드라이버를 활용한 코스콤 데이터 서비스 로그인 및 API 응답 데이터 추출 (List 作)
import subprocess
import json
import time
import os
import datetime
from seleniumwire import webdriver
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import WebDriverException
import traceback
import requests
from bs4 import BeautifulSoup

# 설정 및 경로 정의
CHROMEDRIVER_PATH = 'C:\\Users\\KRX\\Desktop\\201021\\chromedriver-win32\\chromedriver.exe'
CHROME_BINARY_PATH = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe'
LOGIN_URL = 'https://dataservice.koscom.co.kr/login?returnUrl=/krx/approval-list'
TARGET_URL = 'https://dataservice.koscom.co.kr/krx/approval-list'
PROFILE_PATH = 'C:\\Users\\KRX\\Desktop\\201021'
PROFILE_NAME = 'Profile 4'

# Chrome 옵션 설정
chrome_options = Options()
chrome_options.binary_location = CHROME_BINARY_PATH
chrome_options.add_argument("--disable-gpu")
chrome_options.add_argument("--no-sandbox")
chrome_options.add_argument("--start-maximized")
chrome_options.add_argument(f'user-data-dir={PROFILE_PATH}')
chrome_options.add_argument(f'profile-directory={PROFILE_NAME}')

# 기존 Chrome 작업 종료
def kill_chrome_tasks():
    try:
        subprocess.run(["taskkill", "/f", "/im", "chrome.exe"], check=True)
        print("Existing Chrome tasks terminated successfully.")
    except subprocess.CalledProcessError as e:
        print(f"Error terminating Chrome tasks: {e}")

# WebDriver 인스턴스 생성
def create_webdriver():
    service = ChromeService(executable_path=CHROMEDRIVER_PATH)
    driver = webdriver.Chrome(service=service, options=chrome_options)
    return driver

# 로그인 함수
def login(driver, app_id, app_pw):
    try:
        driver.get(LOGIN_URL)
        WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[1]/div/div/input')))
        id_box = driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[1]/div/div/input')
        password_box = driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[2]/div/div/input')
        login_button = driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[3]/button')
        id_box.send_keys(app_id)
        password_box.send_keys(app_pw)
        login_button.click()
        WebDriverWait(driver, 15).until(EC.url_to_be(TARGET_URL))
        print("[INFO] 로그인에 성공했습니다.")
    except Exception as e:
        print("[ERROR] 로그인 중 오류 발생:", traceback.format_exc())

# BeautifulSoup을 사용하여 HTML 테이블 추출
def extract_tables_from_html(html_content):
    soup = BeautifulSoup(html_content, 'html.parser')
    tables = soup.find_all('table')
    result = []

    for table in tables:
        rows = table.find_all('tr')
        table_data = []

        for row in rows:
            cols = row.find_all(['td', 'th'])
            cols = [ele.text.strip() for ele in cols]
            table_data.append(cols)

        result.append(table_data)

    return result

# API 요청 함수
def send_api_request(url, headers):
    response = requests.get(url, headers=headers, verify=False)
    if response.status_code == 200:
        html_content = response.content.decode('utf-8')
        tables = extract_tables_from_html(html_content)
        return tables
    else:
        print(f"[ERROR] API 요청 실패. Status Code: {response.status_code}")
        print(f"Response: {response.text}")
        return None

# 메인 실행 코드
if __name__ == "__main__":
    driver = create_webdriver()
    try:
        login(driver, 'goguma@krx.co.kr', 'wkrwjs12!@')
        time.sleep(10) # 인증 키 얻는 시간 고려
        headers = None
        for request in driver.requests:
            if 'Authorization' in request.headers:
                headers = {'Authorization': request.headers['Authorization']}
                break
        if not headers:
            print("[ERROR] Authorization 헤더를 찾을 수 없습니다.")
        else:
            YOUR_API_URL = 'https://dataservice.koscom.co.kr/apis/v1/user/approvals/100562'
            tables_response = send_api_request(YOUR_API_URL, headers)
            if tables_response:
                print("[INFO] API 응답 데이터:", tables_response)
            else:
                print("[ERROR] API 요청 실패")
    except Exception as e:
        print("[ERROR] 메인 실행 중 오류 발생:", traceback.format_exc())
    finally:
        driver.quit()  # Uncomment if you want to close the browser at the end
        print("세션을 종료하고 프로세스가 완료되었습니다.")

# %% 231113 2200 크롬 드라이버를 이용한 로그인과 BeautifulSoup을 활용한 HTML 테이블 데이터 추출
import subprocess
import json
import time
import os
import datetime
from seleniumwire import webdriver
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import WebDriverException
import traceback
import requests
from bs4 import BeautifulSoup

# 설정 및 경로 정의
CHROMEDRIVER_PATH = 'C:\\Users\\KRX\\Desktop\\201021\\chromedriver-win32\\chromedriver.exe'
CHROME_BINARY_PATH = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe'
LOGIN_URL = 'https://dataservice.koscom.co.kr/login?returnUrl=/krx/approval-list'
TARGET_URL = 'https://dataservice.koscom.co.kr/krx/approval-list'
PROFILE_PATH = 'C:\\Users\\KRX\\Desktop\\201021'
PROFILE_NAME = 'Profile 4'

# Chrome 옵션 설정
chrome_options = Options()
chrome_options.binary_location = CHROME_BINARY_PATH
chrome_options.add_argument("--disable-gpu")
chrome_options.add_argument("--no-sandbox")
chrome_options.add_argument("--start-maximized")
chrome_options.add_argument(f'user-data-dir={PROFILE_PATH}')
chrome_options.add_argument(f'profile-directory={PROFILE_NAME}')

# 기존 Chrome 작업 종료
def kill_chrome_tasks():
    try:
        subprocess.run(["taskkill", "/f", "/im", "chrome.exe"], check=True)
        print("Existing Chrome tasks terminated successfully.")
    except subprocess.CalledProcessError as e:
        print(f"Error terminating Chrome tasks: {e}")

# WebDriver 인스턴스 생성
def create_webdriver():
    service = ChromeService(executable_path=CHROMEDRIVER_PATH)
    driver = webdriver.Chrome(service=service, options=chrome_options)
    return driver

# 로그인 함수
def login(driver, app_id, app_pw):
    try:
        driver.get(LOGIN_URL)
        WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[1]/div/div/input')))
        id_box = driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[1]/div/div/input')
        password_box = driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[2]/div/div/input')
        login_button = driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[3]/button')
        id_box.send_keys(app_id)
        password_box.send_keys(app_pw)
        login_button.click()
        WebDriverWait(driver, 15).until(EC.url_to_be(TARGET_URL))
        print("[INFO] 로그인에 성공했습니다.")
    except Exception as e:
        print("[ERROR] 로그인 중 오류 발생:", traceback.format_exc())

# BeautifulSoup을 사용하여 HTML 컨텐츠 추출
def extract_data_from_html(html_content):
    soup = BeautifulSoup(html_content, 'html.parser')

    # 구조화된 데이터(테이블) 추출
    tables = soup.find_all('table')
    structured_data = []
    for table in tables:
        rows = table.find_all('tr')
        table_data = []
        for row in rows:
            cols = row.find_all(['td', 'th'])
            cols = [ele.text.strip() for ele in cols]
            table_data.append(cols)
        structured_data.append(table_data)

    # 구조화되지 않은 데이터 추출
    [s.extract() for s in soup(['style', 'script', 'table', '[document]', 'head', 'title'])]
    unstructured_data = soup.get_text(separator=' ', strip=True)

    # 전체 데이터 추출
    all_data = soup.get_text(separator=' ', strip=True)

    return all_data, structured_data, unstructured_data

# API 요청 함수
def send_api_request(url, headers):
    response = requests.get(url, headers=headers, verify=False)
    if response.status_code == 200:
        html_content = response.content.decode('utf-8')
        all_data, structured_data, unstructured_data = extract_data_from_html(html_content)
        return all_data, structured_data, unstructured_data
    else:
        print(f"[ERROR] API 요청 실패. Status Code: {response.status_code}")
        print(f"Response: {response.text}")
        return None, None, None

# 메인 실행 코드
if __name__ == "__main__":
    driver = create_webdriver()
    try:
        login(driver, 'goguma@krx.co.kr', 'wkrwjs12!@')
        time.sleep(20) # 인증 키 얻는 시간 고려
        headers = None
        for request in driver.requests:
            if 'Authorization' in request.headers:
                headers = {'Authorization': request.headers['Authorization']}
                break
        if not headers:
            print("[ERROR] Authorization 헤더를 찾을 수 없습니다.")
        else:
            YOUR_API_URL = 'https://dataservice.koscom.co.kr/apis/v1/user/approvals/100562'
            all_data, structured_data, unstructured_data = send_api_request(YOUR_API_URL, headers)
            if all_data or structured_data or unstructured_data:
                print("[INFO] 모든 데이터:", all_data)
                print("[INFO] 구조화된 데이터:", structured_data)
                print("[INFO] 구조화되지 않은 데이터:", unstructured_data)
            else:
                print("[ERROR] API 요청 실패")
    except Exception as e:
        print("[ERROR] 메인 실행 중 오류 발생:", traceback.format_exc())
    finally:
        driver.quit()  # Uncomment if you want to close the browser at the end
        print("세션을 종료하고 프로세스가 완료되었습니다.")

# %% 
import subprocess
import json
import time
import os
import datetime
from seleniumwire import webdriver
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.common.exceptions import WebDriverException, TimeoutException
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import traceback
import requests
from bs4 import BeautifulSoup

# 설정 및 경로 정의
CHROMEDRIVER_PATH = 'C:\\Users\\KRX\\Desktop\\201021\\chromedriver-win32\\chromedriver.exe'
CHROME_BINARY_PATH = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe'
LOGIN_URL = 'https://dataservice.koscom.co.kr/login?returnUrl=/krx/approval-list'
TARGET_URL = 'https://dataservice.koscom.co.kr/krx/approval-list'
PROFILE_PATH = 'C:\\Users\\KRX\\Desktop\\201021'
PROFILE_NAME = 'Profile 4'

# Chrome 옵션 설정
chrome_options = Options()
chrome_options.binary_location = CHROME_BINARY_PATH
chrome_options.add_argument("--disable-gpu")
chrome_options.add_argument("--no-sandbox")
chrome_options.add_argument("--start-maximized")
chrome_options.add_argument(f'user-data-dir={PROFILE_PATH}')
chrome_options.add_argument(f'profile-directory={PROFILE_NAME}')

# 기존 Chrome 작업 종료
def kill_chrome_tasks():
    try:
        subprocess.run(["taskkill", "/f", "/im", "chrome.exe"], check=True)
        print("Existing Chrome tasks terminated successfully.")
    except subprocess.CalledProcessError as e:
        print(f"Error terminating Chrome tasks: {e}")

# WebDriver 인스턴스 생성
def create_webdriver():
    service = ChromeService(executable_path=CHROMEDRIVER_PATH)
    driver = webdriver.Chrome(service=service, options=chrome_options)
    return driver

# 로그인 함수
def login(driver, app_id, app_pw):
    try:
        driver.get(LOGIN_URL)
        WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[1]/div/div/input')))
        id_box = driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[1]/div/div/input')
        password_box = driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[2]/div/div/input')
        login_button = driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[3]/button')
        id_box.send_keys(app_id)
        password_box.send_keys(app_pw)
        login_button.click()
        WebDriverWait(driver, 15).until(EC.url_to_be(TARGET_URL))
        print("[INFO] 로그인에 성공했습니다.")
        time.sleep(5)  # 대기 시간을 20초로 증가
    except TimeoutException as e:
        print("[ERROR] 로그인 중 Timeout 발생, 대기 시간 증가:", e)
        time.sleep(5)  # 대기 시간을 5초로 증가
    except Exception as e:
        print("[ERROR] 로그인 중 다른 오류 발생:", traceback.format_exc())

# BeautifulSoup을 사용하여 HTML 컨텐츠 추출
def extract_data_from_html(html_content):
    soup = BeautifulSoup(html_content, 'html.parser')
    tables = soup.find_all('table')
    structured_data = []
    unstructured_data = []

    # 구조화된 데이터(테이블) 추출
    for table in tables:
        rows = table.find_all('tr')
        table_data = []

        for row in rows:
            cols = row.find_all(['td', 'th'])
            cols = [ele.text.strip() for ele in cols]
            table_data.append(cols)

        structured_data.append(table_data)

    # 구조화되지 않은 데이터 추출
    [s.extract() for s in soup(['style', 'script', '[document]', 'head', 'title'])]
    unstructured_data = soup.get_text(separator=' ', strip=True)

    return structured_data, unstructured_data

# API 요청 함수
def send_api_request(url, headers):
    response = requests.get(url, headers=headers, verify=False)
    if response.status_code == 200:
        html_content = response.content.decode('utf-8')
        structured_data, unstructured_data = extract_data_from_html(html_content)
        return response.json(), structured_data, unstructured_data
    else:
        print(f"[ERROR] API 요청 실패. Status Code: {response.status_code}")
        print(f"Response: {response.text}")
        return None, None, None

# POST 요청을 보내는 함수
def send_post_request(url, headers, body):
    try:
        response = requests.post(url, headers=headers, json=body, verify=False)  # SSL 검증 비활성화
        if response.status_code == 200:
            return response.json()
        else:
            print(f"[ERROR] POST 요청 실패. Status Code: {response.status_code}")
            print(f"Response: {response.text}")
            return None
    except Exception as e:
        print("[ERROR] POST 요청 중 오류 발생:", traceback.format_exc())
        return None
    
# 응답 데이터를 JSON 파일로 저장하는 함수
def save_response_as_json(response_data, file_path):
    with open(file_path, 'w', encoding='utf-8') as file:
        json.dump(response_data, file, ensure_ascii=False, indent=4)

# 두 번째 API 응답 데이터 분류
def classify_api_response(api_response):
    structured_data = {}   # 구조화된 데이터 저장
    unstructured_data = {} # 비구조화된 데이터 저장

    # 데이터를 적절한 구조화 또는 비구조화 범주에 할당
    for key, value in api_response.items():
        if isinstance(value, dict) or isinstance(value, list):
            structured_data[key] = value
        else:
            unstructured_data[key] = value

    return structured_data, unstructured_data

# 로그인 후 쿠키 확인 함수
def check_cookies(driver):
    cookies = driver.get_cookies()
    print("[INFO] 쿠키 정보:", cookies)

# 네트워크 요청 로그 확인 함수
def print_network_logs(driver):
    for request in driver.requests:
        print(f"요청 URL: {request.url}")
        print(f"헤더: {request.headers}")

# 메인 실행 코드
if __name__ == "__main__":
    driver = create_webdriver()
    try:
        login(driver, 'goguma@krx.co.kr', 'wkrwjs12!@')
        # time.sleep(20) # 인증 키 얻는 시간 고려
        # 로그인 후 쿠키와 네트워크 요청 로그 확인
        # check_cookies(driver)
        # print_network_logs(driver)

        # 첫 번째 API 요청
        first_api_url = 'https://dataservice.koscom.co.kr/apis/v1/user/approvals/100562'
        headers = None
        for request in driver.requests:
            if 'Authorization' in request.headers:
                headers = {'Authorization': request.headers['Authorization']}
                break
        if not headers:
            print("[ERROR] Authorization 헤더를 찾을 수 없습니다.")
        else:
            first_api_response, structured_data, unstructured_data = send_api_request(first_api_url, headers)
            if first_api_response or structured_data or unstructured_data:
                # print("[INFO] 첫 번째 API 응답:", first_api_response)
                # print("[INFO] 구조화된 데이터:", structured_data)
                # print("[INFO] 구조화되지 않은 데이터:", unstructured_data)
                save_response_as_json({"first_api_response": first_api_response, "structured_data": structured_data, "unstructured_data": unstructured_data}, "first_api_response.json")
            else:
                print("[ERROR] 첫 번째 API 요청 실패")

        # 두 번째 API 요청
        second_api_url = "https://dataservice.koscom.co.kr/apis/v1/common/snapshots/history"
        
        # Authorization, Content-Type, Accept와 같은 헤더는 대부분의 API 요청에 필수적
        second_api_headers = {
            'Host': 'dataservice.koscom.co.kr',
            'Connection': 'keep-alive',
            # 'Content-Length': '105',
            'sec-ch-ua': '"Google Chrome";v="119", "Chromium";v="119", "Not?A_Brand";v="24"',
            # 'KMBS-LANGUAGE': 'ko',
            # 'sec-ch-ua-mobile': '?0',
            'Authorization': headers['Authorization'],
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36',
            'Content-Type': 'application/json',
            'Accept': 'application/json, text/plain, */*',
            # 'KMBS-PAGEID': '300238',
            'sec-ch-ua-platform': '"Windows"',
            'Origin': 'https://dataservice.koscom.co.kr',
            'Sec-Fetch-Site': 'same-origin',
            'Sec-Fetch-Mode': 'cors',
            'Sec-Fetch-Dest': 'empty',
            'Referer': 'https://dataservice.koscom.co.kr/krx/100562/approval-detail',
            'Accept-Encoding': 'gzip, deflate, br',
            'Accept-Language': 'ko-KR,ko;q=0.9,en-US;q=0.8,en;q=0.7'
        }
        second_api_body = {
            # 'snapshotsLargeClassificationCode': '04',
            'snapshotsLargeClassificationCode': '04',
            'snapshotsSmallClassificationCode': '04_01',
            'referenceId': 100562
        }
        # 두 번째 API 요청
        second_api_response = send_post_request(second_api_url, second_api_headers, second_api_body)
        if second_api_response:
            # print("[INFO] 두 번째 API 응답:", second_api_response)
    
            # 두 번째 API 응답 데이터 분류
            structured_data, unstructured_data = classify_api_response(second_api_response)
            # print("[INFO] 구조화된 데이터:", structured_data)
            # print("[INFO] 비구조화된 데이터:", unstructured_data)
    
            # JSON 파일로 저장
            save_response_as_json({"second_api_response": second_api_response, "structured_data": structured_data, "unstructured_data": unstructured_data}, "second_api_response.json")
        else:
            print("[ERROR] 두 번째 API 요청 실패")

    except Exception as e:
        print("[ERROR] 메인 실행 중 오류 발생:", traceback.format_exc())
    finally:
        driver.quit()
        print("세션을 종료하고 프로세스가 완료되었습니다.")
        
# %% 231116 1300 Full API Request codes (Login error edited)
import subprocess
import json
import time
import os
import datetime
from seleniumwire import webdriver
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.common.exceptions import WebDriverException, TimeoutException
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import traceback
import requests
from bs4 import BeautifulSoup

# 설정 및 경로 정의
CHROMEDRIVER_PATH = 'C:\\Users\\KRX\\Desktop\\201021\\chromedriver-win32\\chromedriver.exe'
CHROME_BINARY_PATH = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe'
LOGIN_URL = 'https://dataservice.koscom.co.kr/login?returnUrl=/krx/approval-list'
TARGET_URL = 'https://dataservice.koscom.co.kr/krx/approval-list'
PROFILE_PATH = 'C:\\Users\\KRX\\Desktop\\201021'
PROFILE_NAME = 'Profile 4'
REFERENCE_ID = 100562  # 추가된 설정

# Chrome 옵션 설정
chrome_options = Options()
chrome_options.binary_location = CHROME_BINARY_PATH
chrome_options.add_argument("--disable-gpu")
chrome_options.add_argument("--no-sandbox")
chrome_options.add_argument("--start-maximized")
chrome_options.add_argument(f'user-data-dir={PROFILE_PATH}')
chrome_options.add_argument(f'profile-directory={PROFILE_NAME}')

# 기존 Chrome 작업 종료
def kill_chrome_tasks():
    try:
        subprocess.run(["taskkill", "/f", "/im", "chrome.exe"], check=True)
        print("Existing Chrome tasks terminated successfully.")
    except subprocess.CalledProcessError as e:
        print(f"Error terminating Chrome tasks: {e}")

# WebDriver 인스턴스 생성
def create_webdriver():
    service = ChromeService(executable_path=CHROMEDRIVER_PATH)
    driver = webdriver.Chrome(service=service, options=chrome_options)
    return driver

# 로그인 함수
def login(driver, app_id, app_pw):
    try:
        driver.get(LOGIN_URL)
        WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[1]/div/div/input')))
        id_box = driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[1]/div/div/input')
        password_box = driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[2]/div/div/input')
        login_button = driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[3]/button')
        id_box.send_keys(app_id)
        password_box.send_keys(app_pw)
        login_button.click()
        WebDriverWait(driver, 15).until(EC.url_to_be(TARGET_URL))
        print("[INFO] 로그인에 성공했습니다.")
    except TimeoutException as e:
        print("[ERROR] 이미 로그인 되었는지, 로그인 창으로 이동할 수 없습니다.")
        # print(e)
    except Exception as e:
        print("[ERROR] 로그인 중 다른 오류 발생:", traceback.format_exc())

# 로그인 및 Authorization 헤더 추출 함수
def login_and_get_auth_header(driver, app_id, app_pw):
    try:
        driver.get(LOGIN_URL)
        WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[1]/div/div/input')))
        id_box = driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[1]/div/div/input')
        password_box = driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[2]/div/div/input')
        login_button = driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[3]/button')
        id_box.send_keys(app_id)
        password_box.send_keys(app_pw)
        login_button.click()
        WebDriverWait(driver, 15).until(EC.url_to_be(TARGET_URL))

        # 로그인 후 Authorization 헤더를 추출합니다.
        new_auth_header = None
        for request in driver.requests:
            if 'Authorization' in request.headers:
                new_auth_header = request.headers['Authorization']
                break

        if new_auth_header:
            print(f"[INFO] 추출된 Authorization 헤더: {new_auth_header}")
            return new_auth_header
        else:
            print("[ERROR] Authorization 헤더를 찾을 수 없습니다.")
            return None

    except TimeoutException:
        # 이미 로그인 상태인 경우, TARGET_URL로 이동하여 재시도
        print("[INFO] 이미 로그인 상태로 확인됨. TARGET_URL로 이동하여 재시도합니다.")
        driver.get(TARGET_URL)
        time.sleep(30)  # 30초 대기
        for request in driver.requests:
            if 'Authorization' in request.headers:
                new_auth_header = request.headers['Authorization']
                print(f"[INFO] 재시도 후 얻은 Authorization 헤더: {new_auth_header}")
                return new_auth_header
        print("[ERROR] 재시도 후에도 Authorization 헤더를 얻지 못함")
        return None
    except Exception as e:
        print("[ERROR] 로그인 또는 헤더 추출 중 오류 발생:", traceback.format_exc())
        return None
        
# BeautifulSoup을 사용하여 HTML 컨텐츠 추출
def extract_data_from_html(html_content):
    soup = BeautifulSoup(html_content, 'html.parser')
    tables = soup.find_all('table')
    structured_data = []
    unstructured_data = []

    # 구조화된 데이터(테이블) 추출
    for table in tables:
        rows = table.find_all('tr')
        table_data = []

        for row in rows:
            cols = row.find_all(['td', 'th'])
            cols = [ele.text.strip() for ele in cols]
            table_data.append(cols)

        structured_data.append(table_data)

    # 구조화되지 않은 데이터 추출
    [s.extract() for s in soup(['style', 'script', '[document]', 'head', 'title'])]
    unstructured_data = soup.get_text(separator=' ', strip=True)

    return structured_data, unstructured_data

# API 요청 함수
def send_api_request(url, headers):
    response = requests.get(url, headers=headers, verify=False)
    if response.status_code == 200:
        html_content = response.content.decode('utf-8')
        structured_data, unstructured_data = extract_data_from_html(html_content)
        return response.json(), structured_data, unstructured_data
    else:
        print(f"[ERROR] API 요청 실패. Status Code: {response.status_code}")
        print(f"Response: {response.text}")
        return None, None, None

# POST 요청을 보내는 함수
def send_post_request(url, headers, body):
    try:
        response = requests.post(url, headers=headers, json=body, verify=False)  # SSL 검증 비활성화
        if response.status_code == 200:
            return response.json()
        else:
            print(f"[ERROR] POST 요청 실패. Status Code: {response.status_code}")
            print(f"Response: {response.text}")
            return None
    except Exception as e:
        print("[ERROR] POST 요청 중 오류 발생:", traceback.format_exc())
        return None
    
# 응답 데이터를 JSON 파일로 저장하는 함수
def save_response_as_json(response_data, file_path):
    with open(file_path, 'w', encoding='utf-8') as file:
        json.dump(response_data, file, ensure_ascii=False, indent=4)

# 두 번째 API 응답 데이터 분류
def classify_api_response(api_response):
    structured_data = {}   # 구조화된 데이터 저장
    unstructured_data = {} # 비구조화된 데이터 저장

    # 데이터를 적절한 구조화 또는 비구조화 범주에 할당
    for key, value in api_response.items():
        if isinstance(value, dict) or isinstance(value, list):
            structured_data[key] = value
        else:
            unstructured_data[key] = value

    return structured_data, unstructured_data

# 로그인 후 쿠키 확인 함수
def check_cookies(driver):
    cookies = driver.get_cookies()
    print("[INFO] 쿠키 정보:", cookies)

# 네트워크 로그를 파일로 저장하는 함수
def save_network_logs(driver, file_name):
    with open(file_name, 'w', encoding='utf-8') as file:
        for request in driver.requests:
            file.write(f"요청 URL: {request.url}\n")
            file.write(f"요청 헤더: {request.headers}\n")
            if 'Authorization' in request.headers:
                file.write(f"요청 Authorization 헤더: {request.headers['Authorization']}\n")
            if request.response:
                file.write(f"응답 코드: {request.response.status_code}\n")
                file.write(f"응답 헤더: {request.response.headers}\n")
                if 'Authorization' in request.response.headers:
                    file.write(f"응답 Authorization 헤더: {request.response.headers['Authorization']}\n")
            file.write("\n")

# 메인 실행 코드
if __name__ == "__main__":
    driver = create_webdriver()
    try:
        # 로그인 및 Authorization 헤더 추출
        auth_header = login_and_get_auth_header(driver, 'goguma@krx.co.kr', 'wkrwjs12!@')
        time.sleep(15)  # 로그인 후 인증 토큰 생성 대기

        if auth_header:
            print(f"[INFO] 로그인 후 얻은 Authorization 헤더: {auth_header}")
        else:
            print("[ERROR] Authorization 헤더를 얻을 수 없습니다.")
            driver.quit()
            
        headers = {'Authorization': auth_header}
        first_api_url = f'https://dataservice.koscom.co.kr/apis/v1/user/approvals/{REFERENCE_ID}'

        for request in driver.requests:
            if 'Authorization' in request.headers:
                headers = {'Authorization': request.headers['Authorization']}
                break
        if not headers:
            print("[ERROR] Authorization 헤더를 찾을 수 없습니다.")
        else:
            # 첫 번째 API 요청 실행
            first_api_response, structured_data, unstructured_data = send_api_request(first_api_url, headers)
            print(f"[INFO] 첫 번째 API 요청 헤더: {headers}")
    
            if first_api_response or structured_data or unstructured_data:
                # 첫 번째 API 응답 처리
                # print("[INFO] 첫 번째 API 응답:", first_api_response)
                # print("[INFO] 구조화된 데이터:", structured_data)
                # print("[INFO] 구조화되지 않은 데이터:", unstructured_data)
                save_response_as_json({"first_api_response": first_api_response, "structured_data": structured_data, "unstructured_data": unstructured_data}, "first_api_response.json")
            else:
                print("[ERROR] 첫 번째 API 요청 실패. 재시도를 시도합니다.")
                # 재로그인을 시도하고 다시 헤더 추출
                login(driver, 'goguma@krx.co.kr', 'wkrwjs12!@')
                time.sleep(15)
                for request in driver.requests:
                    if request.url == "https://dataservice.koscom.co.kr/apis/v1/common/auth/my-information":
                        auth_header = request.headers.get('Authorization')
                        print(f"[INFO] 첫 번째 API 요청 재시도 헤더: {auth_header}")
                        break

        # 두 번째 API 요청
        second_api_url = "https://dataservice.koscom.co.kr/apis/v1/common/snapshots/history"
        
        # Authorization, Content-Type, Accept와 같은 헤더는 대부분의 API 요청에 필수적
        second_api_headers = {
            'Host': 'dataservice.koscom.co.kr',
            'Connection': 'keep-alive',
            # 'Content-Length': '105',
            'sec-ch-ua': '"Google Chrome";v="119", "Chromium";v="119", "Not?A_Brand";v="24"',
            # 'KMBS-LANGUAGE': 'ko',
            # 'sec-ch-ua-mobile': '?0',
            'Authorization': headers['Authorization'],
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36',
            'Content-Type': 'application/json',
            'Accept': 'application/json, text/plain, */*',
            # 'KMBS-PAGEID': '300238',
            'sec-ch-ua-platform': '"Windows"',
            'Origin': 'https://dataservice.koscom.co.kr',
            'Sec-Fetch-Site': 'same-origin',
            'Sec-Fetch-Mode': 'cors',
            'Sec-Fetch-Dest': 'empty',
            'Referer': 'https://dataservice.koscom.co.kr/krx/100562/approval-detail',
            'Accept-Encoding': 'gzip, deflate, br',
            'Accept-Language': 'ko-KR,ko;q=0.9,en-US;q=0.8,en;q=0.7'
        }
        second_api_body = {
            'snapshotsLargeClassificationCode': '04',
            'snapshotsSmallClassificationCode': '04_01',
            'referenceId': REFERENCE_ID
        }

        # 두 번째 API 요청 실행
        second_api_response = send_post_request(second_api_url, second_api_headers, second_api_body)
        print(f"[INFO] 두 번째 API 요청 헤더: {second_api_headers}")

        if second_api_response:
            # print("[INFO] 두 번째 API 응답:", second_api_response)

            # 두 번째 API 응답 데이터 분류
            structured_data, unstructured_data = classify_api_response(second_api_response)
            # print("[INFO] 구조화된 데이터:", structured_data)
            # print("[INFO] 비구조화된 데이터:", unstructured_data)

            # JSON 파일로 저장
            save_response_as_json({"second_api_response": second_api_response, "structured_data": structured_data, "unstructured_data": unstructured_data}, "second_api_response.json")
            save_network_logs(driver, "network_logs_success.txt")
        else:
            print("[ERROR] 두 번째 API 요청 실패")
            save_network_logs(driver, "network_logs_fail.txt")

    except Exception as e:
        print("[ERROR] 메인 실행 중 오류 발생:", traceback.format_exc())
    finally:
        driver.quit()
        print("세션을 종료하고 프로세스가 완료되었습니다.")
        
# %% 231117 2300 셀레니움 와이어를 활용한 웹 페이지 로그 저장기
from seleniumwire import webdriver
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.chrome.options import Options
import time
# 설정 부분
CHROMEDRIVER_PATH = 'C:\\Users\\KRX\\Desktop\\201021\\chromedriver-win32\\chromedriver.exe'
TARGET_URL = 'https://dataservice.koscom.co.kr/krx/approval-list'
DETAIL_URL = 'https://dataservice.koscom.co.kr/krx/101016/approval-detail'
APPROVAL_LIST_LOG_FILE = 'approval-list.log'
APPROVAL_DETAIL_LOG_FILE = 'approval-detail.log'

# Chrome 옵션 설정
chrome_options = Options()
# 필요한 추가적인 옵션 설정

# WebDriver 인스턴스 생성
service = ChromeService(executable_path=CHROMEDRIVER_PATH)
driver = webdriver.Chrome(service=service, options=chrome_options)

# 로그인 실행
login(driver, 'goguma@krx.co.kr', 'wkrwjs12!@')
time.sleep(15)  # 로그인 후 인증 토큰 생성 대기

# 웹 페이지 로드 (TARGET_URL)
driver.get(TARGET_URL)

# TARGET_URL 로그 파일에 저장
with open(APPROVAL_LIST_LOG_FILE, 'w', encoding='utf-8') as file:
    for request in driver.requests:
        file.write(f"URL: {request.url}\n")
        file.write(f"Method: {request.method}\n")
        file.write(f"Headers: {request.headers}\n")
        if request.response:
            file.write(f"Response Status: {request.response.status_code}\n")
            file.write(f"Response Headers: {request.response.headers}\n")
        file.write("\n")

# DETAIL_URL 로그 파일에 저장
driver.get(DETAIL_URL)
with open(APPROVAL_DETAIL_LOG_FILE, 'w', encoding='utf-8') as file:
    for request in driver.requests:
        if DETAIL_URL in request.url:
            file.write(f"URL: {request.url}\n")
            file.write(f"Method: {request.method}\n")
            file.write(f"Headers: {request.headers}\n")
            if request.response:
                file.write(f"Response Status: {request.response.status_code}\n")
                file.write(f"Response Headers: {request.response.headers}\n")
            file.write("\n")

# WebDriver 종료
driver.quit()

# %% cf) 231118 tracking log using tk 
import json
import time
from seleniumwire import webdriver
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import tkinter as tk
from threading import Thread

# 설정 부분
CHROMEDRIVER_PATH = 'C:\\Users\\KRX\\Desktop\\201021\\chromedriver-win32\\chromedriver.exe'
LOGIN_URL = 'https://dataservice.koscom.co.kr/login?returnUrl=/krx/approval-list'
TARGET_URL = 'https://dataservice.koscom.co.kr/krx/approval-list'
LOG_FILE = 'page_interaction.log'
JSON_LOG_FILE = 'json_responses.json'

# Chrome 옵션 설정
chrome_options = Options()
chrome_options.add_argument("--disable-gpu")
chrome_options.add_argument("--no-sandbox")
chrome_options.add_argument("--start-maximized")

# WebDriver 인스턴스 생성
service = ChromeService(executable_path=CHROMEDRIVER_PATH)
driver = webdriver.Chrome(service=service, options=chrome_options)

# 로그인 함수
def login(driver, username, password):
    driver.get(LOGIN_URL)
    WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[1]/div/div/input'))).send_keys(username)
    WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[2]/div/div/input'))).send_keys(password)
    WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[3]/button'))).click()
    time.sleep(5)  # 로그인 처리 및 페이지 전환 대기

# 전역 변수 선언
json_responses = []
recording = False

# 로그 저장 및 JSON 응답 수집 함수
def save_interaction_log(file_name, driver):
    global json_responses, recording
    json_responses = []
    with open(file_name, 'w', encoding='utf-8') as file:
        for request in driver.requests:
            file.write(f"URL: {request.url}\n")
            file.write(f"Method: {request.method}\n")
            file.write(f"Headers: {request.headers}\n")
            if request.body:
                file.write(f"Request Body: {request.body.decode('utf-8')}\n")
            if request.response:
                file.write(f"Response Status: {request.response.status_code}\n")
                file.write(f"Response Headers: {request.response.headers}\n")
                try:
                    response_body = request.response.body.decode('utf-8')
                    file.write(f"Response Body: {response_body}\n")
                    if 'application/json' in request.response.headers.get('Content-Type', '') and recording:
                        json_data = json.loads(response_body)
                        json_responses.append({
                            'url': request.url,
                            'method': request.method,
                            'request_headers': dict(request.headers),
                            'request_body': request.body.decode('utf-8'),
                            'response_code': request.response.status_code,
                            'response_headers': dict(request.response.headers),
                            'response_body': json_data
                        })
                except UnicodeDecodeError:
                    continue
            file.write("\n")
    with open(JSON_LOG_FILE, 'w', encoding='utf-8') as json_file:
        json.dump(json_responses, json_file, ensure_ascii=False, indent=4)
    recording = False

# tkinter GUI
def launch_gui(driver):
    global recording
    root = tk.Tk()
    root.title("Web Interaction Logger")

    def on_start_recording():
        global recording
        recording = True

    def on_stop_recording():
        global recording
        if recording:
            save_interaction_log(LOG_FILE, driver)
            recording = False
            root.destroy()

    start_button = tk.Button(root, text="Start Recording", command=on_start_recording)
    start_button.pack(pady=10)

    stop_button = tk.Button(root, text="Stop Recording and Exit", command=on_stop_recording)
    stop_button.pack(pady=10)

    root.mainloop()

# 로그인 실행
login(driver, 'goguma@krx.co.kr', 'wkrwjs12!@')
driver.get(TARGET_URL)

# GUI를 별도의 스레드에서 실행
gui_thread = Thread(target=launch_gui, args=(driver,))
gui_thread.start()
gui_thread.join()  # 사용자 상호작용이 완료될 때까지 대기

# JSON 응답 출력
if not recording:
    print("JSON Responses Collected:")
    for response in json_responses:
        print(f"URL: {response['url']}")
        print(f"Method: {response['method']}")
        print(f"Request Headers: {response['request_headers']}")
        print(f"Request Body: {response['request_body']}")
        print(f"Response Code: {response['response_code']}")
        print(f"Response Headers: {response['response_headers']}")
        print(json.dumps(response['response_body'], indent=4, ensure_ascii=False))

# WebDriver 종료
driver.quit()
# %% cf) 231121 tracking log using tk (Network logs)
import json
import time
import tkinter as tk
from threading import Thread
from seleniumwire import webdriver
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

class WebInteractionLogger:
    """
    웹 상호작용을 로깅하는 클래스입니다.
    Selenium WebDriver를 사용하여 웹 페이지와의 상호작용을 기록하고,
    결과를 로그 파일과 객체에 저장합니다.
    """
    def __init__(self, chromedriver_path, chrome_binary_path, login_url, username, password, target_url, log_file, json_log_file):
        self.chromedriver_path = chromedriver_path
        self.chrome_binary_path = chrome_binary_path
        self.login_url = login_url
        self.username = username
        self.password = password
        self.target_url = target_url
        self.log_file = log_file
        self.json_log_file = json_log_file
        self.driver = None
        self.json_responses = []
        self.recording = False

    def create_webdriver(self):
        """
        Chrome WebDriver 인스턴스를 생성합니다.
        """
        chrome_options = Options()
        chrome_options.binary_location = self.chrome_binary_path
        chrome_options.add_argument("--disable-gpu")
        chrome_options.add_argument("--no-sandbox")
        chrome_options.add_argument("--start-maximized")
        service = ChromeService(executable_path=self.chromedriver_path)
        self.driver = webdriver.Chrome(service=service, options=chrome_options)

    def login(self):
        """
        로그인 페이지에서 자동 로그인을 수행합니다.
        """
        self.driver.get(self.login_url)
        WebDriverWait(self.driver, 10).until(EC.presence_of_element_located((By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[1]/div/div/input'))).send_keys(self.username)
        WebDriverWait(self.driver, 10).until(EC.presence_of_element_located((By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[2]/div/div/input'))).send_keys(self.password)
        WebDriverWait(self.driver, 10).until(EC.presence_of_element_located((By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[3]/button'))).click()
        time.sleep(5)

    def save_interaction_log(self):
        """
        상호작용 로그를 파일과 객체에 저장합니다.
        """
        with open(self.log_file, 'w', encoding='utf-8') as file:
            for request in self.driver.requests:
                file.write(f"URL: {request.url}\n")
                file.write(f"Method: {request.method}\n")
                file.write(f"Headers: {request.headers}\n")
                if request.body:
                    file.write(f"Request Body: {request.body.decode('utf-8')}\n")
                if request.response:
                    file.write(f"Response Status: {request.response.status_code}\n")
                    file.write(f"Response Headers: {request.response.headers}\n")
                    try:
                        response_body = request.response.body.decode('utf-8')
                        file.write(f"Response Body: {response_body}\n")
                        if 'application/json' in request.response.headers.get('Content-Type', '') and self.recording:
                            json_data = json.loads(response_body)
                            self.json_responses.append({
                                'url': request.url,
                                'method': request.method,
                                'request_headers': dict(request.headers),
                                'request_body': request.body.decode('utf-8'),
                                'response_code': request.response.status_code,
                                'response_headers': dict(request.response.headers),
                                'response_body': json_data
                            })
                    except UnicodeDecodeError:
                        continue
                file.write("\n")
        self.recording = False
        self.print_json_responses()

    def print_json_responses(self):
        """
        JSON 응답을 출력합니다.
        """
        print("JSON Responses Collected:")
        for response in self.json_responses:
            print(f"URL: {response['url']}")
            print(f"Method: {response['method']}")
            print(f"Request Headers: {response['request_headers']}")
            print(f"Request Body: {response['request_body']}")
            print(f"Response Code: {response['response_code']}")
            print(f"Response Headers: {response['response_headers']}")
            print(json.dumps(response['response_body'], indent=4, ensure_ascii=False))

    def launch_gui(self):
        """
        tkinter GUI를 실행하여 녹화 시작 및 중지를 제어합니다.
        """
        root = tk.Tk()
        root.title("Web Interaction Logger")

        start_button = tk.Button(root, text="녹화 시작", command=self.start_recording)
        start_button.pack(pady=10)

        stop_button = tk.Button(root, text="녹화 중지 및 종료", command=self.stop_recording)
        stop_button.pack(pady=10)

        root.mainloop()

    def start_recording(self):
        """
        상호작용 녹화를 시작합니다.
        """
        self.recording = True

    def stop_recording(self):
        """
        상호작용 녹화를 중지하고 GUI를 종료합니다.
        """
        if self.recording:
            self.save_interaction_log()
            self.driver.quit()

    def run(self):
        """
        웹 상호작용 로거를 실행합니다.
        """
        self.create_webdriver()
        self.login()
        self.driver.get(self.target_url)
        gui_thread = Thread(target=self.launch_gui)
        gui_thread.start()
        gui_thread.join()

if __name__ == "__main__":
    # 설정 부분
    CHROMEDRIVER_PATH = 'C:\\Users\\KRX\\Desktop\\201021\\chromedriver-win32\\chromedriver.exe'
    CHROME_BINARY_PATH = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe'
    LOGIN_URL = 'https://dataservice.koscom.co.kr/login?returnUrl=/krx/approval-list'
    TARGET_URL = 'https://dataservice.koscom.co.kr/krx/approval-list'
    LOG_FILE = 'page_interaction.log'
    JSON_LOG_FILE = 'json_responses.json'

    # 클래스 인스턴스 생성 및 실행
    logger = WebInteractionLogger(CHROMEDRIVER_PATH, CHROME_BINARY_PATH, LOGIN_URL, 'goguma@krx.co.kr', 'wkrwjs12!@', TARGET_URL, LOG_FILE, JSON_LOG_FILE)
    logger.run()
     
    # JSON 응답 출력
    logger.print_json_responses()
# %% cf) Filter Responses 
import json
import time
from seleniumwire import webdriver
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import requests
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# 설정 및 경로 정의
CHROMEDRIVER_PATH = 'C:\\Users\\KRX\\Desktop\\201021\\chromedriver-win32\\chromedriver.exe'
CHROME_BINARY_PATH = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe'
LOGIN_URL = 'https://dataservice.koscom.co.kr/login?returnUrl=/krx/approval-list'

# Chrome 옵션 설정
chrome_options = Options()
chrome_options.binary_location = CHROME_BINARY_PATH
chrome_options.add_argument("--start-maximized")  # 화면 최대화

# WebDriver 인스턴스 생성 함수
def create_webdriver():
    service = ChromeService(executable_path=CHROMEDRIVER_PATH)
    driver = webdriver.Chrome(service=service, options=chrome_options)
    return driver

# 로그인 함수
def login(driver, username, password):
    driver.get(LOGIN_URL)
    WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[1]/div/div/input'))).send_keys(username)
    WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[2]/div/div/input'))).send_keys(password)
    WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[3]/button'))).click()
    time.sleep(5)  # 로그인 처리 및 페이지 전환 대기

# JSON 응답 필터링 함수
def filter_json_responses(json_responses, wts_keywords):
    filtered_responses = []

    for response in json_responses:
        response_str = json.dumps(response)
        if any(keyword in response_str for keyword in wts_keywords):
            filtered_responses.append(response)

    return filtered_responses

# 메인 실행 코드
if __name__ == "__main__":
    driver = create_webdriver()
    try:
        login(driver, 'goguma@krx.co.kr', 'wkrwjs12!@')
        time.sleep(10)  # 페이지 로드 대기

        # JSON 응답 수집
        json_responses = []
        for request in driver.requests:
            if request.response and 'application/json' in request.response.headers.get('Content-Type', ''):
                try:
                    json_data = json.loads(request.response.body.decode('utf-8'))
                    json_responses.append(json_data)
                except (json.JSONDecodeError, UnicodeDecodeError):
                    continue

        # 필터링 실행
        wts_keywords = ["fileuuid", "total", "referenceId"]
        filtered = filter_json_responses(json_responses, wts_keywords)

        # 필터링된 결과 출력
        print(json.dumps(filtered, indent=4, ensure_ascii=False))

    except Exception as e:
        print(f"[ERROR] 메인 실행 중 오류 발생: {e}")
    finally:
        driver.quit()

# %% cf) Filter Responses_2 (231121)
import json
import time
from seleniumwire import webdriver
from urllib.parse import urlparse
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# 설정 및 경로 정의
CHROMEDRIVER_PATH = 'C:\\Users\\KRX\\Desktop\\201021\\chromedriver-win32\\chromedriver.exe'
CHROME_BINARY_PATH = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe'
LOGIN_URL = 'https://dataservice.koscom.co.kr/login?returnUrl=/krx/approval-list'

# Chrome 옵션 설정
chrome_options = Options()
chrome_options.binary_location = CHROME_BINARY_PATH
chrome_options.add_argument("--start-maximized")

# WebDriver 인스턴스 생성 함수
def create_webdriver():
    service = ChromeService(executable_path=CHROMEDRIVER_PATH)
    driver = webdriver.Chrome(service=service, options=chrome_options)
    return driver

# 로그인 함수
def login(driver, username, password):
    driver.get(LOGIN_URL)
    WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[1]/div/div/input'))).send_keys(username)
    WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[2]/div/div/input'))).send_keys(password)
    WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[3]/button'))).click()
    time.sleep(5)

# 기본 URL 추출 함수
def extract_base_url(driver):
    for request in driver.requests:
        print("Request URL:", request.url)  # 디버깅을 위한 URL 출력
        if '/document' in request.url:
            parsed_url = urlparse(request.url)
            base_url = f"{parsed_url.scheme}://{parsed_url.netloc}"
            return base_url
    return None

# 메인 실행 코드
if __name__ == "__main__":
    driver = create_webdriver()
    try:
        login(driver, 'goguma@krx.co.kr', 'wkrwjs12!@')
        time.sleep(10)  # 페이지 로드 대기

        # 기본 URL 추출 및 출력
        base_url = extract_base_url(driver)
        if base_url:
            print(f"Base URL: {base_url}")
        else:
            print("Base URL not found")

    except Exception as e:
        print(f"[ERROR] 메인 실행 중 오류 발생: {e}")
    finally:
        driver.quit()

# %% EX) File downloads
import requests

# 기본 URL 설정
base_url = "https://dataservice.koscom.co.kr"

# 파일 UUID
file_uuid = "0c9f8f91-c61e-4e13-ad21-67f2789f9404"  # 예시 파일 UUID

# 파일 다운로드 URL
download_url = f"{base_url}/apis/v1/common/files?fileUUID={file_uuid}"

# 파일 다운로드
response = requests.get(download_url, verify = False)
if response.status_code == 200:
    with open("downloaded_file.pdf", "wb") as file:
        file.write(response.content)
    print("파일 다운로드 완료")
else:
    print("파일 다운로드 실패:", response.status_code)

# %% EX) File downloads
import requests
import time
from seleniumwire import webdriver
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# 설정 및 경로 정의
CHROMEDRIVER_PATH = 'C:\\Users\\KRX\\Desktop\\201021\\chromedriver-win32\\chromedriver.exe'
CHROME_BINARY_PATH = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe'
LOGIN_URL = 'https://dataservice.koscom.co.kr/login?returnUrl=/krx/approval-list'

# Chrome 옵션 설정
chrome_options = Options()
chrome_options.binary_location = CHROME_BINARY_PATH
chrome_options.add_argument("--start-maximized")

# WebDriver 인스턴스 생성 함수
def create_webdriver():
    service = ChromeService(executable_path=CHROMEDRIVER_PATH)
    driver = webdriver.Chrome(service=service, options=chrome_options)
    return driver

# 로그인 함수
def login(driver, username, password):
    driver.get(LOGIN_URL)
    WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[1]/div/div/input'))).send_keys(username)
    WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[2]/div/div/input'))).send_keys(password)
    WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[3]/button'))).click()
    time.sleep(5)

# 파일 다운로드 함수
def download_file(file_uuid, auth_token, save_path):
    """
    파일을 다운로드하는 함수

    :param file_uuid: 파일의 UUID
    :param auth_token: 인증 토큰 (Authorization header)
    :param save_path: 파일을 저장할 경로
    """
    base_url = "https://dataservice.koscom.co.kr"
    download_url = f"{base_url}/apis/v1/common/files?fileUUID={file_uuid}"

    headers = {'Authorization': auth_token}
    
    response = requests.get(download_url, headers=headers, verify=False)
    if response.status_code == 200:
        with open(save_path, 'wb') as file:
            file.write(response.content)
        print(f"File downloaded successfully and saved as {save_path}")
    else:
        print(f"Failed to download file: Status code {response.status_code}, Response: {response.text}")

# 메인 실행 코드
if __name__ == "__main__":
    driver = create_webdriver()
    try:
        login(driver, 'goguma@krx.co.kr', 'wkrwjs12!@')
        time.sleep(10)  # 인증 토큰 생성 대기

        # Authorization 헤더 추출
        auth_header = None
        for request in driver.requests:
            if 'Authorization' in request.headers:
                auth_header = request.headers['Authorization']
                break

        if auth_header:
            # 여기에 파일 UUID를 입력하세요
            file_uuid = "1df807dc-9e8d-4698-9581-383f484f7a42.pdf"  # JSON 응답에서 가져온 fileUUID
            save_path = "downloaded_file.pdf"  # 저장할 파일 이름

            # 파일 다운로드 및 저장
            download_file(file_uuid, auth_header, save_path)
        else:
            print("Failed to obtain Authorization header")

    except Exception as e:
        print(f"[ERROR] 메인 실행 중 오류 발생: {e}")
    finally:
        driver.quit()


# %% 231117 셀레니움을 이용한 'referenceId' 포함 JSON 응답 추출기
import json
import time
from seleniumwire import webdriver
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.chrome.options import Options

# 설정 및 경로 정의
CHROMEDRIVER_PATH = 'C:\\Users\\KRX\\Desktop\\201021\\chromedriver-win32\\chromedriver.exe'
CHROME_BINARY_PATH = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe'
TARGET_URL = 'https://dataservice.koscom.co.kr/krx/approval-list'
JSON_LOG_FILE = 'referenceId_responses.json'

# Chrome 옵션 설정
chrome_options = Options()
chrome_options.binary_location = CHROME_BINARY_PATH
chrome_options.add_argument("--disable-gpu")
chrome_options.add_argument("--no-sandbox")
chrome_options.add_argument("--start-maximized")

# WebDriver 인스턴스 생성 함수
def create_webdriver():
    service = ChromeService(executable_path=CHROMEDRIVER_PATH)
    driver = webdriver.Chrome(service=service, options=chrome_options)
    return driver

# JSON 응답 필터링 및 저장 함수 정의
def filter_and_save_json_responses(driver):
    referenceId_responses = []
    json_data_collected = []
    for request in driver.requests:
        if request.response and 'application/json' in request.response.headers.get('Content-Type', ''):
            try:
                json_data = json.loads(request.response.body.decode('utf-8'))
                response_info = {
                    'request_url': request.url,
                    'request_method': request.method,
                    'request_headers': dict(request.headers),
                    'response_code': request.response.status_code,
                    'response_headers': dict(request.response.headers),
                    'response_body': json_data
                }
                json_data_collected.append(response_info)
                if 'referenceId' in json.dumps(json_data):
                    referenceId_responses.append(response_info)
            except (json.JSONDecodeError, UnicodeDecodeError):
                continue

    with open(JSON_LOG_FILE, 'w', encoding='utf-8') as file:
        json.dump(referenceId_responses, file, ensure_ascii=False, indent=4)

    return referenceId_responses, json_data_collected

# 메인 실행 코드
if __name__ == "__main__":
    driver = create_webdriver()
    try:
        # 이미 정의된 로그인 함수 호출
        login(driver, 'goguma@krx.co.kr', 'wkrwjs12!@')

        driver.get(TARGET_URL)
        time.sleep(10)  # 페이지 로드 및 추가 네트워크 요청 대기

        referenceId_responses, json_data_collected = filter_and_save_json_responses(driver)

        # 필터링된 응답과 모든 JSON 데이터 출력
        print("Filtered Responses with referenceId:")
        for response in referenceId_responses:
            print(json.dumps(response, indent=4, ensure_ascii=False))
        
        print("\nAll JSON Data Collected:")
        for data in json_data_collected:
            print(json.dumps(data, indent=4, ensure_ascii=False))

    except Exception as e:
        print(f"[ERROR] 메인 실행 중 오류 발생: {e}")
    finally:
        driver.quit()
# %% 231118 0030 cf) 셀레니움을 이용한 웹 페이지 네트워크 요청 캡처 및 분석 도구 (two pages, Filter)
import json
import time
from seleniumwire import webdriver
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By

# 설정 및 경로 정의
CHROMEDRIVER_PATH = 'C:\\Users\\KRX\\Desktop\\201021\\chromedriver-win32\\chromedriver.exe'
CHROME_BINARY_PATH = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe'
TARGET_URL = 'https://dataservice.koscom.co.kr/krx/approval-list'
JSON_LOG_FILE = 'referenceId_responses.json'
# WTS_keywords = 'referenceId' # URL 을 구성하는 숫자이자 Requset Header 에 쓰이는 Reference ID 
WTS_keywords = 'total' # 3rd API 의 request_body 에 포함된 
WTS_keywords = 'fileuuid' # 3rd API 의 request_body 에 포함된 

# Chrome 옵션 설정ㅉ
chrome_options = Options()
chrome_options.binary_location = CHROME_BINARY_PATH
chrome_options.add_argument("--disable-gpu")
chrome_options.add_argument("--no-sandbox")
chrome_options.add_argument("--start-maximized")

# WebDriver 인스턴스 생성 함수
def create_webdriver():
    service = ChromeService(executable_path=CHROMEDRIVER_PATH)
    driver = webdriver.Chrome(service=service, options=chrome_options)
    driver.implicitly_wait(10)  # Implicit Wait 설정 (예: 10초)
    return driver

# JSON 응답 필터링 및 저장 함수 정의
def filter_and_save_json_responses(driver):
    referenceId_responses = []
    json_data_collected = []
    for request in driver.requests:
        if request.response and 'application/json' in request.response.headers.get('Content-Type', ''):
            try:
                json_data = json.loads(request.response.body.decode('utf-8'))
                response_info = {
                    'request_url': request.url,
                    'request_method': request.method,
                    'request_headers': dict(request.headers),
                    'response_code': request.response.status_code,
                    'response_headers': dict(request.response.headers),
                    'response_body': json_data
                }
                json_data_collected.append(response_info)
                if WTS_keywords in json.dumps(json_data):
                    referenceId_responses.append(response_info)
            except (json.JSONDecodeError, UnicodeDecodeError):
                continue

    with open(JSON_LOG_FILE, 'w', encoding='utf-8') as file:
        json.dump(referenceId_responses, file, ensure_ascii=False, indent=4)

    return referenceId_responses, json_data_collected

# 특정 요소 클릭 후 JSON 응답 필터링 함수 정의
# (2 Page 로 이동시에 변화를 보기 위함)
def filter_responses_after_click(driver, xpath, last_request_index):
    element_to_click = driver.find_element(By.XPATH, xpath)
    element_to_click.click()

    time.sleep(30)  # 네트워크 트래픽 대기

    referenceId_responses_temp = []
    for request in driver.requests[last_request_index:]:
        if request.response and 'application/json' in request.response.headers.get('Content-Type', ''):
            try:
                request_body = request.body.decode('utf-8') if request.body else None
                json_data = json.loads(request.response.body.decode('utf-8'))
                if WTS_keywords in json.dumps(json_data):
                    response_info = {
                        'request_url': request.url,
                        'request_method': request.method,
                        'request_body': request_body,  # 요청 본문 추가
                        'request_headers': dict(request.headers),
                        'response_code': request.response.status_code,
                        'response_headers': dict(request.response.headers),
                        'response_body': json_data
                    }
                    referenceId_responses_temp.append(response_info)
            except (json.JSONDecodeError, UnicodeDecodeError):
                continue
    return referenceId_responses_temp

# 메인 실행 코드
if __name__ == "__main__":
    driver = create_webdriver()
    try:
        login(driver, 'goguma@krx.co.kr', 'wkrwjs12!@')

        driver.get(TARGET_URL)
        time.sleep(10)  # 페이지 로드 대기

        # 첫 번째 요청 필터링 및 저장
        referenceId_responses, json_data_collected = filter_and_save_json_responses(driver)

        # 클릭 이벤트 전 마지막 요청의 인덱스 저장
        last_request_index = len(driver.requests)

        # XPath에 해당하는 요소 클릭 후 두 번째 요청 필터링 및 저장
        referenceId_responses_2_temp = filter_responses_after_click(driver, "/html/body/div[1]/div[2]/div[3]/div[2]/div[3]/div/ul/li[2]", last_request_index)

        # 필터링된 응답과 모든 JSON 데이터 출력
        print(f"Filtered Responses with {WTS_keywords}:")
        for response in referenceId_responses:
            print(json.dumps(response, indent=4, ensure_ascii=False))

        print("\nAll JSON Data Collected:")
        for data in json_data_collected:
            print(json.dumps(data, indent=4, ensure_ascii=False))

        print("\nFiltered Responses After Click:")
        for data in referenceId_responses_2_temp:
            print(json.dumps(data, indent=4, ensure_ascii=False))

    except Exception as e:
        print(f"[ERROR] 메인 실행 중 오류 발생: {e}")
    finally:
        driver.quit()


# %% cf) PDF 저장 
import pdfkit
import os

# wkhtmltopdf의 설치 경로 (Windows 환경)
wkhtmltopdf_path = r'C:\Program Files (x86)\wkhtmltopdf\bin\wkhtmltopdf.exe'

# pdfkit 설정에 wkhtmltopdf 경로 지정
config = pdfkit.configuration(wkhtmltopdf=wkhtmltopdf_path)

# 변환할 웹페이지 URL
url = 'https://nasdaqtrader.com/Trader.aspx?id=PriceListTrading2'

# PDF 파일이 저장될 경로
pdf_path = os.path.join(os.path.expanduser('~'), 'nasdaq_trading_price_list.pdf')

# URL을 PDF로 변환하여 저장
pdfkit.from_url(url, pdf_path, configuration=config)

print(f'PDF saved to {pdf_path}')

# %% 231123 0100 Full API Request codes (Third API added)
import subprocess
import json
import time
import os
import datetime
from seleniumwire import webdriver
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.common.exceptions import WebDriverException, TimeoutException
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import traceback
import requests
from bs4 import BeautifulSoup
import urllib3

# SSL 경고 비활성화 (개발 환경에서만 사용)
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


# 설정 및 경로 정의
CHROMEDRIVER_PATH = 'C:\\Users\\KRX\\Desktop\\201021\\chromedriver-win32\\chromedriver.exe'
CHROME_BINARY_PATH = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe'
LOGIN_URL = 'https://dataservice.koscom.co.kr/login?returnUrl=/krx/approval-list'
TARGET_URL = 'https://dataservice.koscom.co.kr/krx/approval-list'
PROFILE_PATH = 'C:\\Users\\KRX\\Desktop\\201021'
PROFILE_NAME = 'Profile 4'
REFERENCE_ID = 100562  # 추가된 설정

# Chrome 옵션 설정
chrome_options = Options()
chrome_options.binary_location = CHROME_BINARY_PATH
chrome_options.add_argument("--disable-gpu")
chrome_options.add_argument("--no-sandbox")
chrome_options.add_argument("--start-maximized")
chrome_options.add_argument(f'user-data-dir={PROFILE_PATH}')
chrome_options.add_argument(f'profile-directory={PROFILE_NAME}')

# 기존 Chrome 작업 종료
def kill_chrome_tasks():
    try:
        subprocess.run(["taskkill", "/f", "/im", "chrome.exe"], check=True)
        print("Existing Chrome tasks terminated successfully.")
    except subprocess.CalledProcessError as e:
        print(f"Error terminating Chrome tasks: {e}")

# WebDriver 인스턴스 생성
def create_webdriver():
    service = ChromeService(executable_path=CHROMEDRIVER_PATH)
    driver = webdriver.Chrome(service=service, options=chrome_options)
    return driver

# 로그인 함수
def login(driver, app_id, app_pw):
    try:
        driver.get(LOGIN_URL)
        WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[1]/div/div/input')))
        id_box = driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[1]/div/div/input')
        password_box = driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[2]/div/div/input')
        login_button = driver.find_element(By.XPATH, '//*[@id="contents"]/div[1]/div/form/div[3]/button')
        id_box.send_keys(app_id)
        password_box.send_keys(app_pw)
        login_button.click()
        WebDriverWait(driver, 15).until(EC.url_to_be(TARGET_URL))
        print("[INFO] 로그인에 성공했습니다.")
    except TimeoutException as e:
        print("[ERROR] 이미 로그인 되었는지, 로그인 창으로 이동할 수 없습니다.")
        # print(e)
    except Exception as e:
        print("[ERROR] 로그인 중 다른 오류 발생:", traceback.format_exc())
        
# BeautifulSoup을 사용하여 HTML 컨텐츠 추출
def extract_data_from_html(html_content):
    soup = BeautifulSoup(html_content, 'html.parser')
    tables = soup.find_all('table')
    structured_data = []
    unstructured_data = []

    # 구조화된 데이터(테이블) 추출
    for table in tables:
        rows = table.find_all('tr')
        table_data = []

        for row in rows:
            
            cols = row.find_all(['td', 'th'])
            cols = [ele.text.strip() for ele in cols]
            table_data.append(cols)

        structured_data.append(table_data)

    # 구조화되지 않은 데이터 추출
    [s.extract() for s in soup(['style', 'script', '[document]', 'head', 'title'])]
    unstructured_data = soup.get_text(separator=' ', strip=True)

    return structured_data, unstructured_data

# API 요청 함수
def send_api_request(url, headers):
    response = requests.get(url, headers=headers, verify=False)
    if response.status_code == 200:
        html_content = response.content.decode('utf-8')
        structured_data, unstructured_data = extract_data_from_html(html_content)
        return response.json(), structured_data, unstructured_data
    else:
        print(f"[ERROR] API 요청 실패. Status Code: {response.status_code}")
        print(f"Response: {response.text}")
        return None, None, None

# POST 요청을 보내는 함수
def send_post_request(url, headers, body):
    try:
        response = requests.post(url, headers=headers, json=body, verify=False)  # SSL 검증 비활성화
        if response.status_code == 200:
            return response.json()
        else:
            print(f"[ERROR] POST 요청 실패. Status Code: {response.status_code}")
            print(f"Response: {response.text}")
            return None
    except Exception as e:
        print("[ERROR] POST 요청 중 오류 발생:", traceback.format_exc())
        return None
    
# 응답 데이터를 JSON 파일로 저장하는 함수
def save_response_as_json(response_data, file_path):
    with open(file_path, 'w', encoding='utf-8') as file:
        json.dump(response_data, file, ensure_ascii=False, indent=4)

# 두 번째 API 응답 데이터 분류
def classify_api_response(api_response):
    structured_data = {}   # 구조화된 데이터 저장
    unstructured_data = {} # 비구조화된 데이터 저장

    # 데이터를 적절한 구조화 또는 비구조화 범주에 할당
    for key, value in api_response.items():
        if isinstance(value, dict) or isinstance(value, list):
            structured_data[key] = value
        else:
            unstructured_data[key] = value

    return structured_data, unstructured_data

# 로그인 후 쿠키 확인 함수
def check_cookies(driver):
    cookies = driver.get_cookies()
    print("[INFO] 쿠키 정보:", cookies)

# 네트워크 로그를 파일로 저장하는 함수
def save_network_logs(driver, file_name):
    with open(file_name, 'w', encoding='utf-8') as file:
        for request in driver.requests:
            file.write(f"요청 URL: {request.url}\n")
            file.write(f"요청 헤더: {request.headers}\n")
            if 'Authorization' in request.headers:
                file.write(f"요청 Authorization 헤더: {request.headers['Authorization']}\n")
            if request.response:
                file.write(f"응답 코드: {request.response.status_code}\n")
                file.write(f"응답 헤더: {request.response.headers}\n")
                if 'Authorization' in request.response.headers:
                    file.write(f"응답 Authorization 헤더: {request.response.headers['Authorization']}\n")
            file.write("\n")

# 새로운 POST 요청을 보내는 함수
def send_third_api_request(url, headers, body):
    try:
        response = requests.post(url, headers=headers, json=body, verify=False)
        if response.status_code == 200:
            html_content = response.content.decode('utf-8')
            structured_data, unstructured_data = extract_data_from_html(html_content)
            return response.json(), structured_data, unstructured_data
        else:
            print(f"[ERROR] 새로운 POST 요청 실패. Status Code: {response.status_code}")
            print(f"Response: {response.text}")
            return None, None, None
    except Exception as e:
        print("[ERROR] 새로운 POST 요청 중 오류 발생:", traceback.format_exc())
        return None, None, None

# 메인 실행 코드
if __name__ == "__main__":
    driver = create_webdriver()
    try:
        login(driver, 'goguma@krx.co.kr', 'wkrwjs12!@')
        time.sleep(15)  # 로그인 후 인증 토큰 생성 대기
        
        # Authorization 헤더 추출
        auth_header = None
        for request in driver.requests:
            if request.url == "https://dataservice.koscom.co.kr/apis/v1/common/auth/my-information":
                auth_header = request.headers.get('Authorization')
                print(f"[INFO] 로그인 후 얻은 Authorization 헤더: {auth_header}")
                break

        if not auth_header:
            print("[ERROR] Authorization 헤더를 찾을 수 없습니다.")
            driver.quit()
            
        headers = {'Authorization': auth_header}
        first_api_url = f'https://dataservice.koscom.co.kr/apis/v1/user/approvals/{REFERENCE_ID}'

        for request in driver.requests:
            if 'Authorization' in request.headers:
                headers = {'Authorization': request.headers['Authorization']}
                break
        if not headers:
            print("[ERROR] Authorization 헤더를 찾을 수 없습니다.")
        else:
# =============================================================================
#             # 첫 번째 API 요청 실행
# =============================================================================
            first_api_response, structured_data, unstructured_data = send_api_request(first_api_url, headers)
            # print(f"[INFO] 첫 번째 API 요청 헤더: {headers}")
    
            if first_api_response or structured_data or unstructured_data:
                # 첫 번째 API 응답 처리
                # print("[INFO] 첫 번째 API 응답:", first_api_response)
                # print("[INFO] 구조화된 데이터:", structured_data)
                # print("[INFO] 구조화되지 않은 데이터:", unstructured_data)
                save_response_as_json({"first_api_response": first_api_response, "structured_data": structured_data, "unstructured_data": unstructured_data}, "first_api_response.json")
                # 첫 번째 API 응답에서 total 및 totalPage 추출
                total = first_api_response.get("page", {}).get("total", 0)
                totalPage = first_api_response.get("page", {}).get("totalPage", 0)

            else:
                print("[ERROR] 첫 번째 API 요청 실패. 재시도를 시도합니다.")
                # 재로그인을 시도하고 다시 헤더 추출
                login(driver, 'goguma@krx.co.kr', 'wkrwjs12!@')
                time.sleep(15)
                for request in driver.requests:
                    if request.url == "https://dataservice.koscom.co.kr/apis/v1/common/auth/my-information":
                        auth_header = request.headers.get('Authorization')
                        # print(f"[INFO] 첫 번째 API 요청 재시도 헤더: {auth_header}")
                        break

# =============================================================================
#         # 두 번째 API 요청
# =============================================================================
        second_api_url = "https://dataservice.koscom.co.kr/apis/v1/common/snapshots/history"
        
        # Authorization, Content-Type, Accept와 같은 헤더는 대부분의 API 요청에 필수적
        second_api_headers = {
            'Host': 'dataservice.koscom.co.kr',
            'Connection': 'keep-alive',
            # 'Content-Length': '105',
            'sec-ch-ua': '"Google Chrome";v="119", "Chromium";v="119", "Not?A_Brand";v="24"',
            # 'KMBS-LANGUAGE': 'ko',
            # 'sec-ch-ua-mobile': '?0',
            'Authorization': headers['Authorization'],
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36',
            'Content-Type': 'application/json',
            'Accept': 'application/json, text/plain, */*',
            # 'KMBS-PAGEID': '300238',
            'sec-ch-ua-platform': '"Windows"',
            'Origin': 'https://dataservice.koscom.co.kr',
            'Sec-Fetch-Site': 'same-origin',
            'Sec-Fetch-Mode': 'cors',
            'Sec-Fetch-Dest': 'empty',
            'Referer': 'https://dataservice.koscom.co.kr/krx/100562/approval-detail',
            'Accept-Encoding': 'gzip, deflate, br',
            'Accept-Language': 'ko-KR,ko;q=0.9,en-US;q=0.8,en;q=0.7'
        }
        second_api_body = {
            'snapshotsLargeClassificationCode': '04',
            'snapshotsSmallClassificationCode': '04_01',
            'referenceId': REFERENCE_ID
        }

        # 두 번째 API 요청 실행
        second_api_response = send_post_request(second_api_url, second_api_headers, second_api_body)
        # print(f"[INFO] 두 번째 API 요청 헤더: {second_api_headers}")

        if second_api_response:
            # print("[INFO] 두 번째 API 응답:", second_api_response)

            # 두 번째 API 응답 데이터 분류
            structured_data, unstructured_data = classify_api_response(second_api_response)
            # print("[INFO] 구조화된 데이터:", structured_data)
            # print("[INFO] 비구조화된 데이터:", unstructured_data)

            # JSON 파일로 저장
            save_response_as_json({"second_api_response": second_api_response, "structured_data": structured_data, "unstructured_data": unstructured_data}, "second_api_response.json")
            save_network_logs(driver, "network_logs_success.txt")
        else:
            print("[ERROR] 두 번째 API 요청 실패")
            save_network_logs(driver, "network_logs_fail.txt")

# =============================================================================
#         # 새로운(third) API 요청 및 응답 처리
# =============================================================================
        pageNumber = 0
        third_api_url = "https://dataservice.koscom.co.kr/apis/v1/user/approvals/search"
        third_api_body = {
            "startDate": "",
            "endDate": "",
            "sanctionTypeCode": "",
            "approvalStatusCode": "",
            "ordersSectionCode": "",
            "searchType": "SUBJECT",
            "searchText": "",
            "page": {
                "pageNumber": pageNumber, 
                "pageSize": 10,
                "total": total,   # 첫 번째 API 응답에서 추출한 total 값
                "totalPage": totalPage  # 첫 번째 API 응답에서 추출한 totalPage 값
            }
        }
        third_api_response, structured_data, unstructured_data = send_third_api_request(third_api_url, headers, third_api_body)
        if third_api_response or structured_data or unstructured_data:
            save_response_as_json({"third_api_response": third_api_response, "structured_data": structured_data, "unstructured_data": unstructured_data}, "third_api_response.json")
        else:
            print("[ERROR] 새로운 API 요청 실패")


    except Exception as e:
        print("[ERROR] 메인 실행 중 오류 발생:", traceback.format_exc())
    finally:
        driver.quit()
        print("세션을 종료하고 프로세스가 완료되었습니다.")


